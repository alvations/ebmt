/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 1.34							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plmsg.cpp		message-output functions	 	*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2001,2003 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "panlite.h"
#include "plglobal.h"

/************************************************************************/
/************************************************************************/

void output_message(ostream &output, const char *type, va_list args)
{
   const char *text ;
   ostream *out = &output ;
   if (Panlite_network_mode)
      out = current_outstream ? current_outstream : &cout ;
   if (generate_lattice)
      {
      if (lattice_in_transducer_format)
	 *out << type << " # # " ;
      else
	 *out << "-1 -1 :" << type << " -1 \"" ;
      }
   else
      *out << "; " ;
   while ((text = va_arg(args,char*)) != 0)
      {
      *out << text ;
      }
   va_end(args) ;
   if (generate_lattice)
      {
      if (lattice_in_transducer_format)
	 *out << " # 0" ;
      else
	 *out << '"' ;
      }
   *out << endl ;
   return ;
}

//----------------------------------------------------------------------

void output_message(ostream &output, const char *type, ...)
{
   va_list args ;
   va_start(args,type) ;
   output_message(output,type,args) ;
   va_end(args) ;
   return ;
}

// end of file plmsg.cpp //
