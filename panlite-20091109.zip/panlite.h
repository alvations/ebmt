/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File panlite.h							*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __PANLITE_H_INCLUDED
#define __PANLITE_H_INCLUDED

#include "FramepaC.h"

#if defined(__GNUC__) && __GNUC__ == 3 && __GNUC_MINOR__ < 4
# pragma GCC dependency "FramepaC.h" "You may need to do a 'make clean'"
#endif
#if __GNUC__ == 4 || (__GNUC__ == 3 && __GNUC_MINOR__ >= 4)
# pragma GCC dependency "FramepaC.h"
#endif

/************************************************************************/
/*    Manifest constants 						*/
/************************************************************************/

#define PROGRAM_NAME		"Multi-EngineMT"
#define PANLITE_VERSION_STR	"2.90"

#define DEFAULT_PANLITE_CFGFILE "panlite.cfg"
#define DEFAULT_PANLITE_PORTNUM 4130

/************************************************************************/
/*	"Forward" declarations of opaque class types			*/
/************************************************************************/

class PLConfig ;
class MEMTGlobalVariables ;

/************************************************************************/
/************************************************************************/

class MEMTServer : public FrNetworkServer
   {
   private:
      MEMTGlobalVariables **global_vars ;
      char *partial_sentence ;
   public:
      MEMTServer(int portnum) ;
      ~MEMTServer() ;

      // network activity callbacks
      virtual void onConnect(size_t conn) ;
      virtual void onDisconnect(size_t conn) ;
      virtual bool onLineReceived(size_t conn, const char *line) ;
   } ;

/************************************************************************/
/************************************************************************/

void PlTrapSignals() ;
void PlRestoreSignals() ;

void PlTrapErrors() ;
void PlRestoreErrors() ;

void PlLineWrap(ostream &, const char *line) ;
void PlResetLineWrap(ostream &, bool force = false) ;

void output_message(ostream &output, const char *type, va_list) ;
void output_message(ostream &output, const char *type, ...) ;

bool PlExecPrograms(const PLConfig *config,ostream &err) ;
void PlShutdownPrograms(ostream &out,ostream &err) ;

void PlApplyPreprocessor(char *line, size_t maxline, bool canonicalize) ;
FrList *PlSplitIntoSentences(char *&partial, char *line) ;

void PlApplyLM(const FrTextSpans *input, FrTextSpans *lattice,
	       ostream &out, ostream &err, bool gc = false) ;
void PlResyncLM(ostream &out) ;

bool PlSetGenre(const char *) ;
const char *PlGetGenre() ;

FrTextSpans *PlMakeLattice(const FrObject *obj) ;
void PlAddSourcePassthru(const FrTextSpans *inlattice,
			 FrTextSpans *outlattice) ;

void PlProcessInput(istream &in,ostream &out, ostream &err) ;
int PlProcessLine(const char *line, istream &in, ostream &out,
		  ostream &err) ;

bool PlIsXMLHeader(const char *line, bool unicode) ;
bool PlHasUTF8Marker(const char *line) ;

bool PlIsCommand(const char *line) ;
bool PlIsSafeCommand(const char *line) ;
char *PlExtractCommandWord(ostream &err, const char *line,
			   const char **end = 0) ; // use FrFree on result
bool PlProcessCommand(const char *line,istream &in,
			ostream &out,ostream &err) ;

bool PlPrepareForDocument(bool starting, istream &in, ostream &out,
			    ostream &err) ;

void PlSetAlternativeGenres(const FrList *genres) ;
FrSymbol *PlNextAlternativeGenre() ;

void Panlite_clear_word_delimiters() ;

void PlOutputXMLHeader(ostream &out) ;
void PlOutputXMLFooter(ostream &out) ;

#endif /* !__PANLITE_H_INCLUDED */

// end of file panlite.h //
