/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plcmd.cpp		process 'colon' commands		*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "plchart.h"
#include "plengine.h"
#include "plproc.h"
#include "plutil.h"
#include "panlite.h"
#include "plglobal.h"

#ifdef FrSTRICT_CPLUSPLUS
# include <fstream>
#else
# include <fstream.h>
#endif /* FrSTRICT_CPLUSPLUS */

/************************************************************************/
/* 	Global Variables						*/
/************************************************************************/

extern PLConfig *pl_config ;

/************************************************************************/
/*    on-line command processing					*/
/************************************************************************/

static void process_help_command(const char *, istream &, ostream &,
				 ostream &out)
{
   out << "Available commands:\n"
	  ":HELP\t\tthis listing\n" ;
   if (!Panlite_network_mode)
      out << ":ALT seg|word\ttranslate alternate versions of a sentence (to :END)\n" ;
   out << ":BLOCKQUOTE c\t"
      	  	"output everything up to next occurrence of char 'c' as-is\n"
	  ":CONTEXT x n\t"
		"show 'n' lines of context (default 4) around example number 'x'\n"
	  ":DESCRIBE x\treturn information about parameter 'x'\n"
	  ":DISABLE x\tdisable the engine whose tag is 'x'\n"
          "\t(" ;
   MEMTEngine::enumerate(out) ; out << ')' << endl ;
   out << ":DOC/:ENDDOC\ttranslate a document as a unit (may improve qual)\n"
	  ":ENABLE x\tenable the engine whose tag is 'x'\n" ;
   if (!Panlite_network_mode)
      out << ":FILE file\tprocess 'file' as if typed from keyboard\n" ;
   out << ":FREEFORM on|off  en/disable free-form text input\n"
	  ":GENRE g [t]\tswitch settings to genre 'g' and optionally translate 't'\n"
	  ":LATTICE\t\ttranslate the word lattice on the following line(s)\n"
          ":LEARN engine \"SLtext\" \"TLtext\"\n"
	  ":META tag val\tadd metadata to following sentence\n"
	  ":PARAMS\t\tlist available program parameters\n"
          ":QUOTE text\toutput 'text' unaltered\n" ;
   if (!Panlite_network_mode)
      out << ":REF\tspecify reference translations (to :END) for next sentence\n" ;
   out << ":SET \"x\" \"y\"\tset the value of parameter 'x' to 'y'\n"
	  ":SHOW \"x\"\tshow current value of parameter 'x'\n"
          ":STATE x\treport on the state of engine 'x'\n"
	  ":TELL eng cmd\tsend a private command to engine 'eng'\n"
	  ":VERB on|off\tset/unset Verbose mode\n" ;
   out << ":EXIT\t\tquit this program\n" ;
   out << endl ;
   return ;
}

//----------------------------------------------------------------------

static void process_listparms_command(const char *, istream &, ostream &out,
				      ostream & /*err*/)
{
   const PLConfig *config = pl_config ;
   if (!config)
      out << "Unable to list parameters -- no configuration loaded" << endl ;
   else
      {
      FrList *params = config->listParameters() ;
      out << params << endl << endl ;
      free_object(params) ;
      }
   return ;
}

//----------------------------------------------------------------------

static int check_on_off(const char *line,ostream &err)
{
   if (!line)
      return -1 ;
   while (Fr_isspace(*line))
      line++ ;
   char newstate[5] ;
   unsigned int len ;
   for (len = 0 ; len < sizeof(newstate)-1 ; len++, line++)
      {
      if (Fr_isspace(*line))
	 break ;
      else
	 newstate[len] = *line ;
      }
   newstate[len] = '\0' ;
   if (Fr_stricmp(newstate,"on") == 0)
      return true ;
   else if (Fr_stricmp(newstate,"off") == 0)
      return false ;
   else if (Fr_stricmp(newstate,"?") == 0)
      return -1 ;
   else
      {
      output_message(err,"INFO","Expected 'on' or 'off'",0) ;
      return -1 ;
      }
}

//----------------------------------------------------------------------

static void print_status_header(ostream &out)
{
   if (generate_lattice)
      out << "-1 -1 :STATUS -1 \"" ;
   return ;
}

//----------------------------------------------------------------------

static void print_status_trailer(ostream &out)
{
   if (generate_lattice)
      out << '"' ;
   out << endl ;
   return ;
}

//----------------------------------------------------------------------

static void print_status(ostream &out, const char *message)
{
   print_status_header(out) ;
   out << message ;
   print_status_trailer(out) ;
   return ;
}

//----------------------------------------------------------------------

static void print_status(ostream &out, const char *message, const char *arg)
{
   if (!message)
      message = "" ;
   if (!arg)
      arg = "" ;
   print_status_header(out) ;
   out << message << arg ;
   print_status_trailer(out) ;
   return ;
}

//----------------------------------------------------------------------

static void print_flag(ostream &out, const char *message, bool flag)
{
   print_status(out,message,(flag ? " on" : " off")) ;
   return ;
}

//----------------------------------------------------------------------

static void process_alt_command(const char *line, istream &, ostream &,
				ostream &err)
{
   // start by seeing what type of alternation we're starting, segmentation
   //   or word choice
   FrSkipWhitespace(line) ;
   if (Fr_toupper(*line) == 'S')
      {
      // segmentation alternatives
      Panlite_prev_batchsize = Panlite_lines_per_batch ;
      Panlite_lines_per_batch = (int)PL_MERGE_SEG ;
      FrList *genres = 0 ;
      while (FrSkipToWhitespace(line))
	 {
	 FrObject *obj = string_to_FrObject(line) ;
	 FrSymbol *genre = FrCvt2Symbol(obj,char_encoding) ;
	 free_object(obj) ;
	 pushlist(genre,genres) ;
	 }
      genres = listreverse(genres) ;
      PlSetAlternativeGenres(genres) ;
      free_object(genres) ;
      if (&err != &cerr || !quiet_mode)
	 output_message(err,"STATUS","OK",0) ;
      }
   else if (Fr_toupper(*line) == 'W')
      {
      // word-choice alternatives
      output_message(err,"STATUS","Alternation by WORD not available yet",0) ;
      Panlite_prev_batchsize = Panlite_lines_per_batch ;
//!!!      Panlite_lines_per_batch = PL_MERGE_WORD ;
//      if (&err != &cerr || !quiet_mode)
//         output_message(err,"STATUS","OK",0) ;
      }
   else
      output_message(err,"ERROR","Alternation type must be SEGMENT or WORD",0);
   return ;
}

//----------------------------------------------------------------------

static void process_disable_command(const char *line, istream &, ostream &,
				    ostream &err)
{
   FrObject *engine_tag = string_to_FrObject(line) ;
   if (engine_tag && engine_tag->symbolp())
      {
      MEMTEngine *engine = MEMTEngine::findEngine((FrSymbol*)engine_tag) ;
      if (engine)
	 {
	 engine->disableEngine() ;
	 print_status(err,"engine disabled") ;
	 }
      else
	 print_status(err,"no such engine") ;
      }
   else
      print_status(err,"Command format: :DISABLE enginetag") ;
   free_object(engine_tag) ;
   return ;
}

//----------------------------------------------------------------------

static void process_enable_command(const char *line, istream &, ostream &,
				   ostream &err)
{
   FrObject *engine_tag = string_to_FrObject(line) ;
   if (engine_tag && engine_tag->symbolp())
      {
      MEMTEngine *engine = MEMTEngine::findEngine((FrSymbol*)engine_tag) ;
      if (engine)
	 {
	 engine->enableEngine() ;
	 print_status(err,"engine enabled") ;
	 }
      else
	 print_status(err,"no such engine") ;
      }
   else
      print_status(err,"Command format: :ENABLE enginetag") ;
   free_object(engine_tag) ;
   return ;
}

//----------------------------------------------------------------------

static void process_doc_command(const char * /*line*/,
				istream &in, ostream &out, ostream &err)
{
   if (preparing_for_doc)
      {
      if (!quiet_mode)
	 err << ":DOC already started" << endl ;
      }
   else if (PlPrepareForDocument(true,in,out,err))
      {
      if (!quiet_mode)
	 err << ":DOC Ok" << endl ;
      }
   else if (!quiet_mode)
      err << ":DOC Error" << endl ;
   return ;
}

//----------------------------------------------------------------------

static void process_enddoc_command(const char * /*line*/,
				   istream &in, ostream &out, ostream &err)
{
   if (PlPrepareForDocument(false,in,out,err))
      {
      if (!quiet_mode)
	 err << ":ENDDOC Ok" << endl ;
      }
   else if (!quiet_mode)
      err << ":ENDDOC Error" << endl ;
   out.flush() ;
   return ;
}

//----------------------------------------------------------------------

static void process_state_command(const char *line, istream &, ostream &,
				  ostream &err)
{
   FrObject *engine_tag = string_to_FrObject(line) ;
   if (engine_tag && engine_tag->symbolp())
      {
      MEMTEngine *engine = MEMTEngine::findEngine((FrSymbol*)engine_tag) ;
      if (engine)
	 {
	 print_status_header(err) ;
	 err << "engine is "
	     << (engine->engineEnabled() ? "enabled" : "disabled")
	     << " and "
	     << (engine->updatesAllowed() ? "updateable" : "read-only") ;
	 print_status_trailer(err) ;
	 }
      else
	 print_status(err,"no such engine") ;
      }
   else
      print_status(err,"Command format: :ENABLE enginetag") ;
   free_object(engine_tag) ;
   return ;
}

//----------------------------------------------------------------------

static void process_freeform_command(const char *line,istream &, ostream &,
				     ostream &err)
{
   int newstate = check_on_off(line,err) ;
   if (newstate != -1)
      freeform_input = (bool)newstate ;
   print_flag(err,"Free-form file input is now",freeform_input) ;
   return ;
}

//----------------------------------------------------------------------

static void process_genre_command(const char *line, istream &in, ostream &out,
				  ostream &err)
{
   FrObject *genre = string_to_FrObject(line) ;
   if (!genre || genre == makeSymbol("*EOF*") || !genre->symbolp())
      print_status(err,"Must specify a genre name") ;
   else if (genre == makeSymbol("?"))
      print_status(err,"Current genre is ",PlGetGenre()) ;
   else if (FrSkipWhitespace(line))
      {
      // we have optional text to be translated, so set the genre, quietly
      //   ignoring errors, do the translation, restore the genre, and return
      //   the translation of the text
      char *curr_genre = FrDupString(PlGetGenre()) ;
      if (!PlSetGenre(FrPrintableName(genre)))
	 err << "{{bad_genre}} " ;
      PlProcessLine(line,in,out,err) ;
      (void)PlSetGenre(curr_genre) ;
      FrFree(curr_genre) ;
      }
   else
      {
      // no optional text, so just set the genre and report success/failure
      bool success = PlSetGenre(FrPrintableName(genre)) ;
      print_status(err,success?"Ok":"genre selection failed") ;
      }
   return ;
}

//----------------------------------------------------------------------

static void process_lattice_command(const char *line, istream &in,
				    ostream &out, ostream &err)
{
   char *lat = FrDupString(line) ;
   size_t len = strlen(lat) ;
   // read lines until we get a complete lattice
   while (!in.eof() && !in.fail())
      {
      char linebuf[FrMAX_LINE] ;
      in.getline(linebuf,sizeof(linebuf)) ;
      size_t newlen = strlen(linebuf) ;
      char *newlat = FrNewR(char,lat,len+newlen+2) ;
      if (newlat)
	 {
	 newlat[len++] = ' ' ;
	 lat = newlat ;
	 memcpy(newlat+len,linebuf,newlen+1) ;
	 len += newlen ;
	 }
      else
	 {
	 FrNoMemory("reading lattice") ;
	 break ;
	 }
      char *lineptr = lat ;
      if (valid_FrObject_string(lineptr))
	 break;
      }
   char *lineptr = lat ;
   FrObject *latobj = string_to_FrObject(lineptr) ;
   FrFree(lat) ;
   FrTextSpans *lattice = PlMakeLattice(latobj) ;
   free_object(latobj) ;
   if (lattice && !lattice->OK())
      {
      print_status(err,"Expected a list of arcs for the lattice") ;
      return ;
      }
   // now that we have the lattice, translate it
   FrTextSpans *translation = new FrTextSpans(lattice) ;
   if (MEMTEngine::translate(lattice,translation,err,false,verbose))
      {
      PlAddSourcePassthru(lattice,translation) ;
      PlApplyLM(lattice,translation,out,err,conserve_memory) ;
      if (Panlite_linewrap_width == 0)
	 PlResetLineWrap(out) ;
      }
   else
      {
      out << "{no translation}" << endl ;
      if (chartfile)
	 {
	 PlAddSourcePassthru(lattice,lattice) ;
	 FrList *chart = lattice->printable() ;
	 (*chartfile) << chart << endl ;
	 free_object(chart) ;
	 }
      }
   delete translation ;
   delete lattice ;
   return ;
}

//----------------------------------------------------------------------

static void process_verbose_command(const char *line,istream &, ostream &,
				    ostream &err)
{
   int newstate = check_on_off(line,err) ;
   if (newstate != -1)
      verbose = (bool)newstate ;
   print_flag(err,"Verbose is now",verbose) ;
   return ;
}

//----------------------------------------------------------------------

static char *remove_blanks(const char *line)
{
   if (!line)
      return 0 ;
   char *result = FrNewN(char,strlen(line)+1) ;
   if (result)
      {
      char *loc = result ;
      for ( ; *line ; line++)
	 if (!Fr_isspace(*line))
	    *loc++ = *line ;
      *loc = '\0' ;			// ensure proper termination
      }
   return result ;
}

//----------------------------------------------------------------------

static void process_file_command(const char *line,istream &, ostream &out,
				 ostream &err)
{
   while (Fr_isspace(*line))
      line++ ;
   if (!*line)
      print_status(err,"Expected filename.") ;
   else
      {
      bool old_interactive = interactive_Panlite ;
      interactive_Panlite = false ;
      char *filename = remove_blanks(line) ;
      istream *in = new ifstream(filename,ios::in|ios::binary) ;
      if (in && in->good())
	 {
	 PlProcessInput(*in,out,err) ;
	 delete in ;
	 PlResetLineWrap(out) ;
	 out << endl ;
	 }
      else
	 {
	 print_status_header(err) ;
	 err << "Unable to open file '" << filename << "'" ;
	 print_status_trailer(err) ;
	 }
      FrFree(filename) ;
      interactive_Panlite = old_interactive ;
      }
   return ;
}

//----------------------------------------------------------------------

static void process_learn_command(const char *line, istream &, ostream &,
				  ostream &err)
{
   FrObject *engine_tag = string_to_FrObject(line) ;
   FrObject *source_text = string_to_FrObject(line) ;
   FrObject *target_text = string_to_FrObject(line) ;
   FrObject *meta_text = string_to_FrObject(line) ;
   if (meta_text && !meta_text->stringp())
      {
      free_object(meta_text) ;
      meta_text = 0 ;
      }
   if (engine_tag && engine_tag->symbolp() &&
       source_text && source_text->stringp() &&
       target_text && target_text->stringp())
      {
      if (((FrString*)source_text)->stringLength() == 0 ||
	  ((FrString*)target_text)->stringLength() == 0)
	 print_status(err,"both source and target must be non-empty") ;
      else
	 {
	 if (Panlite_update_filename)
	    {
	    FILE *fp = fopen(Panlite_update_filename,"a") ;
	    if (fp)
	       {
	       fprintf(fp,"%s %s \"%s\" = %s \"%s\", metadata=\"%s\"\n",
		       FrPrintableName(engine_tag),
		       Panlite_source_language,
		       FrPrintableName(source_text),
		       Panlite_target_language,
		       FrPrintableName(target_text),
		       FrPrintableName(meta_text)) ;
	       fclose(fp) ;
	       }
	    }
	 MEMTEngine *engine = MEMTEngine::findEngine((FrSymbol*)engine_tag) ;
	 if (!engine)
	    print_status(err,"no such engine") ;
	 else if (!engine->updatesAllowed())
	    print_status(err,"engine does not support/allow updates") ;
	 else if (engine->addTranslation((FrString*)source_text,
					 (FrString*)target_text,
					 (FrString*)meta_text,cout))
	    print_status(err,"translation added to engine") ;
	 else
	    print_status(err,"error adding translation to engine") ;
	 }
      }
   else
      print_status(err,
		   "Command format: :LEARN enginetag \"SLtext\" \"TLtext\" [\"metadata\"]") ;
   free_object(engine_tag) ;
   free_object(source_text) ;
   free_object(target_text) ;
   free_object(meta_text) ;
   return ;
}

//----------------------------------------------------------------------

static void process_meta_command(const char *line, istream &in,
				 ostream &out, ostream &err)
{
   (void)in; (void)out;
   FrObject *keyobj = string_to_FrObject(line) ;
   FrObject *value = string_to_FrObject(line) ;
   FrSymbol *key = (keyobj && keyobj->symbolp()) ? (FrSymbol*)keyobj : 0 ;
   if (key && value)
      {
      if (!pending_metadata)
	 pending_metadata = new FrStruct(makeSymbol("METADATA")) ;
      if (pending_metadata)
	 pending_metadata->put(key,value) ;
      else
	 print_status(err,"problem storing metadata") ;
      }
   else
      print_status(err,"must supply both a key and a value to :META") ;
   free_object(key) ;
   free_object(value) ;
   return ;
}

//----------------------------------------------------------------------

static void process_blockquote_command(const char *line, istream &in,
				       ostream &out, ostream &err)
{
   while (*line && Fr_isspace(*line))
      line++ ;
   char terminator = *line ;
   if (terminator)
      {
      while (!in.eof() && !in.fail())
	 {
	 int c = in.get() ;
	 if (c != EOF)
	    out << (char)c ;
	 if (c == terminator)
	    break ;
	 }
      out << flush ;
      }
   else
      print_status(err,"Usage is :BLOCKQUOTE *, where * is the last character "
		   "to pass unchanged") ;
   return ;
}

//----------------------------------------------------------------------

static void process_quote_command(const char *line, istream &, ostream &out,
				  ostream &)
{
   out << line << endl ;
   return ;
}

//----------------------------------------------------------------------

static void process_ref_command(const char * /*line*/, istream &, ostream &,
				ostream &err)
{
   // accumulate reference translations
   Panlite_prev_batchsize = Panlite_lines_per_batch ;
   Panlite_lines_per_batch = (int)PL_MERGE_REF ;
   output_message(err,"STATUS","OK",0) ;
   return ;
}

//----------------------------------------------------------------------

static char *extract_filename(const char *line)
{
   FrSkipWhitespace(line) ;
   char *name = FrDupString(line) ;
   if (name)
      {
      char *end = strchr(name,'\0') ;
      while (end > name && Fr_isspace(end[-1]))
	 *--end = '\0' ;
      }
   return name ;
}

//----------------------------------------------------------------------

static void process_setcorpus_command(const char *line, istream &, ostream &,
				      ostream &err)
{
   char *corpusname = extract_filename(line) ;
   bool success = ebmt_engine.selectKB(corpusname) ;
   if ((size_t)Panlite_lines_per_batch < PL_MERGE)
      {
      if (success)
	 print_status(err,"Corpus successfully selected") ;
      else
	 print_status(err,"Unable to select specified EBMT corpus") ;
      }
   FrFree(corpusname) ;
   return ;
}

//----------------------------------------------------------------------

static void process_setdict_command(const char *line, istream &, ostream &,
				    ostream &err)
{
   char *dictname = extract_filename(line) ;
   bool success = dict_engine.selectKB(dictname) ;
   if (success)
      print_status(err,"Dictionary successfully selected") ;
   else
      print_status(err,"Unable to select specified dictionary") ;
   FrFree(dictname) ;
   return ;
}

//----------------------------------------------------------------------

static void process_show_command(const char *line, istream &, ostream &out,
				 ostream & /*err*/ )
{
   PLConfig *config = pl_config ;
   if (!config)
      {
      out << "Unable to show parameters -- no configuration loaded\n"
	  << endl ;
      return ;
      }
   FrObject *obj = string_to_FrObject(line) ;
   if (obj && obj != makeSymbol("?") && obj->printableName())
      {
      char *value = config->currentValue(obj->printableName()) ;
      if (value)
	 out << "( " << obj->printableName() << " = " << value << " )\n"
	     << endl;
      else
	 out << "( unknown parameter )\n" << endl ;
      FrFree(value) ;
      }
   else
      out << "Usage: :SHOW \"parameter\"\n" << endl ;
   return ;
}


//----------------------------------------------------------------------

static void process_set_command(const char *line, istream &, ostream &out,
				ostream & /*err*/ )
{
   PLConfig *config = pl_config ;
   if (!config)
      {
      out << "Unable to show parameters -- no configuration loaded"
	  << endl ;
      return ;
      }
   FrObject *obj = string_to_FrObject(line) ;
   if (obj && obj != makeSymbol("?") && obj->printableName())
      {
      const char *param_name = obj->printableName() ;
      FrObject *obj2 = string_to_FrObject(line) ;
      if (obj2 && obj2->printableName())
	 {
	 if (config->setParameter(param_name,obj2->printableName(),&out))
	    {
	    char *value = config->currentValue(param_name) ;
	    out << "( " << param_name << " <= " << value << " )" << endl  ;
	    FrFree(value) ;
	    }
	 else
	    out << "( error )" << endl ;
	 return ;
	 }
      }
   out << "Usage: :SET \"parameter\" \"new-value\"\n" << endl ;
   return ;
}


//----------------------------------------------------------------------

static void process_describe_command(const char *line, istream &, ostream &out,
				     ostream & /*err*/ )
{
   PLConfig *config = pl_config ;
   if (!config)
      {
      out << "Unable to describe parameters -- no configuration loaded"
	  << endl ;
      return ;
      }
   FrObject *obj = string_to_FrObject(line) ;
   if (obj && obj != makeSymbol("?") && obj->printableName())
      {
      const char *param = obj->printableName() ;
      FrList *description =  config->describeParameter(param) ;
      out << description << endl << endl ;
      free_object(description) ;
      }
   else
      out << "Usage: :DESCRIBE \"parameter\"\n" << endl ;
   return ;
}

//----------------------------------------------------------------------

static void process_tell_command(const char *line, istream &, ostream &out,
				 ostream &err)
{
   FrObject *eng = string_to_FrObject(line) ;
   const char *eng_name = FrPrintableName(eng) ;
   if (!eng_name || FrSkipWhitespace(line) == '\0')
      {
      err << "Usage: :TELL :engine command...." << endl << endl ;
      return ;
      }
   MEMTEngine *engine = MEMTEngine::findEngine(eng_name) ;
   if (engine)
      {
      char *result = engine->sendCommand(line,err,verbose) ;
      if (result && *result)
	 {
	 out << result[0] ;
	 char *str ;
	 for (str = result+1 ; *str ; str++)
	    {
	    if (str[0] == '\n' && str[-1] == '\n')
	       out << ' ' ;
	    out << str[0] ;
	    }
	 if (str[-1] != '\n')
	    out << endl << endl ;
	 else if (str > result + 1 && str[-2] != '\n')
	    out << endl ;
	 }
      else
	 out << endl << endl ;
      FrFree(result) ;
      }
   else
      err << "Engine " << eng_name << " not available" << endl << endl ;
   return ;
}

//----------------------------------------------------------------------
// ABP

static void process_context_command(const char *line, istream & /*in*/,
				    ostream &out, ostream &err)
{
   char *end = 0 ;
   FrSkipWhitespace(line) ;
   long exampleNumber = strtol(line,&end,0);
   long range = 0 ;
   if (end == line || exampleNumber < 0)
      {
      err << "Invalid example number" << endl ;
      return ;
      }
   if (end != line)
      range = strtol(end,&end,0) ;
   if (range <= 0)
      range = 4 ;
   else if (range > 20)
      range = 20 ;
   char buf[1000] ;
   Fr_sprintf(buf,sizeof(buf),"CONTEXT %ld %ld",exampleNumber,range) ;
   char *context = ebmt_engine.sendCommand(buf,err,false) ;
   bool have_context = false ;
   if (context)
      {
      char *c = context ;
      FrList *clist = (FrList*)string_to_FrObject(c) ;
      FrFree(context) ;
      if (clist && clist->consp())
	 {
	 have_context = true ;
	 while (clist)
	    {
	    FrString *context = (FrString*)poplist(clist) ;
	    if (context && context->stringp())
	       out << context->stringValue() << endl ;
	    else
	       out << endl ;
	    }
	 }
      }
   if (!have_context)
      err << "No context found" << endl << flush;
   return ;
}
// ABP

/************************************************************************/
/************************************************************************/

struct PANLITE_Command
   {
   const char *name ;
   void (*func)(const char *line, istream &in, ostream &out, ostream &err) ;
   bool safe ;
   } ;

static PANLITE_Command special_options[] =
   {
     { "alt",	    process_alt_command,	true },
     { "alternates",process_alt_command,	true },
     { "blockquote",process_blockquote_command,	true },
     { "context",   process_context_command,	false }, //(unsafe:leaks data)
     { "describe",  process_describe_command,	true },
     { "dis",       process_disable_command,	true },
     { "disable",   process_disable_command,	true },
     { "doc",	    process_doc_command,	true },
     { "en",        process_enable_command,	true },
     { "enable",    process_enable_command,	true },
     { "end",	    0, true },		// handled explicitly elsewhere
     { "enddoc",    process_enddoc_command,	true },
     { "file",	    process_file_command,	false },
     { "freeform",  process_freeform_command,	true },
     { "genre",	    process_genre_command,	true },
     { "help",	    process_help_command,	false },
     { "lattice",   process_lattice_command,	true },
     { "learn",	    process_learn_command,	false },
     { "listparms", process_listparms_command,	true },
     { "meta",	    process_meta_command,	true },
     { "quote",	    process_quote_command,	true },
     { "params",    process_listparms_command,	true },
     { "ref",	    process_ref_command,	true },
     { "setcorpus", process_setcorpus_command,	true },
     { "set",	    process_set_command,	false },
     { "setdict",   process_setdict_command,	true },
     { "show",	    process_show_command,	false },
     { "state",	    process_state_command,	true },
     { "tell",	    process_tell_command,	false },
     { "verb",	    process_verbose_command,	false },
     { "verbose",   process_verbose_command,	false },
     { 0,	    0,				true },
   } ;

//----------------------------------------------------------------------

char *PlExtractCommandWord(ostream & /*err*/, const char *line,
			   const char **end)
{
   if (!line)
      return 0 ;
   while (Fr_isspace(*line))
      line++ ;
   if (*line == ':')
      line++ ;
   while (Fr_isspace(*line))
      line++ ;
   char command[40] ;
   unsigned int len ;
   for (len = 0 ; *line && len < sizeof(command)-1 ; len++, line++)
      {
      if (Fr_isspace(*line))
	 {
	 line++ ;
	 break ;
	 }
      else
	 command[len] = *line ;
      }
   command[len] = '\0' ;
   if (end)
      *end = line ;
   return FrDupString(command) ;
}

//----------------------------------------------------------------------

bool PlIsSafeCommand(const char *line)
{
   char *command = PlExtractCommandWord(cerr,line,&line) ;
   if (!command)
      return false ;
   bool safe = false ;
   if (allow_colon_commands || interactive_Panlite)
      {
      if (Fr_stricmp(command,"shutdown") == 0)
	 safe = (!Panlite_network_mode || allow_colon_commands) ;
      else
	 safe = true ;
      }
   if ((Fr_stricmp(command,"exit") == 0 || Fr_stricmp(command,"quit") == 0) &&
       Panlite_network_mode)
      return true ;
   for (PANLITE_Command *cmd = special_options ; cmd->name && !safe ; cmd++)
      {
      if (Fr_stricmp(command,cmd->name) == 0)
	 safe = true ;
      }
   FrFree(command) ;
   return safe ;
}

//----------------------------------------------------------------------

bool PlProcessCommand(const char *line,istream &in,
			ostream &out,ostream &err)
{
   (void)in ;
   char *command = PlExtractCommandWord(err,line,&line) ;
   if (!command)
      return true ;
   if (Fr_stricmp(command,"exit") == 0 || Fr_stricmp(command,"quit") == 0)
      {
      FrFree(command) ;
      return false ;
      }
   else if (Panlite_network_mode && Fr_stricmp(command,"shutdown") == 0)
      {
      Panlite_network_mode = false ;
      FrFree(command) ;
      return false ;
      }
   bool found = false ;
   for (PANLITE_Command *cmd = special_options ; cmd->name ; cmd++)
      {
      if (Fr_stricmp(command,cmd->name) == 0)
	 {
	 if (cmd->func)
	    cmd->func(line,in,out,err) ;
	 found = true ;
	 break ;
	 }
      }
   if (!found)
      print_status(err,"Unrecognized command.") ;
   FrFree(command) ;
   return true ;
}

//----------------------------------------------------------------------

bool PlIsCommand(const char *line)
{
   if (!line)
      return false ;
   while (Fr_isspace(*line))
      line++ ;
   return (*line == ':') ;
}

// end of file plcmd.cpp //
