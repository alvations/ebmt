/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plebmt.cpp		interface to EBMT/Dict engines		*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifdef LINK_ALL
#define LINK_EBMT
#endif /* LINK_ALL */

#ifdef LINK_EBMT
#include "ebmt.h"
#endif /* LINK_EBMT */

#include "plengine.h"
#include "plproc.h"
#include "plutil.h"
#include "plglobal.h"

/************************************************************************/
/*	forward declarations						*/
/************************************************************************/

static bool exec_EBMT(MEMTEngine *, const PLConfig *config,
			const PlEngineConfig *engcfg, ostream &err,
			bool run_verbosely) ;
static bool translate_sentence_EBMT(MEMTEngine *engine, bool prepare,
				      const FrTextSpans *input,
				      FrTextSpans *lattice, ostream &err) ;
static bool select_EBMT_corpus(MEMTEngine *engine, const char *corpusname) ;
static bool select_EBMT_genre(MEMTEngine *engine, const char *genre_name) ;
static char *send_EBMT_command(MEMTEngine *engine, const char *command) ;
static bool update_EBMT(MEMTEngine *engine, const FrString *src,
			  const FrString *trg, const FrString *meta) ;
static bool prepare_EBMT_document(MEMTEngine *engine, bool starting) ;
static bool start_EBMT_shutdown(MEMTEngine *engine) ;

static bool translate_sentence_dict(MEMTEngine *engine, bool prepare,
				      const FrTextSpans *input,
				      FrTextSpans *lattice, ostream &err) ;
static bool select_dictionary(MEMTEngine *engine, const char *dictname) ;
static bool update_dictionary(MEMTEngine *engine, const FrString *src,
				const FrString *trg, const FrString *meta) ;

/************************************************************************/
/*    Global variables for this module				        */
/************************************************************************/

MEMTEngine dict_engine("Dictionary",":DICT",ET_Xlat,exec_EBMT,
		       translate_sentence_dict,start_EBMT_shutdown,
		       update_dictionary,select_dictionary) ;

MEMTEngine ebmt_engine("Example-Based MT",":EBMT",ET_Xlat,exec_EBMT,
		       translate_sentence_EBMT,start_EBMT_shutdown,
		       update_EBMT,select_EBMT_corpus,0,
		       send_EBMT_command,select_EBMT_genre,
		       prepare_EBMT_document) ;

/************************************************************************/
/*	helper functions						*/
/************************************************************************/

/************************************************************************/
/*    Functions for interfacing with EBMT				*/
/************************************************************************/

static bool exec_EBMT(MEMTEngine *engine, const PLConfig *config,
			const PlEngineConfig *engcfg, ostream &err,
			bool run_verbosely)
{
   // handle the fact that we have two engines sharing one program
   if (engine->copyConnection(dict_engine) ||
       engine->copyConnection(ebmt_engine))
      return true ;
   const char *cfg = engcfg->cfg() ;
   if (!cfg)
      cfg = "." ;
#ifdef LINK_EBMT
   if (engcfg->isInternal())
      {
      bool quiet = EBMT_quiet_mode(!verbose) ;
      if (initialize_EBMT("panlite-EBMT",cfg,err,true,false))
	 {
	 if (word_delimiters)
	    EBMT_set_word_delimiters(word_delimiters) ;
	 else
	    EBMT_set_word_delimiters(char_encoding) ;
	 if (run_verbosely)
	    identify_EBMT(cout,true) ;
	 EBMT_quiet_mode(quiet) ;
	 return true ;
	 }
      EBMT_quiet_mode(quiet) ;
      return false ;
      }
#endif /* LINK_EBMT */
   return engine->startEngine(config,engcfg,EBMT_NETWORK_FLAG,EBMT_QUIET_FLAG,
			      err,run_verbosely) ;
}

//----------------------------------------------------------------------

static bool translate_sentence_EBMT(MEMTEngine *engine, bool prepare,
				      const FrTextSpans *input,
				      FrTextSpans *lattice, ostream & /*err*/)
{
#ifdef LINK_EBMT
   if (!engine->isRemote())
      {
      if (prepare)
	 return false ;			// didn't need to prepare anything
      bool quiet = EBMT_quiet_mode(!verbose) ;
      EBMTCandidate *candidates = process_sentence_EBMT((FrTextSpans*)input) ;
      EBMT_quiet_mode(quiet) ;
      bool have_translations = false ;
      while (candidates)
	 {
	 if (engine->insertArcs(lattice,EbPrintCandidate(candidates)))
	    have_translations = true ;
	 EBMTCandidate *next = candidates->next() ;
	 delete candidates ;
	 candidates = next ;
	 }
      extern void EbClearLattice(FrTextSpans*) ;
      EbClearLattice((FrTextSpans*)input) ;
      return have_translations ;
      }
#endif /* LINK_EBMT */
   return engine->translate(prepare,input,lattice,"CHUNKS") ;
}

//----------------------------------------------------------------------

static bool send_EBMT_command(MEMTEngine *engine, const char *command,
				const char *arg, const char *success_string)
{
   if (engine->usingDataFile())
      return true ;
   else
      {
      engine->sendLine(command,arg) ;
      FrObject *result = engine->readObject() ;
      bool success = (result && result->stringp() &&
			((FrString*)result)->operator==(success_string)) ;
      free_object(result) ;
      return success ;
      }
}

//----------------------------------------------------------------------

static bool select_EBMT_corpus(MEMTEngine *engine, const char *corpusname)
{
#ifdef LINK_EBMT
   if (!engine->isRemote())
      return active_EBMT()->enableCorpus(corpusname,true) ;
#endif /* LINK_EBMT */
   return send_EBMT_command(engine,"SETCORPUS",corpusname,"Corpus selected");
}

//----------------------------------------------------------------------

static bool select_EBMT_genre(MEMTEngine *engine, const char *genre_name)
{
#ifdef LINK_EBMT
   if (!engine->isRemote())
      return active_EBMT()->selectGenre(genre_name) ;
#endif /* LINK_EBMT */
   return send_EBMT_command(engine,"GENRE",genre_name,"Genre selected") ;
}

//----------------------------------------------------------------------

static char *send_EBMT_command(MEMTEngine *engine, const char *command)
{
#ifdef LINK_EBMT
   if (!engine->isRemote())
      return active_EBMT()->privateCommand(command) ;
#endif /* LINK_EBMT */
   return engine->sendRemoteCommand(command) ;
}

//----------------------------------------------------------------------

static bool update_EBMT(MEMTEngine *engine, const FrString *src,
			  const FrString *trg, const FrString *meta)
{
#ifdef LINK_EBMT
   if (!engine->isRemote())
      return add_EBMT_entry(src,trg,meta,cout) ;
#endif /* LINK_EBMT */
   engine->stdIn() << "EXAMPLE ((" << src << ' ' << trg << ' ' << meta
		   << "))" << endl ;
   FrObject *result = engine->readObject() ;
   bool success = ((FrSymbol*)result == symOK) ;
   free_object(result) ;
   return success ;
}

//----------------------------------------------------------------------

static bool prepare_EBMT_document(MEMTEngine *engine, bool starting)
{
#ifdef LINK_EBMT
   if (!engine->isRemote())
      return EbPrepareDocument(starting) ;
#endif /* LINK_EBMT */
   engine->sendLine(starting ? "PREPDOC" : "ENDPREP") ;
   FrObject *result = engine->readObject() ;
   bool success = ((FrSymbol*)result == symOK) ;
   free_object(result) ;
   return success ;
}

//----------------------------------------------------------------------

static bool start_EBMT_shutdown(MEMTEngine *engine)
{
#ifdef LINK_EBMT
   if (!engine->isRemote())
      {
      bool success = save_EBMT_updates() ;
      bool q = EBMT_quiet_mode(quiet_mode) ;
      shutdown_EBMT() ;
      EBMT_quiet_mode(q) ;
      return success ;
      }
#endif /* LINK_EBMT */
   engine->sendLine("*EOF*") ;
   return true ;
}

/************************************************************************/
/*    Functions for interfacing with Dictionary				*/
/************************************************************************/

static bool translate_sentence_dict(MEMTEngine *engine, bool prepare,
				      const FrTextSpans *input,
				      FrTextSpans *lattice, ostream & /*err*/)
{
#ifdef LINK_EBMT
   if (!engine->isRemote())
      {
      if (prepare)
	 return false ;			// didn't need to prepare anything
      bool quiet = EBMT_quiet_mode(!verbose) ;
      FrObject *result = active_EBMT()->lookupDict(input) ;
      EBMT_quiet_mode(quiet) ;
      bool have_translations = false ;
      if (result && result->consp() && lattice)
	 have_translations = engine->insertArcs(lattice,(FrList*)result) ;
      else
	 free_object(result) ;
      return have_translations ;
      }
#endif /* LINK_EBMT */
   return engine->translate(prepare,input,lattice,"DICT") ;
}

//----------------------------------------------------------------------

static bool select_dictionary(MEMTEngine *engine, const char *dictname)
{
   if (engine->usingDataFile())
      return true ;
#ifdef LINK_EBMT
   if (!engine->isRemote())
      {
//   return active_EBMT()->selectDictionary(dictname) ;
      return true ;
      }
#endif /* LINK_EBMT */
   FrString cname(dictname) ;
   engine->sendLine("SETDICT",cname) ;
   FrObject *result = engine->readObject() ;
   bool success = (result == symOK) ;
   free_object(result) ;
   return success ;
}

//----------------------------------------------------------------------

static bool update_dictionary(MEMTEngine *engine, const FrString *src,
				const FrString *trg, const FrString *meta)
{
   size_t count = 1 ;
   if (meta && meta->stringValue() && *meta->stringValue())
      {
      int count2 = atoi(meta->stringValue()) ;
      if (count2 < 0)
	 count2 = 0 ;
      count = count2 ;
      }
   if (engine->usingDataFile())
      return true ;
#ifdef LINK_EBMT
   if (!engine->isRemote())
      {
      FrList *trglist = new FrList(trg) ;
      bool success = (src && src->stringp() &&
			add_dict_entry((FrString*)src,trglist,count,cerr)) ;
      (void)poplist(trglist) ;
      return success ;
      }
#endif /* LINK_EBMT */
   engine->stdIn() << "ADDWFWC ((" << src << ' ' << count
		   << " ("  << trg << ' ' << count << ")))" << endl ;
   FrObject *result = engine->readObject() ;
   bool success = ((FrSymbol*)result == symOK) ;
   free_object(result) ;
   return success ;
}

// end of file plebmt.cpp //
