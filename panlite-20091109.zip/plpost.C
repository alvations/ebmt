/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plpost.cpp		interface to postprocessor module	*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2004,2006,2007,2009 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "plengine.h"
#include "plproc.h"

#ifdef LINK_ALL
//#define LINK_POSTPROC
#endif /* LINK_ALL */

/************************************************************************/
/*	Forward Declarations						*/
/************************************************************************/

static bool exec_postproc(MEMTEngine *engine, const PLConfig *config,
			    const PlEngineConfig *engcfg,
			    ostream &err, bool /*run_verbosely*/) ;
static bool start_postproc_shutdown(MEMTEngine *engine) ;
static FrObject *postprocess_sentence(MEMTEngine *engine,
				      const FrList *wordlist) ;

/************************************************************************/
/*    Global variables for this module					*/
/************************************************************************/

MEMTEngine postproc_engine("Postprocessor",":POST",ET_Postproc,exec_postproc,0,
			   start_postproc_shutdown,0,0,postprocess_sentence) ;

/************************************************************************/
/*    Functions for interfacing with postprocessor			*/
/************************************************************************/

static bool exec_postproc(MEMTEngine *engine, const PLConfig *config,
			    const PlEngineConfig *engcfg,
			    ostream &err, bool run_verbosely)
{
   return engine->startEngine(config,engcfg,POSTPROC_NETWORK_FLAG,0,err,
			      run_verbosely) ;
}

//----------------------------------------------------------------------

FrObject *postprocess_sentence(MEMTEngine *engine, const FrList *wordlist)
{
#ifdef LINK_POSTPROC
   if (!engine->isRemote())
      {

      }
#endif
   FrString *raw = new FrString(wordlist) ;
   const char *rawstr = raw ? raw->stringValue() : "" ;
   engine->sendLine(rawstr) ;
   free_object(raw) ;
   char line[2*FrMAX_LINE] ;
   if (engine->readLine(line,sizeof(line)))
      return new FrString(line) ;
   else
      return 0 ;
}

//----------------------------------------------------------------------

static bool start_postproc_shutdown(MEMTEngine *engine)
{
   engine->sendLine("*EOF*") ;
   return true ;
}

// end of file plpost.cpp //

