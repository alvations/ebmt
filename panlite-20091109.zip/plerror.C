/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plerror.cpp		error handlers				*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2006,2009		*/
/*		 Ralf Brown						*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include <signal.h>
#include "plengine.h"		// for Panlite_trap_sigpipe
#include "panlite.h"
#include "plglobal.h"

/************************************************************************/
/*	Global Variables for this module				*/
/************************************************************************/

static FramepaC_error_handler orig_out_of_memory = 0 ;
static FramepaC_error_handler orig_error_handler = 0 ;
static FramepaC_error_handler orig_prog_error = 0 ;

static FrSignalHandler *sigint ;
static FrSignalHandler *sigill ;
#ifdef SIGHUP
static FrSignalHandler *sighup ;
#endif /* SIGHUP */
#ifdef SIGBUS
static FrSignalHandler *sigbus ;
#endif /* SIGBUS */

/************************************************************************/
/************************************************************************/

//----------------------------------------------------------------------

static void panlite_error(const char *message)
{
   if (Panlite_network_mode)
      {
      output_message(cerr,"ERROR","FATAL ERROR: ",message,0) ;
      output_message(cerr,"INFO","The translation engine must shut down.",0) ;
      }
   else
      {
      // call the original handler
      PlRestoreErrors() ;
      FrError(message) ;
      PlTrapErrors() ;
      }
   return ;
}

//----------------------------------------------------------------------

static void panlite_prog_error(const char *message)
{
   if (Panlite_network_mode)
      {
      output_message(cerr,"ERROR","PROGRAMMING ERROR: ",message,0) ;
      output_message(cerr,"INFO","The translation engine must shut down.",0) ;
      }
   else
      {
      // call the original handler
      PlRestoreErrors() ;
      FrProgError(message) ;
      PlTrapErrors() ;
      }
   return ;
}

//----------------------------------------------------------------------

static void panlite_out_of_memory(const char *message)
{
   if (Panlite_network_mode)
      {
      output_message(cerr,"ERROR","OUT OF MEMORY ",message,0) ;
      output_message(cerr,"INFO",
		     "The translation engine may crash at any time;",0) ;
      output_message(cerr,"INFO",
		     "please exit as soon as possible.",0) ;
      }
   else
      {
      // call the original handler
      PlRestoreErrors() ;
      FrNoMemory(message) ;
      PlTrapErrors() ;
      }
   return ;
}

//----------------------------------------------------------------------

void PlTrapErrors()
{
   orig_out_of_memory = set_out_of_memory_handler(panlite_out_of_memory) ;
   orig_error_handler = set_fatal_error_handler(panlite_error) ;
   orig_prog_error = set_prog_error_handler(panlite_prog_error) ;
   return ;
}

//----------------------------------------------------------------------

void PlRestoreErrors()
{
   set_out_of_memory_handler(orig_out_of_memory) ;
   set_fatal_error_handler(orig_error_handler) ;
   set_prog_error_handler(orig_prog_error) ;
   return ;
}

/************************************************************************/
/************************************************************************/

static void sigint_handler(int)
{
   // attempt a graceful shutdown of the child processes
   cout << "Shutting down (signal)...." << endl ;
   PlShutdownPrograms(cout,cerr) ;
   return ;
}

//----------------------------------------------------------------------

static void sigill_handler(int)
{
   static bool first = true ;
   // first time, attempt a graceful shutdown of the child processes
   if (first)
      {
      first = false ;
      FrError("illegal instruction or bus error; attempting to shut down") ;
      PlShutdownPrograms(cout,cerr) ;
      }
   else
      FrProgError("repeated illegal instruction or bus error!") ;
   return ;
}

//----------------------------------------------------------------------

void PlTrapSignals()
{
   sigint = new FrSignalHandler(SIGINT,sigint_handler) ;
   sigill = new FrSignalHandler(SIGILL,sigill_handler) ;
#ifdef SIGHUP
   sighup = new FrSignalHandler(SIGHUP,sigint_handler) ;
#endif /* SIGHUP */
#ifdef SIGBUS
   sigbus = new FrSignalHandler(SIGBUS,sigill_handler) ;
#endif /* SIGBUS */
   Panlite_trap_sigpipe() ;
   return ;
}

//----------------------------------------------------------------------

void PlRestoreSignals()
{
   delete sigint ;
   delete sigill ;
#ifdef SIGHUP
   delete sighup ;
#endif /* SIGHUP */
#ifdef SIGBUS
   delete sigbus ;
#endif /* SIGBUS */
   Panlite_restore_sigpipe() ;
   return ;
}

// end of file plerror.cpp //
