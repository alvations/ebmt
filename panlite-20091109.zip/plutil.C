/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plutil.cpp	general utility functions			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,2000,2001,2002,2003,2004,2006	*/
/*		 Ralf Brown						*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "plutil.h"
#include "plglobal.h"

/************************************************************************/
/************************************************************************/

void set_word_delimiters(char *&delimiter_table, const FrList *delims)
{
   if (!delims)
      return ;
   if (delims->first() && delims->first()->consp())
      delims = (FrList*)delims->first() ;
   delimiter_table = FrNewC(char,256) ;
   if (delimiter_table)
      {
      for (size_t i = 0 ; delims && i < 256 ; i++, delims = delims->rest())
	 {
	 FrObject *del = delims->first() ;
	 if (del && del->numberp() && del->intValue() > 0)
	    delimiter_table[i] = (char)1 ;
	 }
      }
   return ;
}

// end of file plutil.cpp //
