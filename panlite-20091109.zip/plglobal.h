/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plglobal.h		global variables for PanLite		*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,	*/
/*		2006,2007,2008,2009 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __PLGLOBAL_H_INCLUDED
#define __PLGLOBAL_H_INCLUDED

//----------------------------------------------------------------------

class FrRegExp ;
class PLConfig ;
class LanguageModeler ;
#if __GNUC__ < 3
class istream ;
class ostream ;
#endif /* __GNUC__ */

class MEMTGlobalVariables
   {
   public:
      double _Panlite_lattice_minscore ;
      double _Panlite_passthru_source ;
      FrSymbol *_symMORPH ;
      FrSymbol *_symOK ;
      FrSymbol *_symROOT ;
      FrSymbol *_symSTRING ;
      FrSymbol *_symWORD ;
      ostream *_current_outstream ;
      LanguageModeler *_lm ;
      char *_Panlite_chartfilename ;
      char *_Panlite_source_language ;
      char *_Panlite_target_language ;
      char *_Panlite_update_filename ;
      char *_word_delimiters ;
      char *_abbrevs_filename ;
      char **_abbrevs_list ;
      int _Panlite_languages_specified ;
      int _Panlite_lines_per_batch ;
      int _Panlite_prev_batchsize ;
      int _Panlite_linewrap_width ;
      int _curr_column ;
      size_t _freeform_maxlen ;
      ostream *_chartfile ;
      FrRegExp *_preproc_regex_list ;
      bool _Panlite_batch_mode;
      bool _Panlite_network_mode ;
      bool _Unicode_bswap ;
      bool _conserve_memory ;
      bool _freeform_input ;
      bool _xml_input ;
      bool _no_input_yet ;
      bool _keep_empty_lines ;
      bool _generate_lattice ;
      bool _generate_IBM_XML ;
      bool _gloss_overrides_dict ;
      bool _interactive_Panlite ;
      bool _preparing_for_doc ;
      bool _allow_colon_commands ;
      bool _output_chart_alignment ;
      bool _output_arc_origin ;
      bool _lattice_lists_source ;
      bool _lattice_in_transducer_format ;
      bool _lattice_in_smtstub_format ;
      bool _show_Panlite_memusage ;
      bool _showmem ;
      bool _verbose ;
      bool _quiet_mode ;
      bool _use_morph ;
      bool _uppercase_morph ;
      bool _morph_global_info ;
      bool _morph_replace_text ;
      FrList *_morph_classes ;
      FrList *_alternative_genres ;
      FrList *_curr_alternative_genre ;
      char * _morph_intro_str ;
      char * _morph_assign_str ;
      char * _morph_separator_str ;
      FrList *_prepared_doc ;
      FrStruct *_pending_metadata ;
      FrCharEncoding _char_encoding ;
      FrNamedEntitySpec *_named_entity_spec ;
      size_t _stats__sentences_translated ;
   public: // methods
      MEMTGlobalVariables() ;
      MEMTGlobalVariables(const MEMTGlobalVariables &) ;
      ~MEMTGlobalVariables() ;
      void freeVariables() ;

      void applyConfiguration(const PLConfig *config) ;
      MEMTGlobalVariables *select() ;
   } ;
#endif /* !__PLGLOBAL_H_INCLUDED */

//----------------------------------------------------------------------

extern MEMTGlobalVariables memt_vars ;

/************************************************************************/
/************************************************************************/

#define current_outstream	memt_vars._current_outstream
#define Panlite_batch_mode 	memt_vars._Panlite_batch_mode
#define Panlite_chartfilename 	memt_vars._Panlite_chartfilename
#define Panlite_lattice_minscore memt_vars._Panlite_lattice_minscore
#define Panlite_passthru_source memt_vars._Panlite_passthru_source
#define Panlite_languages_specified memt_vars._Panlite_languages_specified
#define Panlite_lines_per_batch memt_vars._Panlite_lines_per_batch
#define Panlite_prev_batchsize  memt_vars._Panlite_prev_batchsize
#define Panlite_linewrap_width 	memt_vars._Panlite_linewrap_width
#define Panlite_network_mode 	memt_vars._Panlite_network_mode
#define Panlite_source_language memt_vars._Panlite_source_language
#define Panlite_target_language memt_vars._Panlite_target_language
#define Panlite_update_filename memt_vars._Panlite_update_filename
#define abbrevs_filename	memt_vars._abbrevs_filename
#define abbrevs_list		memt_vars._abbrevs_list
#define word_delimiters		memt_vars._word_delimiters
#define Unicode_bswap 		memt_vars._Unicode_bswap
#define conserve_memory		memt_vars._conserve_memory
#define chartfile 		memt_vars._chartfile
#define curr_column		memt_vars._curr_column
#define preproc_regex_list	memt_vars._preproc_regex_list
#define freeform_maxlen		memt_vars._freeform_maxlen
#define freeform_input		memt_vars._freeform_input
#define xml_input		memt_vars._xml_input
#define no_input_yet		memt_vars._no_input_yet
#define keep_empty_lines	memt_vars._keep_empty_lines
#define generate_lattice 	memt_vars._generate_lattice
#define generate_IBM_XML 	memt_vars._generate_IBM_XML
#define gloss_overrides_dict 	memt_vars._gloss_overrides_dict
#define interactive_Panlite 	memt_vars._interactive_Panlite
#define allow_colon_commands	memt_vars._allow_colon_commands
#define output_chart_alignment	memt_vars._output_chart_alignment
#define output_arc_origin	memt_vars._output_arc_origin
#define lattice_lists_source 	memt_vars._lattice_lists_source
#define lattice_in_transducer_format 	memt_vars._lattice_in_transducer_format
#define lattice_in_smtstub_format 	memt_vars._lattice_in_smtstub_format
#define show_Panlite_memusage 	memt_vars._show_Panlite_memusage
#define showmem			memt_vars._showmem
#define symMORPH 		memt_vars._symMORPH
#define symOK 			memt_vars._symOK
#define symROOT 		memt_vars._symROOT
#define symSTRING 		memt_vars._symSTRING
#define symWORD			memt_vars._symWORD
#define verbose 		memt_vars._verbose
#define quiet_mode		memt_vars._quiet_mode
#define morph_intro_str		memt_vars._morph_intro_str
#define morph_assign_str	memt_vars._morph_assign_str
#define morph_separator_str	memt_vars._morph_separator_str
#define morph_global_info	memt_vars._morph_global_info
#define morph_replace_text	memt_vars._morph_replace_text
#define morph_classes		memt_vars._morph_classes
#define alternative_genres	memt_vars._alternative_genres
#define curr_alternative_genre	memt_vars._curr_alternative_genre
#define preparing_for_doc	memt_vars._preparing_for_doc
#define prepared_doc		memt_vars._prepared_doc
#define pending_metadata	memt_vars._pending_metadata
#define use_morph		memt_vars._use_morph
#define uppercase_morph		memt_vars._uppercase_morph
#define named_entity_spec	memt_vars._named_entity_spec
#define sentences_translated	memt_vars._stats__sentences_translated
#define char_encoding		memt_vars._char_encoding

#define active_lm		memt_vars._lm

// end of file plglobal.h //

