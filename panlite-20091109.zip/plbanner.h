/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 1.34							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plbanner.cpp							*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,1999,2000,2001,2003 Ralf Brown	*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifdef FrSTRICT_CPLUSPLUS
#include <iostream>
#else
#include <iostream.h>
#endif /* FrSTRICT_CPLUSPLUS */

void display_banner(ostream &out) ;
void welcome_message(ostream &out) ;
void goodbye_message(ostream &out) ;

// end of file plbanner.h //


