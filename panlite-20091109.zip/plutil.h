/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plutil.h	general utility functions			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,2001,2002,2003,2006 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __PLUTIL_H_INCLUDED
#define __PLUTIL_H_INCLUDED

#include "FramepaC.h"

//----------------------------------------------------------------------

#ifndef EXIT_SUCCESS
#define EXIT_SUCCESS 0
#endif

#ifndef EXIT_FAILURE
#define EXIT_FAILURE 127
#endif

//----------------------------------------------------------------------

void set_word_delimiters(char *&delimiter_table, const FrList *delims) ;

#endif /* !__PLUTIL_H_INCLUDED */

// end of file plutil.h //
