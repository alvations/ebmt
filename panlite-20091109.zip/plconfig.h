/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plconfig.h							*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2009 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __PLCONFIG_H_INCLUDED
#define __PLCONFIG_H_INCLUDED

#include "FramepaC.h"

//-----------------------------------------------------------------------

#define PL_VERBOSE		0x0001
#define PL_FREEFORM         	0x0002
#define PL_MINMEM	        0x0004

#define PL_BYTESWAP	        0x0010

#define PL_GENCHART	        0x0400
#define PL_CHARTWALK	        0x0800
#define PL_TRANSDUCER		0x1000
#define PL_SMTSTUB		0x2000
#define PL_SHOWALIGN		0x4000
#define PL_SHOWORIGIN		0x8000
#define PL_IBMXML	       0x10000

#define PL_IGNORE_EMPTY	       0x20000

#define PL_UPPERCASE_MORPH    0x100000
#define PL_GLOBAL_MORPH	      0x200000  // always put morph tag in catchall
#define PL_KEEP_UNMORPHED     0x400000
#define PL_USE_MORPH	      0x800000 // use morphology information // ABP

//-----------------------------------------------------------------------

#define PLE_ENABLED		0x0001  // engine is enabled
#define PLE_ORIGIN1		0x0002  // arcs start counting at 1, not 0
#define PLE_UPDATEABLE		0x0004  // engine can learn at runtime
#define PLE_REMOTE		0x0008  // engine is on a remote machine
#define PLE_FORCESTART		0x0010  // start engine even if disabled

//-----------------------------------------------------------------------

// note: the order of the following enum must match the definition for
//  PlEngineConfig's Type: parameter in plconfig.C
enum PlEType
   {
   PlEType_Internal = 0,
   PlEType_External,
   PlEType_File
   } ;

//-----------------------------------------------------------------------

class PlEngineConfig : public FrConfiguration
   {
   private: // data
      static FrConfigurationTable engine_def[] ;
      PlEngineConfig *m_next ;
      FrSymbol *m_tag ;
      int   m_engtype ;
      char *m_name ;
      char *m_host ;
      char *m_cfg ;
      char *m_init ;
      char *m_prog ;
      long int m_socket ;
      long int m_flags ;
      int last_local_var ;	// must follow all other data members
   private: // methods
   public: // methods
      PlEngineConfig(const char *name, FrSymbol *eng_tag = 0)
          { m_tag = eng_tag ; m_name = FrDupString(name) ;
	    m_cfg = m_prog = m_host = m_init = 0 ;
	    m_socket = -1 ; m_engtype = 0 ; m_flags = 0 ; m_next = 0 ; }
      ~PlEngineConfig()
	  { FrFree(m_name) ; FrFree(m_cfg) ; FrFree(m_prog) ; FrFree(m_host) ;
	    FrFree(m_init) ; }

      // FrConfiguration support
      virtual void init() ;
      virtual void resetState() ;
      virtual size_t lastLocalVar() const ;
      virtual bool onChange(FrConfigVariableType, void *where) ;
      virtual ostream &dump(ostream &output) const ;

      // manipulators
      void setNext(PlEngineConfig *nxt) { m_next = nxt ; }
      void enable(bool en)
	 { if (en) m_flags |= PLE_ENABLED ; else m_flags &= ~PLE_ENABLED ; }
      void forceStart(bool fs)
	 { if (fs) m_flags |= PLE_FORCESTART ;
	   else m_flags &= ~PLE_FORCESTART ; }
      void updateable(bool upd)
	 { if (upd) m_flags |= PLE_UPDATEABLE ;
	   else m_flags &= ~PLE_UPDATEABLE ; }

      // accessors
      PlEngineConfig *next() const { return m_next ; }
      FrSymbol *tag() const { return m_tag ; }
      int engtype() const { return m_engtype ; }
      const char *name() const { return m_name ; }
      const char *host() const { return m_host ; }
      const char *cfg() const { return m_cfg ; }
      const char *initstring() const { return m_init ; }
      const char *prog() const { return m_prog ; }
      long int socket() const { return m_socket ; }
      long int flags() const { return m_flags ; }
      size_t origin() const { return (m_flags & PLE_ORIGIN1) ? 1 : 0 ; }

      // configuration checks
      bool isEnabled() const { return (m_flags & PLE_ENABLED) != 0 ; }
      bool isUpdateable() const { return (m_flags & PLE_UPDATEABLE) != 0 ; }
      bool isRemote() const { return (m_flags & PLE_REMOTE) != 0 ; }
      bool forceStart() const { return (m_flags & PLE_FORCESTART) != 0 ; }
      bool isInternal() const { return m_engtype == PlEType_Internal ; }
      bool isExternal() const { return m_engtype == PlEType_External ; }
      bool isDataFile() const { return m_engtype == PlEType_File ; }
      
      // manipulators
   } ;

//-----------------------------------------------------------------------

class PLConfig : public FrConfiguration
   {
   public:
      unsigned long options ;
      PlEngineConfig *engines ;
      char *char_enc ;
      char *preproc_regex ;		// filename
      char *remote_exec ;
      char *updates ;
      char *sourcelang ;
      char *targetlang ;
      char *ne_spec ;
      FrList *engine_names ;
      FrList *word_delim ;
      FrList *nonbrk_abbr ;
      long int socketnum ;
      int last_local_var ;	// must follow all other data members
   private:
      static FrConfigurationTable PL_def[] ;
   public: // methods
      PLConfig(const char *base_dir) : FrConfiguration(base_dir) {}
      virtual void init() ;
      virtual void resetState() ;
      virtual size_t lastLocalVar() const ;
      virtual bool onChange(FrConfigVariableType, void *where) ;
      virtual ~PLConfig() ;
      virtual ostream &dump(ostream &output) const ;
   } ;

#endif /* !__PLCONFIG_H_INCLUDED */

PlEngineConfig *PlFindEngineConfig(const PLConfig *config, FrSymbol *tag) ;

// end of file plconfig.h //

