/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plsmt.cpp		interface to StatMT module		*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,2000,2001,2002,2006,2009		*/
/*		 Ralf Brown						*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "plengine.h"
#include "plproc.h"
#include "plglobal.h"

/************************************************************************/
/*	Forward declarations						*/
/************************************************************************/

static bool update_SMT(MEMTEngine *engine, const FrString *src,
			 const FrString *trg, const FrString *meta) ;

/************************************************************************/
/*    Global variables for this module					*/
/************************************************************************/

MEMTEngine smt_engine("Statistical MT",":SMT",ET_Xlat,SMT_NETWORK_FLAG,0,"SMT",
			update_SMT,0) ;

/************************************************************************/
/*    Functions for interfacing with SMT				*/
/************************************************************************/

static bool update_SMT(MEMTEngine *engine, const FrString *src,
			 const FrString *trg, const FrString */*meta*/)
{
   engine->stdIn() << "XLAT (" << src << ' ' << trg << ")" << endl ;
   FrObject *result = engine->readObject() ;
   bool success = ((FrSymbol*)result == symOK) ;
   free_object(result) ;
   return success ;
}

// end of file plsmt.cpp //
