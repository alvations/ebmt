/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plsent.cpp		input-line class			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2009 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "plinput.h"
#include "plglobal.h"

/************************************************************************/
/*	Methods for class PlSentence					*/
/************************************************************************/

PlSentence::PlSentence()
{
   m_textlines = 0 ;
   init() ;
   return ;
}

//----------------------------------------------------------------------

PlSentence::PlSentence(const FrString *text)
{
   m_textlines = text ? new FrList(text->deepcopy()) : 0 ;
   init() ;
   return ;
}

//----------------------------------------------------------------------

PlSentence::PlSentence(const FrList *textlines)
{
   m_textlines = textlines ? (FrList*)textlines->deepcopy() : 0 ;
   init() ;
   return ;
}

//----------------------------------------------------------------------

void PlSentence::init()
{
   m_prefix = 0 ;
   m_suffix = 0 ;
   m_passthrough = false ;
   m_iscommand = false ;
   m_references = 0 ;
   if (m_textlines)
      {
      const FrString *line = (FrString*)m_textlines->first() ;
      m_input = new FrTextSpans(line) ;
      for (FrList *lines = m_textlines->rest() ; lines ; lines = lines->rest())
	 {
//FIXME
	 }
      }
   else
      m_input = new FrTextSpans("",char_encoding) ;
   m_output = new FrTextSpans("",char_encoding) ; //FIXME
   return ;
}

//----------------------------------------------------------------------

PlSentence::~PlSentence()
{
   free_object(m_textlines) ;	m_textlines = 0 ;
   free_object(m_references) ;	m_references = 0 ;
   FrFree(m_prefix) ;		m_prefix = 0 ;
   FrFree(m_suffix) ;		m_suffix = 0 ;
   delete m_input ;		m_input = 0 ;
   delete m_output ;		m_output = 0 ;
   return ;
}

//----------------------------------------------------------------------

void PlSentence::setReferences(const FrList *refs)
{
   free_object(m_references) ;
   m_references = refs ? (FrList*)refs->deepcopy() : 0 ;
   return ;
}

//----------------------------------------------------------------------

// end of file plsent.cpp //
