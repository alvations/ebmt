/************************************************************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 1.40							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plproc.h	   sub-process interfaces			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1995,1996,1997,1998,2001,2004 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __PLPROC_H_INCLUDED
#define __PLPROC_H_INCLUDED

#include "plconfig.h"

/************************************************************************/
/*	 Manifest constants						*/
/************************************************************************/

#define EBMT_QUIET_FLAG "-Q+"
#define EBMT_NETWORK_FLAG "-N"

#define WORST_EBMT		 4	// scores >= N*len get zero confidence

#define DICT_SCORE_OK		1.00
#define DICT_SCORE_ROOT		0.20
#define DICT_SCORE_UNTRANSLATED 0.00

#define GLOSS_NETWORK_FLAG "-N"

#define LM_BEST_TO_STDOUT_FLAG "-f-"
#define LM_CHART_TO_STDOUT_FLAG "-g=-"
#define LM_QUIET_MODE_FLAG "-Q+"
#define LM_NETWORK_FLAG "-p:"

#define KBMT_NETWORK_FLAG "-n"

#define SMT_NETWORK_FLAG "-n"

#define XFER_NETWORK_FLAG "-n"

#define SYSTRAN_NETWORK_FLAG 	"-n"
#define SYSTRAN_SCORE_OK  	1.0
#define SYSTRAN_SCORE_TIMEOUT   0.1

//#define PREPROC_NETWORK_FLAG "-n"
#define PREPROC_NETWORK_FLAG "-N"

//#define POSTPROC_NETWORK_FLAG "-n"
#define POSTPROC_NETWORK_FLAG "-N"

#define MORPH_NETWORK_FLAG "-N"

#define IGNORE_TOKEN "<ignore>"

/************************************************************************/
/************************************************************************/

// the functions for interfacing with iCelos (MORPHE)
FrList *inflect_words(const FrList *words) ;

#endif /* !__PLPROC_H_INCLUDED */

// end of file plproc.h //
