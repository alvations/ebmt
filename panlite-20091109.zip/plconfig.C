/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Lite							*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File plconfig.C		configuration file processing		*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2001,2002,2003	*/
/*		2004,2005,2006,2007,2008,2009 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "plconfig.h"
#include "plglobal.h"

#ifdef FrSTRICT_CPLUSPLUS
# include <cstdlib>
#else
# include <stdlib.h>
#endif /* FrSTRICT_CPLUSPLUS */

/************************************************************************/
/*  the parsing information for the Pangloss-Lite configuration		*/
/************************************************************************/

static FrCommandBit eng_options[] =
{
   { "ENABLED",		PLE_ENABLED,		true,  "engine is enabled" },
   { "ORIGIN1",		PLE_ORIGIN1,		false, "arcs start at 1 instead of 0" },
   { "UPDATEABLE",	PLE_UPDATEABLE,		false, "engine can learn new trnaslations" },
   { "REMOTE",		PLE_REMOTE,		false, "engine is to be run remotely" },
   { "FORCESTART",	PLE_FORCESTART,		false, "start engine even if disabled" },
   // to avoid warnings
   { "BYTESWAP",    	0,			false, "" },
   { "MINMEM",    	0,			false, "" },
   { "VERBOSE",    	0,			false, "" },
   { 0,			0,			false, "" }
} ;

#undef addr
static PlEngineConfig *dummy_config = 0 ;
#define addr(x) (void*)((char*)(&dummy_config->x) - (char*)dummy_config)

#undef fn
#define fn(x) ((FrConfigurationParser)(&PLConfig::x))

FrConfigurationTable PlEngineConfig::engine_def[] =
{
      // keyword	parsing func	storage loc		settability
      //     next state  extra-arg  default  min max
      //     description
   { "Type",		keyword,	addr(m_engtype),	FrSET_STARTUP,
		0,	0,	0,	"INTERNAL EXTERNAL FILE",	0,
		"" },
   { "Config",		filename,	addr(m_cfg),		FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
   { "Host",		cstring,	addr(m_host),		FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
   { "Init",		cstring,	addr(m_init),		FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
   { "Options",		bitflags,	addr(m_flags),		FrSET_ANYTIME,
		0,	eng_options,	0,	0,		0,
		"" },
   { "Program",		filename,	addr(m_prog),		FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
   { "Socket",		integer,	addr(m_socket),		FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
      // what to do if we reach EOF
   { 0,                 invalid, 		0,		FrSET_READONLY,
		0,	0,	0,		0,		0,
		"" },
} ;

//----------------------------------------------------------------------

static FrCommandBit pl_options[] =
{
   { "VERBOSE",     	PL_VERBOSE,		false, 	"" } ,
   { "GENERATE_CHART", 	PL_GENCHART,		false, 	"" },
   { "GENERATE_XML", 	PL_IBMXML,		false, 	"Output in IBM/Rosetta XML format instead of lattice or plain text" },
   { "CHART_WALK",  	PL_CHARTWALK,		false, 	"" },
   { "CHART_TRANSDUCER",PL_TRANSDUCER,		false, 	"" },
   { "CHART_SMTSTUB",	PL_SMTSTUB,		false, 	"" },
   { "SHOWALIGN",	PL_SHOWALIGN,		true,	"Show word-level alignments in lattice, if available" },
   { "SHOWORIGIN",	PL_SHOWORIGIN,		true,	"Show origin of translation in lattice, if available" },
   { "BYTESWAP",    	PL_BYTESWAP,		false, 	"" },
   { "FREEFORM",    	PL_FREEFORM,		false, 	"" },
   { "MINMEM",	    	PL_MINMEM,		false, 	"" },
   { "IGNORE_EMPTY",	PL_IGNORE_EMPTY,	false, 	"" },
   { "USE_MORPH",	PL_USE_MORPH,		true,   "use morphology information" }, // ABP
   { "UP_MORPH",	PL_UPPERCASE_MORPH,	true,   "force morphology info to uppercase" },
   { "GLOBAL_MORPH",	PL_GLOBAL_MORPH,	false,  "always add morphology info to catch-all class, in addition to any defined special class" },
   { "MMAP",		0,			false, 	"" },
   { "STEM_WORDS",  	0,			false, 	"(obsolete)" },
   { "STEMS_ARE_ROOTS", 0,			false, 	"(obsolete)" },
   { 0,			0,			false,	"" }
} ;

#undef addr
static PLConfig *dummy_PLConfig = 0 ;
#undef addr
#define addr(x) (void*)((char*)(&dummy_PLConfig->x) - (char*)dummy_PLConfig)

FrConfigurationTable PLConfig::PL_def[] =
{
      // keyword	parsing func	storage loc		settability
      //     next state  extra-arg  default  min max
      //     description
   { "Abbreviations",    filename, 	&abbrevs_filename,	FrSET_STARTUP,
    		0,	0,	0,		0,		0,
		"Name of file containing a list of abbreviations to which a period should remain attached" },
   { "Base-Directory",	basedir,	0,			FrSET_STARTUP,
   		0,    	0,	"+./",		0,		0,
		"" },
   { "Char-Encoding",	cstring,	addr(char_enc),		FrSET_STARTUP,
		0,	0,	"Latin-1",	0,		0,
		"" },
   { "Chart-File",	filename,     &Panlite_chartfilename,	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
   { "Engines",		list,		addr(engine_names),	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
   { "FreeForm-MaxLine",cardinal,	&freeform_maxlen,	FrSET_ANYTIME,
		0,	0,	"250",		"10",		"9999999",
		"" },
   { "Lattice-MinScore", real,	     &Panlite_lattice_minscore,	FrSET_ANYTIME,
		0,	0,	"0.000001",	"0.0",		"1.0",
		"" },
   { "LineWrap-Width",	integer,	&Panlite_linewrap_width,FrSET_ANYTIME,
		0,	0,	"0",		"40",		"99999999",
		"" },
   { "Morph-Assign", 	   cstring,	&morph_assign_str,	FrSET_ANYTIME,
		0,	0,	"=",		0,		0,
		"Character sequence which takes the role of the equal sign in TYPE=VALUE morphology information" },
   { "Morph-Intro", 	   cstring,	&morph_intro_str,	FrSET_ANYTIME,
		0,	0,	0,		0,		0,
		"Character sequence which introduces embedded morphology information" },
   { "Morph-Separator",   cstring,	&morph_separator_str,	FrSET_ANYTIME,
		0,	0,	"+",	0,		0,
		"Character sequence which separates items in embedded morphology information" },
    { "Morph-Classes",   list,		&morph_classes,		FrSET_ANYTIME,
		0,	0,	0,		0,		0,
		"Mapping from morphology tags to classes, with optional renaming of the tags if a third element is specified in the sublist" },
   { "NE-Spec",		cstring,	addr(ne_spec),		FrSET_ANYTIME,
     		0,	0,	0,		0,		0,
	   	"Format specification for tagged named entities, e.g. @%%c{%%s#%%t#%%p}" },
   { "NonBreak-Abbrev", list,		addr(nonbrk_abbr), 	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
   { "Options",		bitflags,	addr(options),	   	FrSET_ANYTIME,
		0,    pl_options,	0,	0,		0,
		"" },
   { "PassThru-Source", real,	     &Panlite_passthru_source,	FrSET_ANYTIME,
		0,	0,	"0.0",		"0.0",		"0.5",
		"" },
   { "Remote-Exec",	cstring,	addr(remote_exec),	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
   { "Socket-Number",	integer,	addr(socketnum),	FrSET_STARTUP,
		0,	0,	"-1",		"0",		"65535",
		"" },
   { "Source-Language", cstring,	addr(sourcelang),	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
   { "Source-Regex",	filename,	addr(preproc_regex),	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"Regular-expression substitutions to apply to the input text" },
   { "Target-Language", cstring,	addr(targetlang),	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
   { "Updates-File",	filename,	addr(updates),		FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
   { "Word-Delimiters",	list,		addr(word_delim),	FrSET_STARTUP,
		0,	0,	0,		0,		0,
		"" },
   { "",		invalid,	0,			FrSET_READONLY,
		0,	0,	0,		0,		0,
		"" },
      // what to do if we reach EOF
   { 0,			invalid,	0,			FrSET_READONLY,
		0,	0,	0,		0,		0,
		"" },
} ;

PLConfig *pl_config = 0 ;

/************************************************************************/
/*	Externals							*/
/************************************************************************/

void PlEnableEngines(const FrList *engines) ;
void PlUpdateableEngines(const FrList *engines) ;

/************************************************************************/
/*	Helper functions						*/
/************************************************************************/

void Panlite_set_word_delimiters(FrCharEncoding enc)
{
   char *delim = FrNewN(char,256) ;
   if (delim)
      {
      memcpy(delim,FrStdWordDelimiters(enc),256) ;
      FrFree(word_delimiters) ;
      word_delimiters = delim ;
      }
   return ;
}

//----------------------------------------------------------------------

void Panlite_clear_word_delimiters()
{
   FrFree(word_delimiters) ;
   word_delimiters = 0 ;
   return ;
}

//----------------------------------------------------------------------

PlEngineConfig *PlFindEngineConfig(const PLConfig *config, FrSymbol *tag)
{
   for (const PlEngineConfig *eng = config->engines ; eng ; eng = eng->next())
      {
      if (eng->tag() == tag)
	 return (PlEngineConfig*)eng ;
      }
   if (tag->symbolName()[0] == ':')
      {
      // try again, without the leading colon
      tag = makeSymbol(tag->symbolName()+1) ;
      }
   else
      {
      // try again, adding a leading colon
      char *name = Fr_aprintf(":%s",tag->symbolName()) ;
      tag = makeSymbol(name) ;
      FrFree(name) ;
      }
   for (const PlEngineConfig *eng = config->engines ; eng ; eng = eng->next())
      {
      if (eng->tag() == tag)
	 return (PlEngineConfig*)eng ;
      }
   return 0 ;
}

/************************************************************************/
/*	Methods for class PlEngineConfig				*/
/************************************************************************/

void PlEngineConfig::init()
{
   FrConfiguration::init() ;
   return ;
}

//-----------------------------------------------------------------------

void PlEngineConfig::resetState()
{
   curr_state = engine_def ;
   return ;
}

//-----------------------------------------------------------------------

size_t PlEngineConfig::lastLocalVar() const
{
   return (size_t)((char*)(&this->last_local_var) - (char*)this) ;
}

//-----------------------------------------------------------------------

bool PlEngineConfig::onChange(FrConfigVariableType /*vartype*/,
				void * /*where*/)
{
   // nothing to do yet
   return true ;
}

//-----------------------------------------------------------------------

ostream &PlEngineConfig::dump(ostream &output) const
{
   return dumpValues("PlEngineConfig",output) ;
}

/************************************************************************/
/*	Methods for class PLConfig					*/
/************************************************************************/

void PLConfig::init()
{
   FrConfiguration::init() ;
   engines = 0 ;
   updates = 0 ;
   return ;
}

//-----------------------------------------------------------------------

void PLConfig::resetState()
{
   curr_state = PL_def ;
   return ;
}

//-----------------------------------------------------------------------

size_t PLConfig::lastLocalVar() const
{
   return (size_t)((char*)(&this->last_local_var) - (char*)this) ;
}

//-----------------------------------------------------------------------

bool PLConfig::onChange(FrConfigVariableType /*vartype*/, void *where)
{
   if (where == &options)
      {
      verbose = (options & PL_VERBOSE) != 0 ;
      Unicode_bswap = (options & PL_BYTESWAP) != 0 ;
      generate_IBM_XML = (options & PL_IBMXML) != 0 ;
      generate_lattice = (options & PL_GENCHART) != 0 && !generate_IBM_XML ;
      lattice_lists_source = (options & PL_CHARTWALK) == 0 ;
      lattice_in_transducer_format = (options & PL_TRANSDUCER) != 0 ;
      lattice_in_smtstub_format = (options & PL_SMTSTUB) != 0 ;
      output_chart_alignment = (options & PL_SHOWALIGN) != 0 ;
      output_arc_origin = (options & PL_SHOWORIGIN) != 0 ;
      conserve_memory = (options & PL_MINMEM) != 0 ;
      freeform_input = (options & PL_FREEFORM) != 0 ;
      keep_empty_lines = (options & PL_IGNORE_EMPTY) == 0 ;
      morph_global_info = (options & PL_GLOBAL_MORPH) != 0 ;
      morph_replace_text = (options & PL_KEEP_UNMORPHED) == 0 ;
      use_morph = (options & PL_USE_MORPH) != 0 ; // ABP
      uppercase_morph = (options & PL_UPPERCASE_MORPH) != 0 ;
      FrSetMorphologyFeatures(use_morph,
			      uppercase_morph?FrUppercaseTable(char_encoding):0) ;
      }
   else if (where == &char_enc)
      {
      char_encoding = FrParseCharEncoding(char_enc) ;
      if (char_encoding == FrChEnc_Unicode)
	 cout << "Sorry, 16-bit Unicode is currently not supported" << endl ;
      Panlite_set_word_delimiters(char_encoding) ;
      }
   else if (where == &nonbrk_abbr)
      FrSetNonbreakingAbbreviations(nonbrk_abbr,char_encoding) ;
   else if (where == &morph_intro_str || where == &morph_separator_str ||
	    where == &morph_assign_str)
      FrSetMorphologyMarkers(morph_intro_str,morph_separator_str,
			     morph_assign_str) ;
   else if (where == &ne_spec)
      {
      FrFreeNamedEntitySpec(named_entity_spec) ;
      named_entity_spec = FrParseNamedEntitySpec(ne_spec,false) ;
      }
   return true ;
}

//----------------------------------------------------------------------

PLConfig::~PLConfig()
{
   freeValues() ;
   while (engines)
      {
      PlEngineConfig *eng = engines ;
      engines = engines->next() ;
      delete eng ;
      }
   return ;
}

//-----------------------------------------------------------------------

ostream &PLConfig::dump(ostream &output) const
{
   return dumpValues("PLConfig",output) ;
}

// end of file plconfig.C //
