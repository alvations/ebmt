/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmngram.cpp	abstracted n-gram language model		*/
/*  LastEdit: 09nov09							*/
/*									*/
/*  (c) Copyright 2004,2005,2006,2007,2008,2009 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmarcs.h"
#include "lmconfig.h"
#include "lmngram.h"
#include "lmpchart.h"
#include "lmglobal.h"
#include "ebmt.h"			// for EbIsGapMarker etc.
#include <math.h>

/************************************************************************/
/*    Manifest Constants for this module				*/
/************************************************************************/

/************************************************************************/
/*    Data for this module						*/
/************************************************************************/

static const char *contractions[] =
   {
    "It's", "That's", "He's", "She's", "Here's", "There's", "Where's",
    "When's", "What's", "Who's", "Why's", "Two's",
   } ;
static int num_contractions = (sizeof(contractions)/sizeof(contractions[0])) ;

static const char end_of_sentence[] = END_SENTENCE ;

static bool have_case_sensitive_model = false ;

FrAllocator *LmNGramStates::m_allocator = 0 ;

/************************************************************************/
/*	Helper functions						*/
/************************************************************************/

static void strip_accents(char *string)
{
   if (char_encoding == FrChEnc_Latin2)
      {
      for ( ; *string ; string++)
	 *string = Fr_unaccent_Latin2(*string) ;
      }
   else if (char_encoding == FrChEnc_Latin1)
      {
      for ( ; *string ; string++)
	 *string = Fr_unaccent_Latin1(*string) ;
      }
   return ;
}

//----------------------------------------------------------------------

bool LmIsNumber(const char *word)
{
   if (*word == '+' || *word == '-')
      word++ ;			// skip leading sign if present
   if (!Fr_isdigit(*word))		// must have at least one digit
      return false ;
   else
      word++ ;
   while (*word)
      {
      if (!Fr_isdigit(*word) && *word != '.' && *word != ',')
	 return false ;
      else
	 word++ ;
      }
   return true ;
}

/************************************************************************/
/************************************************************************/

LmNGramStates::LmNGramStates(LmNGramModel **models, size_t max_hist)
{
   m_models = models ;
   m_nummodels = 0 ;
   if (m_models)
      {
      m_maxhist = max_hist ;
      m_wordcount = 0 ;
      for (size_t i = 0 ; m_models[i] ; i++)
	 m_nummodels++ ;
      if (allocHistories())
	 clearHistories() ;
      }
   else
      initClear() ;
   return ;
}

//----------------------------------------------------------------------

LmNGramStates::LmNGramStates(const LmNGramStates *oldstates)
{
   if (oldstates)
      {
      m_models = oldstates->m_models ;
      m_nummodels = oldstates->m_nummodels ;
      m_maxhist = oldstates->m_maxhist ;
      m_wordcount = oldstates->m_wordcount ;
      (void)allocHistories(oldstates->m_history) ;
      }
   else
      initClear() ;
   return ;
}

//----------------------------------------------------------------------

LmNGramStates::~LmNGramStates()
{
   if (m_allocator)
      m_allocator->release(m_history) ;
   else
      FrFree(m_history) ;
   m_history = 0 ;
   m_models = 0 ;
   m_scores = 0 ;
   m_histlengths = 0 ;
   m_maxhist = 0 ;
   m_nummodels = 0 ;
   return ;
}

//----------------------------------------------------------------------

void LmNGramStates::initClear()
{
   m_models = 0 ;
   m_nummodels = 0 ;
   m_history = 0 ;
   m_histlengths = 0 ;
   m_scores = 0 ;
   m_maxhist = 0 ;
   m_wordcount = 0 ;
   return ;
}

//----------------------------------------------------------------------

void LmNGramStates::setAllocator(LmNGramModel **models, size_t max_hist)
{
   freeAllocator() ;
   if (models)
      {
      size_t num_models = 0 ;
      for (size_t i = 0 ; models[i] ; i++)
	 num_models++ ;
      size_t num_hist = num_models * (max_hist+2) ;
      size_t alloc = (num_hist*sizeof(FrNGramHistory)
		      +num_models*(sizeof(double)+sizeof(size_t))) ;
#ifdef FrAUTO_SUBALLOC
      if (alloc >= FrMAX_AUTO_SUBALLOC)
#endif
	 if (alloc <= FrBLOCKING_SIZE / 4)
	    m_allocator = new FrAllocator("ngram states",alloc) ;
      }
   return ;
}

//----------------------------------------------------------------------

void LmNGramStates::freeAllocator()
{
   delete m_allocator ;
   m_allocator = 0 ;
   return ;
}

//----------------------------------------------------------------------

bool LmNGramStates::allocHistories(void *oldhist)
{
   size_t num_hist = numModels() * (m_maxhist+2) ;
   size_t alloc = (num_hist*sizeof(FrNGramHistory)
		   +numModels()*(sizeof(double)+sizeof(size_t))) ;
   void *buf = m_allocator ? m_allocator->allocate() : FrNewN(char,alloc) ;
   m_history = (FrNGramHistory*)buf ;
   if (m_history)
      {
      m_scores = (double*)&m_history[num_hist] ;
      m_histlengths = (size_t*)&m_scores[numModels()] ;
      if (oldhist)
	 memcpy(m_history,oldhist,alloc) ;
      return true ;
      }
   else
      {
      m_scores = 0 ;
      m_histlengths = 0 ;
      return false ;
      }
}

//----------------------------------------------------------------------

void LmNGramStates::clearHistories()
{
   for (size_t i = 0 ; i < numModels() ; i++)
      {
      m_histlengths[i] = 0 ;
      FrNGramHistory *hist = history(i) ;
      hist->setIndex(LmVOCAB_WORD_NOT_FOUND) ;
      hist->setCount(model(i)->trainingSize()) ;
//      hist->setSmoothing(0.5) ;
      }
   return ;
}

//----------------------------------------------------------------------

void LmNGramStates::incrHistoryLength(size_t model_num)
{
   if (historyLength(model_num) < maxHistory())
      m_histlengths[model_num]++ ;
   return ;
}

//----------------------------------------------------------------------

void LmNGramStates::updateState(size_t model_num, LmWordID_t ID,
				size_t *max_exist, const char *surf_word)
{
   if (model_num < m_nummodels)
      {
      FrNGramHistory *hist = history(model_num) ;
      incrHistoryLength(model_num) ;
      size_t histlen = historyLength(model_num) ;
      LmNGramModel *m = model(model_num) ;
      m_scores[model_num] = m->rawProbability(hist,histlen,ID,
					      max_exist,surf_word) ;
      }
   return ;
}

//----------------------------------------------------------------------

size_t LmNGramStates::maxExist(size_t model_num) const
{
   size_t histlen = historyLength(model_num) ;
   if (histlen == 0)
      return 0 ;
   FrNGramHistory *hist = history(model_num) ;
   for (size_t i = 1 ; i <= histlen ; i++)
      {
      if (hist[i].count() == 0)
	 return i-1 ;
      }
   return histlen ;
}

/************************************************************************/
/************************************************************************/

//----------------------------------------------------------------------

void LmNGramModel::init(const char *filename, const char *sourcefile,
			double model_weight, double context_weight,
			double discount, FrSymbol *smoothing_name,
			const char *ident)
{
   m_vocab = 0 ;
   m_surfvocab = 0 ;
   m_stopwords = 0 ;
   m_index = 0 ;
   m_ngrams = 0 ;
   m_srilm = 0 ;
   m_srivcb = 0 ;
   m_sourcemodel = 0 ;
   m_sourcecover = 0.0 ;
   m_max_ngram = 0 ;
   m_model_number = 0 ;
   m_logspace = true ;
   m_contextweight = context_weight ;
   weight(model_weight) ;
   useJointProb(false) ;
   smoothing(smoothing_name) ;
   m_discount_mass = discount ;
   m_name = FrDupString(FrFileBasename(filename)) ;
   m_ident = FrDupString(ident) ;
   if (sourcefile && *sourcefile)
      {
      m_sourcemodel = LmNGramModel::newModel(sourcefile,~0,0) ;
      if (m_sourcemodel)
	 m_sourcemodel->smoothing(FrLMSmooth_None) ;
      }
   return ;
}

//----------------------------------------------------------------------

LmNGramModel::LmNGramModel(const char *filename, size_t max_ngram,
			   const char *sourcefile, const char *ident)
{
   init(filename,sourcefile,1.0,1.0,discount_mass,LM_smoothing_name,
	ident) ;
   setSentMarkers() ;
   return ;
}

//----------------------------------------------------------------------

LmNGramModel *LmNGramModel::newModel(const char *filename,
				     const char *sourcemodelfile,
				     size_t max_ngram, double weight,
				     double context_weight,
				     double discount,
				     FrSymbol *smooth_name,
				     const char *ident)
{
   if (verifyBWTSignature(filename))
      return new LmNGramModelBWT(filename, sourcemodelfile, max_ngram,
				 weight, context_weight, discount,
				 smooth_name, ident) ;
   else if (verifyNGMSignature(filename))
      return new LmNGramModelNGM(filename, sourcemodelfile, max_ngram,
				 weight, context_weight, discount,
				 smooth_name, ident) ;
   else if (verifySRISignature(filename))
      return new LmNGramModelSRILM(filename, sourcemodelfile, max_ngram,
				   weight, context_weight, discount,
				   smooth_name, ident) ;
   else
      return 0 ;
}

//----------------------------------------------------------------------

LmNGramModel *LmNGramModel::newModel(const char *filename, size_t max_ngrams,
				     const char *sourcefile, const char *ident)
{
   return newModel(filename,sourcefile,max_ngrams,1.0,1.0,discount_mass,
		   LM_smoothing_name,ident) ;
}

//----------------------------------------------------------------------

LmNGramModel *LmNGramModel::newModel(const class LModelConfig *config)
{
   if (config)
      {
      return newModel(config->modelfile,config->sourcemodel,config->max_ngram,
		      config->weight,config->context_weight,config->discount,
		      config->smoothing_name,config->name) ;
      }
   else
      return 0 ;
}

//----------------------------------------------------------------------

LmNGramModel::~LmNGramModel()
{
   FrFree(m_name) ;	m_name = 0 ;
   FrFree(m_ident) ;	m_ident = 0 ;
   if (!m_ngrams)
      {
      delete m_vocab ;
      delete m_surfvocab ;
      delete m_stopwords ;
      }
   m_vocab = 0 ;
   m_surfvocab = 0 ;
   m_stopwords = 0 ;
   delete m_index ;	m_index = 0 ;
   delete m_ngrams ;	m_ngrams = 0 ;
   delete m_sourcemodel ; m_sourcemodel = 0 ;
   m_max_ngram = 0 ;
   return ;
}

//----------------------------------------------------------------------

bool LmNGramModel::verifyBWTSignature(const char *filename)
{
   FrBWTIndex dummy ;
   return dummy.verifySignature(filename) ;
}

//----------------------------------------------------------------------

bool LmNGramModel::verifySRISignature(const char *filename)
{
   static char SRIsignature[] = "\n\\data\\\nngram" ;

   FILE *fp = fopen(filename,FrFOPEN_READ_MODE) ;
   bool success = false ;
   if (fp)
      {
      char buf[sizeof(SRIsignature)] ;
      if (fread(buf,sizeof(char),sizeof(SRIsignature),fp)
	  == sizeof(SRIsignature) &&
	  memcmp(buf,SRIsignature,sizeof(SRIsignature)-1) == 0)
	 {
	 success = true ;
	 }
      fclose(fp) ;
      }
   return success ;
}

//----------------------------------------------------------------------

void LmNGramModel::useLogSpace(bool logspace)
{
   m_logspace = logspace ;
   return ;
}

//----------------------------------------------------------------------

void LmNGramModel::smoothing(FrSymbol *sm)
{
   m_smoothing_name = sm ;
   FrParseLMSmoothingType(sm,&m_smoothing) ;
   if (ngramsFile())
      ngramsFile()->smoothing(m_smoothing) ;
   return ;
}

//----------------------------------------------------------------------

void LmNGramModel::smoothing(FrLMSmoothing sm)
{
   m_smoothing_name = 0 ;
   m_smoothing = sm ;
   if (ngramsFile())
      ngramsFile()->smoothing(m_smoothing) ;
   return ;
}

//----------------------------------------------------------------------

LmWordID_t LmNGramModel::getUnknownID() const
{
   // figure out an appropriate default value as the ID for all OOV tokens
   //   we want a value that isn't in the model but won't be mistaken
   //   for an end-of-record marker
   return LmVOCAB_WORD_NOT_FOUND ;
}

//----------------------------------------------------------------------

void LmNGramModel::setSentMarkers()
{
   m_unknown_id = getUnknownID() ;
   // if there's an explicit OOV token in the vocabulary, use it instead
   LmWordID_t unk_id = findWordID(TOKEN_UNKNOWN) ;
   if (unk_id == LmVOCAB_WORD_NOT_FOUND)
      unk_id = findWordID(TOKEN_UNKNOWN_LC) ;
   if (unk_id != LmVOCAB_WORD_NOT_FOUND)
      m_unknown_id = unk_id ;
   // now set the begin/end sentence markers
   m_begsent_sym = makeSymbol(BEGIN_SENTENCE) ;
   m_endsent_sym = makeSymbol(end_of_sentence) ;
   m_begsent_id = findWordID(BEGIN_SENTENCE) ;
   return ;
}

//----------------------------------------------------------------------

bool LmNGramModel::accumulateCoverBegin()
{
   if (!ignore_prepdoc_command)
      {
      m_sourcecover = 0.0 ;
      contextWeight(1.0) ;
      }
   return true ;
}

//----------------------------------------------------------------------

bool LmNGramModel::accumulateCover(const FrList *words)
{
   if (sourceModel() && !ignore_prepdoc_command)
      m_sourcecover += LmNGramSourceCoverage(this,words,source_cover_power) ;
   return true ;
}
   
//----------------------------------------------------------------------

bool LmNGramModel::accumulateCoverDone(double total_cover, size_t total_models)
{
   if (total_cover && total_models && !ignore_prepdoc_command)
      {
      contextWeight(m_sourcecover / total_cover * total_models) ;
      TRACE(2,(cout << "set model context weight for " << name() << " to "
	       << m_sourcecover << "/" << total_cover << " => "
	       << m_contextweight << endl)) ;
      }
   return true ;
}

//----------------------------------------------------------------------

LmWordID_t LmNGramModel::findWordID(const char *word) const
{
   if (EbIsGapMarker(word))
      return LmVOCAB_GAP_MARKER ;
   else if (sriVocab())
      return findWordID_SRI(word) ;
   else if (vocabulary())
      {
      FrSymHashTable *stem_ht = (use_word_stems && wordstem_ht
				 ? wordstem_ht : 0) ;
      bool is_poss = false ;
      const char *remapped = remapWord(word,stem_ht,is_poss,isCaseSensitive(),
				       affixSizes());
      LmWordID_t ID = vocabulary()->findID(remapped) ;
      if (ID == LmVOCAB_WORD_NOT_FOUND)
	 {
	 if (strcmp(remapped,end_of_sentence) == 0)
	    return ID ;			// use EOR if no explicit EOS in model
	 else if (is_poss)
	    ID = vocabulary()->findID(TOKEN_POSSESSIVE) ;
#ifdef MATCH_ALT_CASE
	 else if (isCaseSensitive())
	    {
	    // check in order: all-lowercase, all-caps, capitalized
	    char w[LmMAX_WORD_LENGTH+1] ;
	    strncpy(w,remapped,LmMAX_WORD_LENGTH) ;
	    w[LmMAX_WORD_LENGTH] = '\0' ;
	    Fr_strmap(w,(char*)lowercase_table) ;
	    ID = vocabulary()->findID(w) ;
	    if (ID == LmVOCAB_WORD_NOT_FOUND)
	       {
	       Fr_strupr(w,char_encoding) ;
	       ID = vocabulary()->findID(w) ;
	       if (ID == LmVOCAB_WORD_NOT_FOUND)
		  {
		  Fr_strmap(w+1,(char*)lowercase_table) ;
		  ID = vocabulary()->findID(w) ;
		  }
	       }
	    }
#endif /* MATCH_ALT_CASE */
	 // if fuzzy matching is allowed, look for unaccented version
	 //   of the word
	 if (ID == LmVOCAB_WORD_NOT_FOUND && fuzzy_match)
	    {
	    char w[LmMAX_WORD_LENGTH+1] ;
	    // check for unaccented version
	    strncpy(w,remapped,LmMAX_WORD_LENGTH) ;
	    strip_accents(w) ;
	    ID = vocabulary()->findID(w) ;
#ifdef MATCH_ALT_CASE
	    if (ID == LmVOCAB_WORD_NOT_FOUND && isCaseSensitive())
	       {
	       // check in order: all-lowercase, all-caps, capitalized
	       Fr_strmap(w,(char*)lowercase_table) ;
	       ID = vocabulary()->findID(w) ;
	       if (ID == LmVOCAB_WORD_NOT_FOUND)
		  {
		  Fr_strupr(w,char_encoding) ;
		  ID = vocabulary()->findID(w) ;
		  if (ID == LmVOCAB_WORD_NOT_FOUND)
		     {
		     Fr_strmap(w+1,(char*)lowercase_table) ;
		     ID = vocabulary()->findID(w) ;
		     }
		  }
	       }
#endif /* MATCH_ALT_CASE */
	    }
	 if (ID == LmVOCAB_WORD_NOT_FOUND && auto_rare)
	    ID = vocabulary()->findID(TOKEN_RARE) ;
	 if (ID == LmVOCAB_WORD_NOT_FOUND)
	    ID = m_unknown_id ;
	 }
      return ID ;
      }
   else
      return m_unknown_id ;
}

//----------------------------------------------------------------------

bool LmNGramModel::isStopWord(const char *word) const
{
   return (m_stopwords && m_stopwords->find(word)) ;
}

//----------------------------------------------------------------------

FrSymbol *LmNGramModel::wordForID(LmWordID_t ID) const
{
   if (vocabulary())
      {
      vocabulary()->createReverseMapping() ;
      const char *word = vocabulary()->nameForID(ID) ;
      if (word)
	 return makeSymbol(word) ;
      }
   return makeSymbol("?") ;
}

//----------------------------------------------------------------------

double LmNGramModel::freq2prob(double freq) const
{
   assertq(ngramModel() != 0) ;
   if (freq == 0.0) 
      return ngramModel()->discountMass() / ngramModel()->numIDs() ;
   else
      return freq / ngramModel()->totalMass() ;
}

//----------------------------------------------------------------------

double LmNGramModel::perplexity(size_t rank) const
{
   return -1 ;			       // unable to compute perplexity
}

//----------------------------------------------------------------------

double LmNGramModel::scaledProbability(double prob) const
{
   if (usingLogSpace())
      prob = LM_scale_factor * log(prob) ;
   else if (LM_scale_factor != 1.0)
      prob = ((LM_scale_factor * (prob - LM_scale_adjust))
	      + LM_scale_adjust) ;
   return prob ;
}

//----------------------------------------------------------------------

size_t LmNGramModel::classSize(LmWordID_t ID) const
{
      return 1 ;
}

//----------------------------------------------------------------------

size_t LmNGramModel::frequency(const LmWordID_t *IDs, size_t numwords) const
{
   return 0 ;
}

//----------------------------------------------------------------------

size_t LmNGramModel::frequency(const FrList *ngram) const
{
   if (ngram)
      {
      size_t len = ngram->simplelistlength() ;
      FrLocalAlloc(LmWordID_t,IDs,128,len) ;
      if (!IDs)
	 {
	 FrNoMemory("while allocating buffer for word IDs") ;
	 return 0 ;
	 }
      size_t count = 0 ;
      for ( ; ngram ; ngram = ngram->rest())
	 {
	 IDs[count++] = findWordID(FrPrintableName(ngram->first())) ;
	 }
      size_t freq = frequency(IDs,len) ;
      FrLocalFree(IDs) ;
      return freq ;
      }
   else
      return 0 ;
}

//----------------------------------------------------------------------

double LmNGramModel::adjustProbability(const char *surface_word,
				       LmWordID_t ID, double prob) const
{
   // adjust members of a class by their relative unigram frequency
   size_t class_size = classSize(ID) ;
   if (class_size > 1)
      {
      char cased[FrMAX_SYMBOLNAME_LEN+1] ;
      const char *mapped = surface_word ;
      if (!isCaseSensitive())
	 {
	 for (size_t i = 0 ; i < sizeof(cased) ; i++)
	    {
	    cased[i] = lowercase_table[(unsigned)(*surface_word++)] ;
	    if (!cased[i])
	       break ;
	    }
	 mapped = cased ;
	 }
      size_t surf_freq = surfaceVocabulary()->findID(mapped) ;
      if (surf_freq != FrVOCAB_WORD_NOT_FOUND)
	 {
	 size_t base_freq = frequency(&ID,1) ;
	 double avg_freq = base_freq / (double)class_size ;
	 double adj = surf_freq / avg_freq ;
	 prob *= adj ;
	 }
      }
   return prob ;
}

//----------------------------------------------------------------------

size_t LmNGramModel::longestMatch(const LmWordID_t *IDs, size_t numwords)
const
{
   return 0 ;
}

//----------------------------------------------------------------------

double LmNGramModel::rawProbability(size_t numwords, const LmWordID_t *IDs,
				    size_t *max_exist) const
{
   return 0.0 ;
}

//----------------------------------------------------------------------

double LmNGramModel::rawProbability(const LmWordID_t *IDs, size_t numwords,
				    size_t *max_exist,
				    const char *surface_word) const
{
   if (numwords > m_max_ngram)
      {
      // ignore any "excess" history
      IDs += (numwords - m_max_ngram) ;
      numwords = m_max_ngram ;
      }
   if (max_exist)
      *max_exist = 0 ;
   double prob = rawProbability(numwords,IDs,max_exist) ;
   if (adjust_class_probs && surfaceVocabulary() && surface_word && prob > 0.0)
      prob = adjustProbability(surface_word,IDs[numwords-1],prob) ;
   return prob ;
}

//----------------------------------------------------------------------

double LmNGramModel::rawProbability(size_t numwords, FrNGramHistory *hist,
				    LmWordID_t ID, size_t *max_exist) const
{
   return 0.0 ;
}

//----------------------------------------------------------------------

double LmNGramModel::rawProbability(FrNGramHistory *hist,
				    size_t numwords, LmWordID_t ID,
				    size_t *max_exist,
				    const char *surface_word) const
{
   assert(hist != 0) ;
   if (numwords > m_max_ngram)
      {
      // ignore any "excess" history
      numwords = m_max_ngram ;
      }
   if (max_exist)
      *max_exist = 0 ;
   double prob = rawProbability(numwords,hist,ID,max_exist) ;
   if (adjust_class_probs && surfaceVocabulary() && surface_word && prob > 0.0)
      prob = adjustProbability(surface_word,ID,prob) ;
   if (max_exist)
      stats__total_avg_ngram += *max_exist ;
   return prob ;
}

//----------------------------------------------------------------------

double LmNGramModel::probability(const LmWordID_t *IDs, size_t numwords,
				 size_t *max_exist,
				 const char *surface_word) const
{
   return scaledProbability(rawProbability(IDs,numwords,max_exist,
					   surface_word)) ;
}

//----------------------------------------------------------------------

double LmNGramModel::probability(FrNGramHistory *hist, size_t numwords,
				 LmWordID_t ID, size_t *max_exist,
				 const char *surface_word) const
{
   return scaledProbability(rawProbability(hist,numwords,ID,max_exist,
					   surface_word)) ;
}

//----------------------------------------------------------------------

double LmNGramModel::probability(const FrList *ngram) const
{
   if (ngram)
      {
      size_t len = ngram->simplelistlength() ;
      FrLocalAlloc(LmWordID_t,IDs,128,len) ;
      if (!IDs)
	 {
	 FrNoMemory("while allocating buffer for word IDs") ;
	 return 0.0 ;
	 }
      size_t count = 0 ;
      for ( ; ngram ; ngram = ngram->rest())
	 {
	 IDs[count++] = findWordID(FrPrintableName(ngram->first())) ;
	 }
      double prob = probability(IDs,len) ;
      FrLocalFree(IDs) ;
      return prob ;
      }
   else
      return scaledProbability(0.0) ;
}

//----------------------------------------------------------------------

void LmNGramModel::maxNgramLength(size_t len)
{ 
   if (ngramsFile() && len > ngramsFile()->maxNgramLength())
      len = ngramsFile()->maxNgramLength() ;
   m_max_ngram = len ; 
   return ;
}

//----------------------------------------------------------------------

int LmNGramModel::string2words(const char *string, char **&wordlist)
{
   const char *beg, *end ;
   int length = 0 ;
   
   beg = end = string ;
   while (*beg)
      {
      while (*end && !Fr_isspace(*end))
	 end++ ;
      length++ ;
      while (Fr_isspace(*end))
         end++ ;
      beg = end ;
      }
   wordlist = FrNewN(char*,length+1) ;
   beg = end = string ;
   int i = 0 ;
   while (*beg)
      {
      while (*end && !Fr_isspace(*end))
	 end++ ;
      int len = (int)(end-beg) ;
      char *word = FrNewN(char,len+1) ;
      memcpy(word,beg,len) ;
      word[len] = '\0' ;
      wordlist[i++] = word ;
      while (Fr_isspace(*end))
	 end++ ;
      beg = end ;
      }	 
   wordlist[length] = 0 ;
   return length ;
}

//----------------------------------------------------------------------

static bool contraction(const char *word)
{
   for (int i = 0 ; i < num_contractions ; i++)
      if (strcmp(contractions[i],word) == 0)
	 return true ;
   return false ;
}

//----------------------------------------------------------------------

double LmNGramModel::log(double x)
{
   // avoid infinities and other problems by restricting the input to be
   //  a number large enough to produce a valid logarithm
   if (x < DBL_MIN)
      x = DBL_MIN ;
   return ::log(x) ;
}

//----------------------------------------------------------------------

bool LmNGramModel::isCaseSensitive() const
{
   return true ;			// actually "don't know" for now
}

//----------------------------------------------------------------------

bool LmNGramModel::isCharBased() const
{
   return false ;			// actually "don't know" for now
}

//----------------------------------------------------------------------

bool LmNGramModel::includesSpaces() const
{
   return false ;			// actually "don't know" for now
}

//----------------------------------------------------------------------

uint8_t LmNGramModel::affixSizes() const
{
   return 0 ;
}

//----------------------------------------------------------------------

uint64_t LmNGramModel::trainingSize() const
{
   return 0 ;
}

//----------------------------------------------------------------------

const char *LmNGramModel::remapWord(const char *orig_word,
				    FrSymHashTable *stem_ht,
				    bool &is_possessive, bool is_cased,
				    uint8_t affix_sizes,
				    bool *using_affix)
{
   const char *word = orig_word ;
   int length = word ? strlen(word) : 0 ;

   if (strcmp("<end_sent>",word) == 0)
      return end_of_sentence ;

   // we want to convert Xxxx's into <possessive> unless it is one of a list of
   // common contractions, or the term is actually in the model's vocabulary
   if (length > 2 && (unsigned char)word[0] < 0x80 && Fr_isupper(word[0]) &&
       word[length-2] == '\'' && word[length-1] == 's' &&
	  !contraction(word))
	 {
	 bool ok = true ;
	 for (int i = 1 ; i < length-2 ; i++)
	    if (!Fr_isalpha(word[i]) && word[i] != '-' && word[i] != '&')
	       {
	       ok = false ;
	       break ;
	       }
	 if (ok)
	    is_possessive = true ;
	 }
   if (!is_cased)
      {
      static char str[LmMAX_WORD_LENGTH+1] ;
      strncpy(str,word,LmMAX_WORD_LENGTH) ;
      str[LmMAX_WORD_LENGTH] = '\0' ;
      Fr_strmap(str,(char*)lowercase_table) ;
      word = str ;
      }
   if (LmIsNumber(word))
      return TOKEN_NUMBER ;
#if 0
   else if (word[1] == '\0' && (word[0] == '-' || word[0] == '_'))
      return "--" ;
#endif
   else if (affix_sizes)
      {
      unsigned int prefix ;
      unsigned int suffix ;
      UNPACK_AFFIX_LENGTHS(affix_sizes,prefix,suffix) ;
      if (prefix + suffix < (unsigned)length)
	 {
	 char *affixstr = Fr_aprintf("%.*s%c%s",prefix,word,AFFIX_CHAR,
				     (word + length - suffix)) ;
	 FrSymbol *wordsym = findSymbol(affixstr) ;
	 if (!wordsym)
	    {
	    wordsym = makeSymbol(affixstr) ;
	    FrBWTMarkAsDummy(wordsym) ;
	    }
	 FrFree(affixstr) ;
	 word = wordsym->symbolName() ;
	 if (using_affix)
	    *using_affix = true ;
	 }
      }
   if (stem_ht)
      {
      FrSymbol *wordsym = findSymbol(word) ;
      if (wordsym)
	 {
	 FrSymHashEntry *entry = stem_ht->lookup(wordsym) ;
	 if (entry && entry->getUserData())
	    word = ((FrSymbol*)entry->getUserData())->symbolName() ;
	 }
      }
   return word ;
}

//----------------------------------------------------------------------

bool LmNGramModel::dump(FILE * /*outfp*/, const char * /*modelname*/,
			bool /*run_verbosely*/) const
{
   return false ;
}

//----------------------------------------------------------------------

void LmNGramModel::dumpConfig(ostream &out) const
{
   if (sectionName())
      out << "[LM-" << sectionName() << "]" << endl ;
   out << "Model-File:\t\"" << name() << '"' << endl ;
   out << "Longest-NGram:\t" << m_max_ngram << endl ;
   if (smoothingName())
      out << "Smoothing-Type:\t" << smoothingName() << endl ;
   out << "Weight:\t\t" << baseWeight() << endl ;
   out << "Context-Weight:\t" << contextWeight() << endl ;
   out << "Discount-Mass:\t" << discountMass() << endl ;
   out << "Source-Model:\t\"" ;
   if (sourceModel())
      out << sourceModel()->name() ;
   out << '"' << endl ;
   return ;
}

/************************************************************************/
/*	Methods for class LmNGramModelBWT				*/
/************************************************************************/

LmNGramModelBWT::LmNGramModelBWT(const char *filename,
				 const char *sourcemodelfile,
				 size_t max_ngram, double weight,
				 double context_weight,
				 double discount,
				 FrSymbol *smooth_name,
				 const char *ident)
{
   init(filename,sourcemodelfile,weight,context_weight,discount,
	smooth_name,ident) ;
   initBWT(filename,max_ngram,discount) ;
   setSentMarkers() ;
   return ;
}

//----------------------------------------------------------------------

void LmNGramModelBWT::initBWT(const char *filename, size_t max_ngram,
			      double discount)
{
   m_index = new FrBWTIndex(filename,allow_memmapped_model,
			    touch_all_memory) ;
   if (m_index && m_index->good())
      {
      FrFileMapping *map = m_index->mappedFile() ;
      if (map)
	 m_vocab = new FrVocabulary(map,filename,m_index->userDataOffset());
      else
	 m_vocab = new FrVocabulary(filename,m_index->userDataOffset(),true,
				    allow_memmapped_model) ;
      if (discount >= 0.0)
	 m_index->setDiscounts(discount) ;
      m_index->initClassSizes(m_vocab) ;
      if (max_ngram > m_index->numItems())
	 max_ngram = m_index->numItems() ;
      m_max_ngram = max_ngram ;
      if (m_vocab)
	 {
	 off_t offset = (m_index->userDataOffset()
			 + m_vocab->totalDataSize()) ;
	 if (map)
	    m_surfvocab = new FrVocabulary(map,filename,offset) ;
	 else
	    m_surfvocab = new FrVocabulary(filename,offset,true,
					   allow_memmapped_model) ;
	 if (m_surfvocab)
	    {
	    offset += m_surfvocab->totalDataSize() ;
	    if (map && offset < (off_t)FrMappingSize(map))
	       m_stopwords = new FrVocabulary(map,filename,offset) ;
	    else
	       m_stopwords = new FrVocabulary(filename,offset,true,
					      allow_memmapped_model) ;
	    if (m_surfvocab->numWords() == 0)
	       {
	       delete m_surfvocab ;
	       m_surfvocab = 0 ;
	       }
	    if (m_stopwords && m_stopwords->numWords() == 0)
	       {
	       delete m_stopwords ;
	       m_stopwords = 0 ;
	       }
	    }
	 }
      }
   else
      {
      delete m_index ;	m_index = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

LmWordID_t LmNGramModelBWT::getUnknownID() const
{
   // figure out an appropriate default value as the ID for all OOV tokens
   //   we want a value that isn't in the model but won't be mistaken
   //   for an end-of-record marker
   return ngramModel()->numIDs() ;
}

//----------------------------------------------------------------------

bool LmNGramModelBWT::isCaseSensitive() const
{
   return ngramModel()->wordsAreCaseSensitive() ;
}

//----------------------------------------------------------------------

bool LmNGramModelBWT::isCharBased() const
{
   return ngramModel()->indexIsCharBased() ;
}

//----------------------------------------------------------------------

bool LmNGramModelBWT::includesSpaces() const
{
   return false ;
}

//----------------------------------------------------------------------

double LmNGramModelBWT::perplexity(size_t rank) const
{
   cerr << "perplexity computation not supported for BWT models yet"
	<< endl ;
   return -1 ;
}

//----------------------------------------------------------------------

size_t LmNGramModelBWT::classSize(LmWordID_t ID) const
{
   return ngramModel()->classSize(ID) ;
}

//----------------------------------------------------------------------

size_t LmNGramModelBWT::frequency(const LmWordID_t *IDs, size_t numwords) const
{
   if (numwords > m_max_ngram)
      {
      // ignore any "excess" history
      IDs += (numwords - m_max_ngram) ;
      numwords = m_max_ngram ;
      }
   return ngramModel()->frequency(IDs,numwords) ;
}

//----------------------------------------------------------------------

size_t LmNGramModelBWT::longestMatch(const LmWordID_t *IDs,
				     size_t numwords) const
{
   if (!IDs || numwords == 0)
      return 0 ;
   return ngramModel()->longestMatch(IDs,numwords) ;
}

//----------------------------------------------------------------------

double LmNGramModelBWT::rawProbability(size_t numwords, const LmWordID_t *IDs,
				       size_t *max_exist) const
{
   if (usingJointProb())
      return freq2prob(ngramModel()->frequency(IDs,numwords)) ;
   else
      return ngramModel()->condProbability(IDs,numwords,smoothing(),0,
					   max_exist) ;
}

//----------------------------------------------------------------------

double LmNGramModelBWT::rawProbability(size_t numwords, FrNGramHistory *hist,
				       LmWordID_t ID, size_t *max_exist) const
{
   if (usingJointProb())
      return freq2prob(ngramModel()->frequency(hist,numwords,ID)) ;
   else
      return ngramModel()->condProbability(hist,numwords,ID,smoothing(),0,
					   max_exist) ;
}

//----------------------------------------------------------------------

uint8_t LmNGramModelBWT::affixSizes() const
{
//FIXME      return ngramModel()->affixSizes() ;
   return 0 ;
}

//----------------------------------------------------------------------

uint64_t LmNGramModelBWT::trainingSize() const
{
   return ngramModel()->numItems() ;
}

//----------------------------------------------------------------------

bool LmNGramModelBWT::dump(FILE * /*outfp*/, const char * /*modelname*/,
			   bool /*run_verbosely*/) const
{
   return false ;
}

/************************************************************************/
/*	Methods for class LmNGramModelNGM				*/
/************************************************************************/

LmNGramModelNGM::LmNGramModelNGM(const char *filename,
				 const char *sourcemodelfile,
				 size_t max_ngram, double weight,
				 double context_weight,
				 double discount,
				 FrSymbol *smooth_name,
				 const char *ident)
{
   init(filename,sourcemodelfile,weight,context_weight,discount,
	smooth_name,ident) ;
   initNGM(filename,max_ngram) ;
   setSentMarkers() ;
   return ;
}

//----------------------------------------------------------------------

void LmNGramModelNGM::initNGM(const char *filename, size_t max_ngram)
{
   m_ngrams = new LmNGramsFile(filename,max_ngram,
			       allow_memmapped_model,touch_all_memory) ;
   if (m_ngrams)
      {
      m_ngrams->smoothing(smoothing()) ;
      m_vocab = m_ngrams->vocabulary() ;
      m_surfvocab = m_ngrams->surfaceVocabulary() ;
      m_stopwords = m_ngrams->stopwordVocabulary() ;
      size_t maxlen = m_ngrams->maxNgramLength() ;
      if (verbose && max_ngram > maxlen)
	 cout << "; Note: Longest-NGram has been reduced to "
	      << maxlen << endl ;
      m_max_ngram = (max_ngram > maxlen) ? maxlen : max_ngram ;
      }
   return ;
}

//----------------------------------------------------------------------

LmWordID_t LmNGramModelNGM::getUnknownID() const
{
   // figure out an appropriate default value as the ID for all OOV tokens
   //   we want a value that isn't in the model but won't be mistaken
   //   for an end-of-record marker
   return ngramsFile()->vocabularySize() ;
}

//----------------------------------------------------------------------

bool LmNGramModelNGM::isCaseSensitive() const
{
   return ngramsFile()->isCaseSensitive() ;
}

//----------------------------------------------------------------------

bool LmNGramModelNGM::isCharBased() const
{
   return ngramsFile()->isCharBased() ;
}

//----------------------------------------------------------------------

bool LmNGramModelNGM::includesSpaces() const
{
   return ngramsFile()->includesSpaces() ;
}

//----------------------------------------------------------------------

double LmNGramModelNGM::perplexity(size_t rank) const
{
   bool use_entropy = false ;
   return ngramsFile()->perplexity(rank,use_entropy) ;
}

//----------------------------------------------------------------------

size_t LmNGramModelNGM::classSize(LmWordID_t ID) const
{
   return ngramsFile()->classSize(ID) ;
}

//----------------------------------------------------------------------

size_t LmNGramModelNGM::frequency(const LmWordID_t *IDs, size_t numwords) const
{
   if (numwords > m_max_ngram)
      {
      // ignore any "excess" history
      IDs += (numwords - m_max_ngram) ;
      numwords = m_max_ngram ;
      }
   return ngramsFile()->frequency(IDs,numwords) ;
}

//----------------------------------------------------------------------

size_t LmNGramModelNGM::longestMatch(const LmWordID_t *IDs,
				     size_t numwords) const
{
   if (!IDs || numwords == 0)
      return 0 ;
   return ngramsFile()->longestMatch(IDs,numwords) ;
}

//----------------------------------------------------------------------

double LmNGramModelNGM::rawProbability(size_t numwords, const LmWordID_t *IDs,
				       size_t *max_exist) const
{
   ngramsFile()->smoothing(smoothing()) ;
   return ngramsFile()->probability(IDs,numwords,max_exist) ;
}

//----------------------------------------------------------------------

double LmNGramModelNGM::rawProbability(size_t numwords, FrNGramHistory *hist,
				       LmWordID_t ID, size_t *max_exist) const
{
   ngramsFile()->smoothing(smoothing()) ;
   return ngramsFile()->probability(hist,numwords,ID,max_exist) ;
}

//----------------------------------------------------------------------

uint8_t LmNGramModelNGM::affixSizes() const
{
   return ngramsFile()->affixSizes() ;
}

//----------------------------------------------------------------------

uint64_t LmNGramModelNGM::trainingSize() const
{
   return ngramsFile()->trainingSize() ;
}

//----------------------------------------------------------------------

bool LmNGramModelNGM::dump(FILE *outfp, const char *modelname,
			   bool run_verbosely) const
{
   return ngramsFile()->dump(outfp,modelname,run_verbosely) ;
}

/************************************************************************/
/************************************************************************/

template <class T> void LmNgramScore(LmNGramModel **models, T words[],
				     size_t num_words, size_t max_ngram)
{
   if (!models || !models[0])
      return ;				// nothing to compute

   if (max_ngram == 0)
      max_ngram = max_ngram_length ;
   // start by counting how many language models we are using
   size_t num_models = 0 ;
   for (size_t i = 0 ; models[i] ; i++)
      {
      num_models++ ;
      }
   // find the first word for which the probability is not yet known; this
   //   is the first changed word, and everything from that point needs to
   //   be recalculated
   size_t start = num_words ;
   for (size_t i = 0 ; i < num_words ; i++)
      {
      if (!words[i].probabilityKnown())
	 {
	 start = i ;
	 break ;
	 }
      }
   if (start < num_words)
      {
      FrLocalAlloc(LmWordID_t*,IDs,128,num_models) ;
      FrLocalAlloc(size_t,IDcounts,2048,num_models * num_words) ;
      // first, figure out how many word IDs we have in toto
      size_t ID_count = 0 ;
      if (IDs && IDcounts)
	 {
	 for (size_t m = 0 ; m < num_models ; m++)
	    {
	    // reserve space for begsent marker if needed
	    size_t count = use_context_cues ? 1 : 0 ;
	    size_t *IDc = IDcounts + m * num_words ;
	    for (size_t w = 0 ; w < num_words ; w++)
	       {
	       if (words[w].name() != symEPSILON)
		  count += words[w].IDcount(m) ;
	       IDc[w] = count ;
	       }
	    ID_count += count ;
	    }
	 }
      FrLocalAlloc(LmWordID_t,IDs_ptr,2048,ID_count) ;
      if (!IDs || !IDcounts || !IDs_ptr)
	 {
	 FrLocalFree(IDs_ptr) ;
	 FrLocalFree(IDcounts) ;
	 FrLocalFree(IDs) ;
	 FrNoMemory("calculating n-gram score for partial sentence") ;
	 return ;
	 }
      // on the second pass, accumulate the word IDs
      double total_weight = 0.0 ;
      LmWordID_t *curr_IDs_ptr = IDs_ptr ;
      for (size_t model_num = 0 ; model_num < num_models ; model_num++)
	 {
	 IDs[model_num] = curr_IDs_ptr ;
	 if (use_context_cues)
	    *curr_IDs_ptr++ = models[model_num]->wordID_begsent() ;
	 total_weight += models[model_num]->weight() ;
	 for (size_t i = 0 ; i < num_words ; i++)
	    {
	    if (words[i].name() == symEPSILON)
	       continue ;
	    else if (!words[i].targetWord())
	       {
	       if (models[model_num]->sriModel())
		  *curr_IDs_ptr++
		     = (LmWordID_t)models[model_num]->wordID_unknown();
	       else
		  *curr_IDs_ptr++ = LmVOCAB_WORD_NOT_FOUND ;
	       }
	    else
	       {
	       for (size_t j = 1 ; j <= words[i].IDcount(model_num) ; j++)
		  *curr_IDs_ptr++ = words[i].ID(model_num,j) ;
	       }
	    }
	 }
      // finally, pass the word IDs to the ngram models
      for (size_t i = start ; i < num_words ; i++)
	 {
	 INCR_STATS(total_ngram_probs) ;
	 double rawprob = 0.0 ;
	 size_t total_max_match = 0 ;
	 const char *tword = words[i].name()->symbolName() ;
	 for (size_t model_num = 0 ; model_num < num_models ; model_num++)
	    {
	    if (models[model_num]->weight() &&
		words[i].name() != symEPSILON)
	       {
	       LmWordID_t *wordIDs = IDs[model_num] ;
	       size_t numIDs = IDcounts[model_num*num_words + i] ;
	       // if the user has set the global Longest-Ngram to less than
	       //   the current model's maximum length, shorten the list of
	       //   word IDs
	       if (numIDs > max_ngram)
		  {
		  wordIDs += (numIDs - max_ngram) ;
		  numIDs = max_ngram ;
		  }
	       // look up the probability for the sequence of word IDs
	       size_t max_exist = 0 ;
	       rawprob += (models[model_num]->rawProbability(wordIDs,numIDs,
							     &max_exist,
							     tword)
			   * models[model_num]->weight()) ;
	       total_max_match += (max_exist * max_exist * max_exist) ;
	       }
	    }
	 if (total_weight > 0.0)
	    rawprob /= total_weight ;
	 double prob = models[0]->scaledProbability(rawprob) ;
	 words[i].setProbability(prob) ;
	 words[i].setAvgNgram(total_max_match / num_models) ;
	 NTRACE(20,
		(cerr << "prob(... " << words[i].name() << ") = "
		 << setw(13) << setprecision(10) << prob << ' ')) ;
	 }
      FrLocalFree(IDs_ptr) ;
      FrLocalFree(IDcounts) ;
      FrLocalFree(IDs) ;
      }
   return ;
}

// explicit instantiation of the two variants we might actually need
//template void LmNgramScore(LmNGramModel **models, TargetWordRef words[],
//			   size_t num_words, size_t max_ngram) ;
template void LmNgramScore(LmNGramModel **models, TargetWordStats words[],
			   size_t num_words, size_t max_ngram) ;

//----------------------------------------------------------------------

template <class T> void LmNgramScore(LmNGramStates *modelstates,
				     T words[], size_t num_words,
				     size_t max_ngram)
{
   if (!modelstates)
      return ;				// nothing to compute
   if (max_ngram == 0)
      max_ngram = max_ngram_length ;
#ifdef LmUSE_SRILM
   // back off to version that doesn't use model states if using any SRI models
   for (size_t i = 0 ; i < modelstates->numModels() ; i++)
      {
      if (modelstates->model(i) && modelstates->model(i)->sriModel())
	 return LmNgramScore(modelstates->models(),words,num_words,max_ngram) ;
      }
#endif /* LmUSE_SRILM */
   // find the first word for which the probability is not yet known; this
   //   is the first changed word, and everything from that point needs to
   //   be recalculated
   size_t start = num_words ;
   for (size_t i = 0 ; i < num_words ; i++)
      {
      if (!words[i].probabilityKnown())
	 {
	 start = i ;
	 break ;
	 }
      }
   if (start < num_words)
      {
      bool restart = false ;
      if (start != modelstates->wordsProcessed())
	 restart = true ;
      size_t num_models = modelstates->numModels() ;

      // first pass, accumulate the total weights and (re)initialize histories
      //   if necessary
      double total_weight = 0.0 ;
      size_t first = start ;
      if (restart)
	 {
	 modelstates->clearHistories() ;
	 if (start > max_ngram)
	    first = start - max_ngram ;
	 else
	    first = 0 ;
	 }
      for (size_t model_num = 0 ; model_num < num_models ; model_num++)
	 {
	 LmNGramModel *m = modelstates->model(model_num) ;
	 total_weight += m->weight() ;
	 if (use_context_cues && first == 0)
	    {
	    modelstates->updateState(model_num, m->wordID_begsent()) ;
	    }
	 }
      for (size_t i = first ; i < start ; i++)
	 {
	 if (words[i].name() == symEPSILON)
	    continue ;
	 const char *tword = words[i].name()->symbolName() ;
	 for (size_t model_num = 0 ; model_num < num_models ; model_num++)
	    {
	    if (!words[i].targetWord())
	       {
	       modelstates->updateState(model_num,LmVOCAB_WORD_NOT_FOUND);
	       }
	    else
	       for (size_t j = 1 ; j <= words[i].IDcount(model_num) ; j++)
		  {
		  modelstates->updateState(model_num,
					   words[i].ID(model_num,j),0,
					   tword) ;
		  }
	    }
	 modelstates->processedWord() ;
	 }
      LmNGramModel *m0 = modelstates->model(0) ;
      for (size_t i = start ; i < num_words ; i++)
	 {
	 INCR_STATS(total_ngram_probs) ;
	 double rawprob = 0.0 ;
	 size_t total_max_match = 0 ;
	 const char *tword = words[i].name()->symbolName() ;
	 for (size_t model_num = 0 ; model_num < num_models ; model_num++)
	    {
	    LmNGramModel *m = modelstates->model(model_num) ;
	    if (m->weight() && words[i].name() != symEPSILON)
	       {
	       size_t numIDs = words[i].IDcount(model_num) ;
	       size_t max_exist = 0 ;
	       for (size_t j = 1 ; j < numIDs ; j++)
		  {
		  modelstates->updateState(model_num,words[i].ID(model_num,j),
					   0,tword) ;
		  }
	       if (numIDs > 0)
		  {
		  modelstates->updateState(model_num,
					   words[i].ID(model_num,numIDs),
					   &max_exist,tword) ;
		  }
	       else
		  max_exist = modelstates->maxExist(model_num) ;
	       rawprob += (modelstates->score(model_num) * m->weight()) ;
	       total_max_match += (max_exist * max_exist * max_exist) ;
	       }
	    }
	 modelstates->processedWord() ;
	 if (total_weight > 0.0)
	    rawprob /= total_weight ;
	 double prob = m0 ? m0->scaledProbability(rawprob) : rawprob ;
	 words[i].setProbability(prob) ;
	 if (num_models < 1)
	    num_models = 1 ;
	 words[i].setAvgNgram(total_max_match / num_models) ;
	 NTRACE(20,
		(cerr << "prob(... " << words[i].name() << ") = "
		 << setw(13) << setprecision(10) << prob << ' ')) ;
	 }
      }
   return ;
}

// explicit instantiation of the two variants we might need
template void LmNgramScore(LmNGramStates *modelstates,
			   TargetWordRef words[], size_t num_words,
			   size_t max_ngram) ;
//template void LmNgramScore(LmNGramStates *modelstates,
//			   TargetWordStats words[], size_t num_words,
//			   size_t max_ngram) ;

//----------------------------------------------------------------------

double LmNGramProbability(const LmNGramModel *model, const char **words)
{
   if (words && model)
      {
      size_t count = 0 ;
      for ( ; words[count] ; count++)
	 ;
      FrLocalAlloc(LmWordID_t,IDs,128,count) ;
      if (!IDs)
	 {
	 FrNoMemory("while allocating buffer for word IDs") ;
	 return 0.0 ;
	 }
      for (size_t i = 0 ; i < count ; i++)
	 {
	 IDs[i] = model->findWordID(words[i]) ;
	 }
      double prob = model->probability(IDs,count) ;
      FrLocalFree(IDs) ;
      return prob ;
      }
   else if (model)
      return model->scaledProbability(0.0) ;
   else
      return 0.0 ;
}

//----------------------------------------------------------------------

double LmNGramSourceCoverage(const LmNGramModel *model, const FrList *words,
			     double power)
{
   if (words && model && model->sourceModel() && power > 0.0)
      {
      size_t count = words->simplelistlength() ;
      TRACE(7,(cout << "accumulating match statistics for " << count
	            << " words, power=" << power << endl)) ;
      FrLocalAlloc(LmWordID_t,IDs,128,count) ;
      if (!IDs)
	 {
	 FrNoMemory("while allocating buffer for word IDs") ;
	 return 0.0 ;
	 }
      LmNGramModel *srcmodel = model->sourceModel() ;
      for (size_t i = 0 ; i < count ; words = words->rest(), i++)
	 {
	 IDs[i] = srcmodel->findWordID(FrPrintableName(words->first())) ;
	 }
      double cover = 0.0 ;
      for (size_t i = 0 ; i < count ; i++)
	 {
	 size_t match = srcmodel->longestMatch(IDs+1,count-i) ; ;
	 cover += ::pow(match,power) ;
	 }
      FrLocalFree(IDs) ;
      return cover ;
      }
   else
      return 0.0 ;
}

//----------------------------------------------------------------------

bool LmNgramModelWeights(LmNGramModel **models, size_t num_models,
			 const FrList *weights)
{
   bool updates = false ;
   if (models && weights)
      {
      double total_weight = 0.0 ;
      for (size_t m = 0 ; m < num_models ; m++)
	 {
	 if (!models[m])
	    continue ;
	 FrString name(models[m]->name()) ;
	 FrList *weightspec = (FrList*)weights->assoc(&name,::equal) ;
	 if (weightspec)
	    {
	    FrObject *weight = weightspec->second() ;
	    if (weight)
	       {
	       double wt = weight->floatValue() ;
	       models[m]->weight(wt) ;
	       updates = true ;
	       }
	    else
	       models[m]->weight(1.0) ;
	    }
	 else
	    models[m]->weight(1.0) ;
	 total_weight += models[m]->weight() ;
	 }
      // renormalize the model weights to sum to 1.0
      if (total_weight > 0.0)
	 {
	 for (size_t m = 0 ; m < num_models ; m++)
	    {
	    if (models[m])
	       models[m]->weight(models[m]->weight() / total_weight) ;
	    }
	 }
      }
   if (verbose)
      {
      for (size_t m = 0 ; m < num_models ; m++)
	 {
	 if (models[m])
	    cout << "; language model [" << models[m]->name()
		 << "] gets weight " << models[m]->weight() << endl ; 
	 }
      }
   return updates ;
}

//----------------------------------------------------------------------

bool LmCaseSensitiveModel(LmNGramModel const * const *models)
{
   have_case_sensitive_model = false ;
   if (models)
      {
      for (size_t i = 0 ; models[i] ; i++)
	 {
	 if (models[i]->isCaseSensitive() && models[i]->weight() > 0.0)
	    {
	    have_case_sensitive_model = true ;
	    break ;
	    }
	 }
      }
   return have_case_sensitive_model ;
}

//----------------------------------------------------------------------

bool LmCaseSensitiveModel()
{
   return have_case_sensitive_model ;
}

// end of file lmngram.cpp //
