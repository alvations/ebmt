/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmglobal.h	    Language Modeler's global variables		*/
/*  LastEdit: 04nov09    						*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2001,2002,2003	*/
/*		2004,2005,2006,2007,2008,2009 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMGLOBAL_H_INCLUDED
#define __LMGLOBAL_H_INCLUDED

#ifndef __LMGENRE_H_INCLUDED
#include "lmgenre.h"
#endif

#ifndef __LMNGRAM_H_INCLUDED
#include "lmngram.h"
#endif

/************************************************************************/
/************************************************************************/

#define TRACE(level,cmd) if (lm_vars._trace >= level) cmd ;
#define VTRACE(level,cmd) if (verbose && lm_vars._trace >= level) cmd ;

#ifdef NDEBUG
#  define NTRACE(level,cmd)
#  define NVTRACE(level,cmd)
#else
#  define NTRACE(level,cmd) if (lm_vars._trace >= level) { cmd ; }
#  define NVTRACE(level,cmd) if (verbose && lm_vars._trace >= level) { cmd ; }
#endif

#ifdef NO_LM_STATS
#define INCR_STATS(which)
#define INCR_STATS_N(which,count)
#else
#define INCR_STATS(which) 		(stats__##which++)
#define INCR_STATS_N(which,count) 	(stats__##which += (count))
#endif

#define LM_EPSILON_MARKER "<epsilon>"

/************************************************************************/
/* 	Shared Global Variables						*/
/************************************************************************/

class LMConfig ;
class TriggerWords ;
class LmNGramModel ;
class LMConfig ;

class LMGlobalVariables
   {
   public:
      LmGenreSettings *genre_list ;
      LmGenreSettings *genre ;
      LmGenreSettings *previous_genre ;
      FrList *_genre_names ;
      FrList *_engine_names ;
      FrList *_model_IDs ;
      FrThreadPool *_thread_pool ;

      double _discount_mass ;
      double _word_reinforcement_weight ;
      char *_dummy_arc_contents ;
      char *_epsilon_arc_contents ;
      char *_wordstems_filename ;
      FrSymbol *_symMORPH ;
      FrSymbol *_symNIL ;
      FrSymbol *_symSTRING ;
      FrSymbol *_symEPSILON ;
      FrSymbol *_sym_empty ;
      FrList *_skip_raw_scores ;
      FrList *_language_model_files ;
      LmNGramModel **_ngrams ;
      LMConfig *_lm_config ;		// default configuration read from file
      FrSymHashTable *_wordstem_ht ;
      double *_occurrence_bonuses ;
      size_t _language_model_count ;
      size_t _num_occurrence_bonuses ;
      size_t _best_count ;
      size_t _nbest_timeout ;
      int _LM_port_number ;
      int _rare_words_threshold ;
      size_t _trace ;
      size_t _LM_reach ;
      bool _Unicode_bswap ;
      bool _canonicalized_input_data ;
      bool _use_context_cues ;
      bool _use_joint_probabilities ;
      bool _internal_nbest ;
      bool _guarantee_nbest ;
      bool _moses_style_scoring ;
      bool _logarithmic_user_scores ;
      bool _logarithmic_context_scores ;
      bool _use_alternate_ranking ;
      bool _ignore_prepdoc_command ;
      bool _allow_memmapped_model ;
      bool _verbose ;
      bool _run_quietly ;
      bool _remove_accents ;
      bool _fuzzy_match ;
      bool _auto_rare ;
      bool _ignore_case ;
      bool _char_based_model ;
      bool _model_includes_spaces ;
      bool _adjust_class_probs ;
      bool _use_word_stems ;
      bool _complete_arc_overrides_partial ;
      bool _reorder_window_is_uncovered ;
      bool _use_multiple_stacks ;
      bool _sort_nbest_list ;
      bool _remove_nbest_dups ;
      bool _replace_nbest_dups ;
      bool _ignore_source_morphology ;
      bool _preparing_for_document ;
      bool _allow_jigsaw_combination ;
      bool _question_particle_hack ;
      bool _generate_chart ;
      bool _prettyprint_output ;
      bool _show_origins ;
      bool _show_metadata ;
      bool _touch_all_memory ;
      bool _show_coverage ;
      bool _show_overlap_stats ;
      bool _show_search_stats ;
      bool _use_byte_lengths ;
      bool _strict_gap_filler ;
      bool _show_raw_scores ;
      bool _raw_scores_in_CMERT_format ;
      FrSymbol *_smoothing_name ;
      int _nbest_dup_handling ;

      uint8_t _build_affix_sizes ;

      FrCharEncoding _char_encoding ;
      const unsigned char *_uppercase_table ;
      const unsigned char *_lowercase_table ;
      FrNamedEntitySpec *_named_entity_spec ;

      // stack-refilling control
      size_t _stack_refill_interval ;
      size_t _stack_refill_topN ;

      // chart-parsing control
      size_t _predecode_max_arcs ;
      size_t _predecode_max_len ;
      double _predecode_cutoff ;

      // statistics
      size_t _attempted_expansions ;
      size_t _expansion_collisions ;
      size_t _unable_to_cover ;
      size_t _unfillable_gaps ;
      size_t _successful_expansions ;
      size_t _reordered_expansions ;
      size_t _overlap_expansions ;
      size_t _interleaved_expansions ;
      size_t _dups_removed ;
      size_t _beam_exceeded ;
      size_t _never_inserted ;
      size_t _reorderings_used ;
      size_t _interleaves_used ;
      size_t _total_nodes_expanded ;
      size_t _total_ngram_probs ;
      size_t _total_avg_ngram ;
      size_t _total_sentences ;
   public:
      LMGlobalVariables() ;
      LMGlobalVariables(const LMGlobalVariables &) ;
      ~LMGlobalVariables() ;

      void freeVariables() ;

      bool applyConfiguration(const LMConfig *config) ;
      LMGlobalVariables *select() ;
   } ;

extern LMGlobalVariables lm_vars ;

#define thread_pool		lm_vars._thread_pool
#define ignore_case		lm_vars._ignore_case
#define build_affix_sizes	lm_vars._build_affix_sizes
#define char_based_model	lm_vars._char_based_model
#define model_includes_spaces	lm_vars._model_includes_spaces
#define adjust_class_probs	lm_vars._adjust_class_probs
#define rare_words_threshold	lm_vars._rare_words_threshold
#define use_word_stems		lm_vars._use_word_stems
#define complete_arc_overrides_partial	lm_vars._complete_arc_overrides_partial
#define reorder_window_is_uncovered	lm_vars._reorder_window_is_uncovered
#define use_multiple_stacks	lm_vars._use_multiple_stacks
#define sort_nbest_list		lm_vars._sort_nbest_list
#define remove_nbest_dups	lm_vars._remove_nbest_dups
#define replace_nbest_dups	lm_vars._replace_nbest_dups
#define nbest_dup_handling	lm_vars._nbest_dup_handling
#define trace			lm_vars._trace
#define verbose			lm_vars._verbose
#define Unicode_bswap		lm_vars._Unicode_bswap
#define char_encoding		lm_vars._char_encoding
#define uppercase_table		lm_vars._uppercase_table
#define lowercase_table		lm_vars._lowercase_table
#define canonicalized_input_data	lm_vars._canonicalized_input_data

#define LM_genre_names		lm_vars._genre_names
#define LM_engine_names		lm_vars._engine_names
#define LM_model_IDs		lm_vars._model_IDs
#define named_entity_spec	lm_vars._named_entity_spec

#define use_context_cues	lm_vars._use_context_cues
#define use_joint_probabilities	lm_vars._use_joint_probabilities
#define internal_nbest		lm_vars._internal_nbest
#define guarantee_nbest		lm_vars._guarantee_nbest
#define moses_style_scoring	lm_vars._moses_style_scoring
#define logarithmic_user_scores	lm_vars._logarithmic_user_scores
#define logarithmic_context_scores  lm_vars._logarithmic_context_scores
#define use_alternate_ranking	lm_vars._use_alternate_ranking
#define ignore_prepdoc_command	lm_vars._ignore_prepdoc_command
#define run_LM_quietly		lm_vars._run_quietly

#define	symMORPH		lm_vars._symMORPH
#define symNIL			lm_vars._symNIL
#define symSTRING		lm_vars._symSTRING
#define symEPSILON		lm_vars._symEPSILON
#define sym_empty		lm_vars._sym_empty

#define remove_accents		lm_vars._remove_accents
#define fuzzy_match		lm_vars._fuzzy_match
#define auto_rare		lm_vars._auto_rare
#define beam_width		lm_vars.genre->_beam_width
#define beam_ratio		lm_vars.genre->_beam_ratio

#define ignore_source_morphology lm_vars._ignore_source_morphology
#define strict_gap_filler	lm_vars._strict_gap_filler

#define show_raw_scores		lm_vars._show_raw_scores
#define raw_scores_in_CMERT_format lm_vars._raw_scores_in_CMERT_format
#define skip_raw_scores		lm_vars._skip_raw_scores
#define allow_jigsaw_combination lm_vars._allow_jigsaw_combination
#define question_particle_hack	lm_vars._question_particle_hack
#define LM_reach		lm_vars._LM_reach

#define interleave_penalty	lm_vars.genre->_interleave_penalty
#define discount_mass		lm_vars._discount_mass
#define word_reinforcement_weight lm_vars._word_reinforcement_weight

#define weightof_chunking	lm_vars.genre->_weightof_chunking
#define weightof_lengthbonus	lm_vars.genre->_weightof_lengthbonus
#define weightof_untrans	lm_vars.genre->_weightof_untrans
#define weightof_arcweight	lm_vars.genre->_weightof_arcweight
#define weightof_quality	lm_vars.genre->_weightof_quality
#define weightof_score		lm_vars.genre->_weightof_score
#define weightof_user		lm_vars.genre->_weightof_user
#define weightof_future		lm_vars.genre->_weightof_future
#define weightof_doccontext	lm_vars.genre->_weightof_doccontext
#define weightof_sntcontext	lm_vars.genre->_weightof_sntcontext
#define weightof_phrcontext	lm_vars.genre->_weightof_phrcontext
#define ngram_length_bonus	lm_vars.genre->_ngram_length_bonus

#define wordstems_filename	lm_vars._wordstems_filename

#define best_count		lm_vars._best_count
#define nbest_timeout		lm_vars._nbest_timeout
#define generate_chart		lm_vars._generate_chart
#define prettyprint_output	lm_vars._prettyprint_output
#define show_origins		lm_vars._show_origins
#define show_metadata		lm_vars._show_metadata
#define LM_port_number		lm_vars._LM_port_number
#define language_model_files	lm_vars._language_model_files
#define language_model_count	lm_vars._language_model_count
#define language_model_weights	lm_vars.genre->_language_model_weights

#define OOV_penalty		lm_vars.genre->_OOV_penalty

#define max_ngram_length	lm_vars.genre->_max_ngram_length

#define reorder_punct		lm_vars.genre->_reorder_punct
#define reorder_punct_eos	lm_vars.genre->_reorder_punct_eos

#define max_reorder_window	lm_vars.genre->_max_reorder_window
#define reordering_limit	lm_vars.genre->_reordering_limit
#define reordering_penalty	lm_vars.genre->_reordering_penalty

#define average_length_ratio	lm_vars.genre->_average_length_ratio
#define length_mismatch_penalty_base lm_vars.genre->_length_mismatch_penalty_base

#define max_source_overlap	lm_vars.genre->_max_source_overlap
#define max_overlap_diff	lm_vars.genre->_max_overlap_diff
#define overlap_bonus		lm_vars.genre->_overlap_bonus

#define untrans_prefix		lm_vars.genre->_untrans_prefix
#define untrans_suffix		lm_vars.genre->_untrans_suffix
#define dummy_arc_contents	lm_vars._dummy_arc_contents
#define epsilon_arc_contents	lm_vars._epsilon_arc_contents

#define occurrence_bonuses	lm_vars._occurrence_bonuses
#define num_occurrence_bonuses	lm_vars._num_occurrence_bonuses

#define use_byte_lengths	lm_vars._use_byte_lengths
#define nulltrans_value		lm_vars.genre->_nulltrans_value
#define nulltrans_logvalue	lm_vars.genre->_nulltrans_logvalue
#define insertion_penalty	lm_vars.genre->_insertion_penalty
#define allow_memmapped_model	lm_vars._allow_memmapped_model
#define touch_all_memory	lm_vars._touch_all_memory
#define show_coverage		lm_vars._show_coverage
#define show_overlap_stats	lm_vars._show_overlap_stats
#define show_search_stats	lm_vars._show_search_stats

#define lm_config		lm_vars._lm_config
#define LM_ngrams		lm_vars._ngrams
#define wordstem_ht		lm_vars._wordstem_ht

#define LM_scale_factor		lm_vars.genre->_LM_scale_factor
#define LM_scale_adjust		lm_vars.genre->_LM_scale_adjust
#define source_cover_power	lm_vars.genre->_source_cover_power

#define preparing_for_document	lm_vars._preparing_for_document

#define LM_smoothing_name	lm_vars._smoothing_name

#define stack_refill_interval	lm_vars._stack_refill_interval
#define stack_refill_topN	lm_vars._stack_refill_topN

#define predecode_cutoff	lm_vars._predecode_cutoff
#define predecode_max_arcs	lm_vars._predecode_max_arcs
#define predecode_max_len	lm_vars._predecode_max_len

#define stats__attempted_node_expansions lm_vars._attempted_expansions
#define stats__expansion_collisions      lm_vars._expansion_collisions
#define stats__unable_to_cover		 lm_vars._unable_to_cover
#define stats__unfillable_gaps		 lm_vars._unfillable_gaps
#define stats__successful_expansions     lm_vars._successful_expansions
#define stats__reordered_expansions      lm_vars._reordered_expansions
#define stats__overlap_expansions	 lm_vars._overlap_expansions
#define stats__interleaved_expansions	 lm_vars._interleaved_expansions
#define stats__dups_removed		 lm_vars._dups_removed
#define stats__beam_exceeded		 lm_vars._beam_exceeded
#define stats__never_inserted		 lm_vars._never_inserted
#define stats__reorderings_used		 lm_vars._reorderings_used
#define stats__interleaves_used		 lm_vars._interleaves_used
#define stats__total_nodes_expanded	 lm_vars._total_nodes_expanded
#define stats__total_ngram_probs	 lm_vars._total_ngram_probs
#define stats__total_avg_ngram		 lm_vars._total_avg_ngram
#define total_sentences			 lm_vars._total_sentences

//----------------------------------------------------------------------

extern int LM_trace ;

void LmSetCharEncoding(const char *char_enc) ;

#endif /* !__LMGLOBAL_H_INCLUDED */

// end of file lmglobal.h //
