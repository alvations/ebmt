/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lxngram.h	fixed-length smoothed n-gram language model	*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2006,2007,2008 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMXGRAM_H_INCLUDED
#define __LMXGRAM_H_INCLUDED

/************************************************************************/

#if COMMENT
   Format of NGrams file:
   	Header
	Array[1..maxrank] of record pointers
	Array[1..maxrank] of count-of-count records
   	Array[1..maxrank] of global discount records
   	CountID map
	Array of Unigram Records
   	Array of U32 "next" pointers for Unigrams
	N-2 times:
           Array of Ngram Records for each ngram rank
	   Array of U32 "next" pointers
	   Array of smoothing discount factors for previous rank
	Array of Ngram Records for N-grams
	Array of smoothing discount factors for (N-1)-grams
        FrVocabulary
	optional FrBWTIndex
	NOTE: everything but header and record pointers can occur in arbitrary
		order, since there are pointers in the header and pointer
	   	records

   Format of Header:
	signature "Ngram Statistics File\0"
	BYTE	file format version number (1)
	BYTE	n-gram length (maximum rank)
	BYTE	bits used for word ID in ngram record (24)
	BYTE	bits used for count ID in ngram record (16)
	BYTE	maximum count-of-counts value (8)
	BYTE	flags
	   	bit 0: model is case-sensitive (has not been lowercased)
	        bit 1: model is character-based
		bit 2: character-based model includes whitespace
		bits 3-7: reserved (0)
	LONG	number of count IDs
	U64	offset of count-ID array
	U64	offset of first count-of-counts record (for unigrams)
	U64	offset of first global discounts record (for unigrams)
	U64	total count of words used for training this model
   	U64	file offset of FrVocabulary
	U64	size of optional FrBWTIndex
	U64	offset of optional FrBWTIndex or 0
	U64	file offset of optional secondary FrVocabulary or 0
	        used to adjust predictions for members of a word class
		(maps words to additional IDs not actually present in
		 the ngram data)
	U64	file offset of optional stop-word FrVocabulary or 0
	        used to ignore all but certain terms when computing
		   probabilities, e.g. a content-word LM
	BYTE	affix sizes (0 = keep entire word,
			  else bits 7-4 = prefix chars, bits 3-0 = suffix chars)
        BYTE[7]	reserved (0)
	U64[2]	reserved (0)

   Format of record pointers record:
	LONG	number of unigram records
	LONG	number of extra unigram-only records for use in adjusting
	   	  predictions for members of a word class (default 0)
	U64	file offset of array of N-gram records
	U64	file offset of array of "next" pointers for N-grams
		each "next" pointer is a LONG; there is one more pointer than
		unigram records to simplify lookup code
	U64	file offset of array of discount values (FLOATs) for unigrams
		{optional, as it can be computed (slowly) at runtime}
	NOTE: last two elements are reserved (0) for the highest-rank n-grams,
		since there are neither continuation nor a higher rank to
		interpolate with

   Format of count-of-counts record:
	LONG[8]   counts of freq 1..7 and 8+
	LONG[8]   counts of ngrams w/ 1..7 and 8+ distinct continuations

   Format of global discounts record:
	LONG[8]   scaled discounts for count values 1..7 and 8+
		   (actual discount multiplied by 2**31)
		   (discount for count value 0 is zero by definition)

   Format of unigram record:
	LONG	unigram freq
	LONG	number of class members with wordID

   Format of Ngram Record:
	16 bits:  count ID 		{bytes 0-1}
        24 bits:  word ID 		{bytes 2-4}
    (note: older version had
      	17 bits:  count ID 		{bytes 0+1 plus high bit of byte 2}
        23 bits:  word ID 		{low 7 bits of byte 2 + bytes 3+4}
     )
#endif

/************************************************************************/
/************************************************************************/

#define LmCOUNTOFCOUNTS_MAX	8
#define LmWORDID_BITS		24	// note: older version used 23 and 17
#define LmCOUNTID_BITS		16
#define LmWORDID_MAX		((1<<LmWORDID_BITS)-1)
#define LmSIGNATURE		"Ngram Statistics File"
#define LmDISCOUNT_SCALE_FACTOR (1UL<<31)

#define IDENTITY_MAP 2048

#define NUM_DISCOUNT_LEVELS	5	// must be <= LmCOUNTOFCOUNTS_MAX

//----------------------------------------------------------------------

// bits for the "flags" field in the file header
#define NGH_CASED		1
#define NGH_CHARBASED		2
#define NGH_SPACES		4		// not implemented
//#define NGH_			8

//----------------------------------------------------------------------

struct LmNgramFileHeader
   {
   public:
      char 	m_signature[sizeof(LmSIGNATURE)] ;
      uint8_t	m_version ;
      uint8_t	m_rank ;
      uint8_t	m_wordID_bits ;
      uint8_t	m_countID_bits ;
      uint8_t	m_countofcounts_max ;
      uint8_t	m_flags ;
      uint32_t	m_num_countIDs ;
      uint64_t	m_countID_offset ;
      uint64_t	m_countofcounts_offset ;
      uint64_t	m_discounts_offset ;
      uint64_t	m_trainingsize ;
      uint64_t	m_vocab_offset ;
      uint64_t  m_sarray_size ;
      uint64_t  m_sarray_offset ;
      uint64_t  m_surfvocab_offset ;
      uint64_t  m_stopword_offset ;
      uint8_t   m_affix_sizes ;
      uint8_t   m_reserved0[7] ;
      uint64_t	m_reserved[2] ;
   public:
      LmNgramFileHeader(size_t rank = 3) ;
      bool read(FILE *fp) ;
      bool write(FILE *fp) const ;

      // accessors
      uint64_t trainingSize() const
	 { return FrLoad64(&m_trainingsize) ; }
      size_t countIDmax() const
	 { return (size_t)FrLoadLong(&m_num_countIDs) ; }
      off_t countOfCounts() const
	 { return (off_t)FrLoad64(&m_countofcounts_offset) ; }
      off_t countIDoffset() const
	 { return (off_t)FrLoad64(&m_countID_offset) ; }
      off_t globalDiscounts() const
	 { return (off_t)FrLoad64(&m_discounts_offset) ; }
      off_t vocabOffset() const
	 { return (off_t)FrLoad64(&m_vocab_offset) ; }
      off_t surfaceVocabOffset() const
	 { return (off_t)FrLoad64(&m_surfvocab_offset) ; }
      off_t stopWordOffset() const
	 { return (off_t)FrLoad64(&m_stopword_offset) ; }
      uint64_t suffArraySize() const
	 { return FrLoad64(&m_sarray_size) ; }
      off_t suffArrayOffset() const
	 { return (off_t)FrLoad64(&m_sarray_offset) ; }
      uint8_t affixSizes() const { return m_affix_sizes ; }
      bool isCaseSensitive() const { return m_flags & NGH_CASED ; }
      bool isCharBased() const { return m_flags & NGH_CHARBASED ; }
      bool includesSpaces() const { return m_flags & NGH_SPACES ; }

      // manipulators
      void setTrainingSize(uint64_t size)
	 { FrStore64(size,&m_trainingsize) ; }
      void setCountIDmax(size_t size)
	 { FrStoreLong((uint32_t)size,&m_num_countIDs) ; }
      void setCountOfCounts(off_t off)
	 { FrStore64((uint64_t)off,&m_countofcounts_offset) ; }
      void setCountIDoffset(off_t off)
	 { FrStore64((uint64_t)off,&m_countID_offset) ; }
      void setGlobalDiscounts(off_t off)
	 { FrStore64((uint64_t)off,&m_discounts_offset) ; }
      void setVocabOffset(off_t off)
	 { FrStore64((uint64_t)off,&m_vocab_offset) ; }
      void setSurfVocabOffset(off_t off)
	 { FrStore64((uint64_t)off,&m_surfvocab_offset) ; }
      void setStopWordOffset(off_t off)
	 { FrStore64((uint64_t)off,&m_stopword_offset) ; }
      void setSuffArraySize(uint64_t size)
	 { FrStore64(size,&m_sarray_size) ; }
      void setSuffArrayOffset(off_t off)
	 { FrStore64((uint64_t)off,&m_sarray_offset) ; }
      void setAffixSizes(uint8_t sizes)
	 { m_affix_sizes = sizes ; }
      void setCaseSensitive(bool cased)
	 { m_flags &= ~NGH_CASED ; if (cased) m_flags |= NGH_CASED ; }
      void setCharBased(bool cased)
	 { m_flags &= ~NGH_CHARBASED ; if (cased) m_flags |= NGH_CHARBASED ; }
      void setIncludeSpaces(bool cased)
	 { m_flags &= ~NGH_SPACES ; if (cased) m_flags |= NGH_SPACES ; }
   } ;

//----------------------------------------------------------------------

class LmRecordPointerRecord
   {
   private:
      uint32_t m_count ;
      uint32_t m_reserved ;
      uint64_t m_records ;
      uint64_t m_pointers ;
      uint64_t m_discounts ;
   public:
      LmRecordPointerRecord() ;
      bool write(FILE *fp) const ;

      // accessors
      uint32_t count() const { return FrLoadLong(&m_count) ; }
      uint64_t records() const { return FrLoad64(&m_records) ; }
      uint64_t pointers() const { return FrLoad64(&m_pointers) ; }
      uint64_t discounts() const { return FrLoad64(&m_discounts) ; }

      // modifiers
      void setCount(uint32_t count) { FrStoreLong(count,&m_count) ; }
      void setRecords(off_t offset) { FrStore64(offset,&m_records) ; }
      void setPointers(off_t offset) { FrStore64(offset,&m_pointers) ; }
      void setDiscounts(off_t offset) { FrStore64(offset,&m_discounts) ; }
   } ;

//----------------------------------------------------------------------

class LmCountMap
   {
   private:
      size_t	m_numcounts ;
      uint32_t *m_counts ;
      bool	m_allocated ;
   public:
      LmCountMap(size_t numcounts) ;
      LmCountMap(size_t numcounts, char *counts) ;
      LmCountMap(size_t numcounts, FILE *fp) ;
      ~LmCountMap() ;

      bool write(FILE *fp) const ;

      uint32_t countID(size_t count) ;
      uint32_t count(size_t countID) const ;
      size_t numCounts() const { return m_numcounts ; }
      size_t numCountsUsed() const ;
      bool OK() const { return m_counts != 0 ; }
   } ;

//----------------------------------------------------------------------

class LmCountOfCounts
   {
   private:
      uint32_t	m_freqs[LmCOUNTOFCOUNTS_MAX+1] ;
      uint32_t	m_conts[LmCOUNTOFCOUNTS_MAX+1] ;
   public:
      void *operator new(size_t, void *where) { return where ; }
      void *operator new(size_t size) { return FrMalloc(size) ; }
      void operator delete(void *blk, size_t) { FrFree(blk) ; }
      LmCountOfCounts() ;
      LmCountOfCounts(const char *data) ;
//      LmCountOfCounts(const LmCountOfCounts &orig) ;
      ~LmCountOfCounts() {}

      bool write(FILE *fp) const ;

      // accessors
      uint32_t frequency(size_t N) const
	 { return (N < LmCOUNTOFCOUNTS_MAX) ? m_freqs[N] : m_freqs[LmCOUNTOFCOUNTS_MAX] ; }
      uint32_t continuations(size_t N) const
	 { return (N < LmCOUNTOFCOUNTS_MAX) ? m_conts[N] : m_conts[LmCOUNTOFCOUNTS_MAX] ; }
      static size_t dataSize()
	 { return 2*LmCOUNTOFCOUNTS_MAX*sizeof(uint32_t) ; }

      // modifiers
      void setFrequency(size_t N, uint32_t freq)
	 { if (N > LmCOUNTOFCOUNTS_MAX) N = LmCOUNTOFCOUNTS_MAX ;
	   m_freqs[N] = freq ; }
      void incrFrequency(size_t N, uint32_t amt = 1)
	 { if (N > LmCOUNTOFCOUNTS_MAX) N = LmCOUNTOFCOUNTS_MAX ;
	   m_freqs[N] += amt ; }
      void setContinuations(size_t N, uint32_t cont)
	 { if (N > LmCOUNTOFCOUNTS_MAX) N = LmCOUNTOFCOUNTS_MAX ;
	   m_conts[N] = cont ; }
      void incrContinuations(size_t N, uint32_t amt = 1)
	 { if (N > LmCOUNTOFCOUNTS_MAX) N = LmCOUNTOFCOUNTS_MAX ;
	   m_conts[N] += amt ; }
      void clearContinuations() ;
   } ;

//----------------------------------------------------------------------

class LmNgramDiscounts
   {
   private:
      uint32_t	m_discounts[LmCOUNTOFCOUNTS_MAX] ;
   public:
      LmNgramDiscounts() ;

      bool read(FILE *fp) ;
      bool write(FILE *fp) const ;

      // accessors
      double discount(size_t N) const
	 { if (N == 0) return 0.0 ;
	   if (N > LmCOUNTOFCOUNTS_MAX) N = LmCOUNTOFCOUNTS_MAX ;
	   return (FrLoadLong(&m_discounts[N-1]) /
		   (double)LmDISCOUNT_SCALE_FACTOR) ; }

      // modifiers
      void discount(size_t N, double disc)
	 { if (N > 0 && N <= LmCOUNTOFCOUNTS_MAX)
	    FrStoreLong((uint32_t)(disc * LmDISCOUNT_SCALE_FACTOR + 0.5),
			&m_discounts[N-1]) ;
	 }
   } ;

//----------------------------------------------------------------------

class LmNgramRecord
   {
   private:
      FrBYTE    m_count[2] ;
      FrBYTE	m_wordID[3] ;
   public:
      LmNgramRecord() ;
      LmNgramRecord(size_t wordID, size_t countID = 1)
#if LmCOUNTID_BITS == 17
	 { FrStoreShort(countID>>1,m_count) ;
	   FrStoreThreebyte((wordID&0x7FFFFF)+((countID&1)<<23),m_wordID) ; }
#else
	 { FrStoreShort(countID,m_count) ;
	   FrStoreThreebyte(wordID,m_wordID) ; }
#endif
      LmNgramRecord(const LmNgramRecord &orig) ;
      ~LmNgramRecord() {}

      bool write(FILE *fp) const ;

      // accessors
#if LmCOUNTID_BITS == 17
      LmWordID_t wordID() const
	 { return FrLoadThreebyte(m_wordID) & 0x7FFFFF ; }
      LmWordCount_t wordCount() const
	 { return (FrLoadShort(m_count) << 1) + ((m_wordID&0x80)>>7) ; }
#else
      LmWordID_t wordID() const { return FrLoadThreebyte(m_wordID) ; }
      LmWordCount_t wordCount() const { return (FrLoadShort(m_count)) ; }
#endif
      uint32_t wordCount(const LmCountMap *countmap) const
	 { LmWordCount_t count = wordCount() ; 
	   return countmap ? countmap->count(count) : count ; }

      // manipulators
      void setCount(size_t countID) { FrStoreShort(countID,m_count) ; }
   } ;

#endif /* !__LMXGRAM_H_INCLUDED */

// end of file lmxgram.h //
