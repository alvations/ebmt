/************************************************************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmarcs.cpp							*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,2000,2002,2003,2004,2005,	*/
/*		2006,2007,2008,2009 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "ebmt.h"			// for EbIsGapMarker etc.
#include "lmodel.h"
#include "lmarcs.h"
#include "lmengine.h"
#include "lmpchart.h"
#include "lmglobal.h"

/************************************************************************/
/*	Global data							*/
/************************************************************************/

static char question_marker[] = "<question>" ;
			     
/************************************************************************/
/*    Global variables for class ChartArc				*/
/************************************************************************/

FrAllocator ChartArc::allocator("ChartArc",sizeof(ChartArc)) ;

static char *arc_type_names[FrBITS_PER_UINT] =
   { (char*)"none", (char*)"MERGED", (char*)"LM", 0, 0 } ;
const unsigned prealloc_arc_types = 3 ;
static unsigned num_arc_types = prealloc_arc_types ;

/************************************************************************/
/*	Helper Functions						*/
/************************************************************************/

inline size_t minimum(size_t val1, size_t val2)
{
   return val1 < val2 ? val1 : val2 ; 
}

//----------------------------------------------------------------------

inline size_t maximum(size_t val1, size_t val2)
{
   return val1 > val2 ? val1 : val2 ; 
}

//----------------------------------------------------------------------

static LmUSHORT string_length(const TargetWordRef &word)
{
   if (word.name())
      {
      const char *symname = word.name()->symbolName() ;
      return (LmUSHORT)strlen(symname) ;
      }
   else
      return 0 ;
}

//----------------------------------------------------------------------

size_t LmCountWords(const char *text)
{
   if (!text)
      return 0 ;
   size_t count = 0 ;
   while (*text)
      {
      while (*text && !Fr_isspace(*text))
	 text++ ;
      count++ ;
      while (*text && Fr_isspace(*text))
	 text++ ;
      }
   return count ;
}

//----------------------------------------------------------------------

static WordInfo *makeWordInfo(const char *source_text, size_t wc)
{ 
   if (!source_text)
      source_text = "" ;
   WordInfo *info = FrNewC(WordInfo,wc) ;
   if (info)
      {
      size_t i ;
      for (i = 0 ; i < wc && *source_text ; i++)
	 {
	 const char *end = source_text ;
	 while (*end && !Fr_isspace(*end))
	    end++ ;
	 new (&info[i]) WordInfo(source_text,end-source_text) ;
	 while (*end && Fr_isspace(*end))
	    end++ ;
	 source_text = end ;
	 }
      // ensure proper initialization when generalization has resulted in
      //   fewer words in the arc's source text than the arc spans in the
      //   original input
      for ( ; i < wc ; i++)
	 new (&info[i]) WordInfo() ;
      }
   return info ;
}

/************************************************************************/
/*    Methods for class ChartArc					*/
/************************************************************************/

void ChartArc::init()
{
   m_metadata = 0 ;
   m_chunkingbonus = 0.0 ;
   m_lengthbonus = 0.0 ;
   setScore(0.0) ;
   setQuality(0.01) ; //small but nonzero to keep log values from blowing up
   setWeight(0.0) ;
   setContextScores(0.0,0.0,0.0) ;
   setFutureUtility(0.0) ;
   setID(~0) ;
   m_successors = 0 ;
   m_numsuccessors = 0 ;
   m_subsumes = 0 ;
   m_numsubsumed = 0 ;
   target_prefix = target_suffix = 0 ;
   for (size_t i = 0 ; i < MAX_USER_SCORES ; i++)
      m_userscores[i] = 0.0 ;
   question = false ;
   has_gap_markers = false ;
   has_alignments = false ;
   has_user_scores = false ;
   m_is_successor = false ;
   m_match_wc = 0 ;
   m_source_cover = 0 ;
   return ;
}

//----------------------------------------------------------------------

ChartArc::ChartArc()
{
   init() ;
   setNext(0) ;
   m_chart = 0 ;
   source_word_info = 0 ;
   target_word_stats = 0 ;
   source_text = target_text = 0 ;
   m_models = 0 ;
   m_occurrences = 0 ;
   m_startpos = 0 ;
   m_coverage = m_arclen = 0 ;
   arctype = 1<<CE_none ;
   return ;
}

//----------------------------------------------------------------------

ChartArc::ChartArc(const ChartArc *base_arc, const ChartArc *add_arc,
		   TargetWordStats stats[], size_t num_words,
		   size_t trg_offset)
{
   TRACE(4,(cout<<"Combining arcs:\n",base_arc->dump(cout),add_arc->dump(cout)));
   init() ;
   setNext(0) ;
   // copy over all the relevant bits of the base arc
   m_chart = base_arc->chart() ;
   source_text = FrDupString(base_arc->source_text) ;
   target_text = 0 ;
   m_models = base_arc->m_models ;
   m_metadata = base_arc->m_metadata ;
   m_score = base_arc->m_score ;
   m_logscore = base_arc->m_logscore ;
   m_quality = base_arc->m_quality ;
   m_logquality = base_arc->m_logquality ;
   m_weight = base_arc->m_weight ;
   m_logweight = base_arc->m_logweight ;
   m_lengthbonus = base_arc->m_lengthbonus ;
   m_chunkingbonus = base_arc->m_chunkingbonus ;
   m_untrans = base_arc->m_untrans ;
   for (size_t i = 0 ; i < lengthof(m_userscores) ; i++)
      m_userscores[i] = base_arc->m_userscores[i] + add_arc->m_userscores[i] ;
   m_futureutility = base_arc->m_futureutility ;
   m_occurrences = base_arc->m_occurrences ;
   m_startpos = minimum(base_arc->startPosition(),add_arc->startPosition()) ;
   // add in anything relevant from the additional arc that modifies the
   //   base arc
   m_subsumes = base_arc->mergeSubsumedArcs(add_arc,m_numsubsumed,trg_offset) ;
   question = (base_arc->isQuestion() || add_arc->isQuestion()) ;
   has_gap_markers = false ;
   for (size_t i = 0 ; i < num_words ; i++)
      {
      if (stats[i].isGapMarker())
	 {
	 has_gap_markers = true ;
	 break ;
	 }
      }
   has_alignments = (base_arc->has_alignments && add_arc->has_alignments) ;
   arctype = (base_arc->arctype | add_arc->arctype) ;
   if (!m_chart)
      m_chart = add_arc->chart() ;
   assert(m_chart != 0) ;
   m_coverage = maximum(base_arc->pastEndPosition(),
			add_arc->pastEndPosition()) - m_startpos ;
   // convert character indices into word indices
   size_t start_word = m_chart->wordIndex(startPosition()) ;
   size_t base_end = m_chart->wordIndex(base_arc->pastEndPosition()) ;
   size_t add_end = m_chart->wordIndex(add_arc->pastEndPosition()) ;
   size_t base_start = m_chart->wordIndex(base_arc->startPosition()) ;
   size_t add_start = m_chart->wordIndex(add_arc->startPosition()) ;
   size_t source_span = maximum(base_end,add_end) - start_word ;
   setSourceSpan(source_span) ;
   // account for overlap
   if (add_start > base_start && add_start < base_end)
      m_coverage -= base_arc->pastEndPosition() - add_arc->startPosition() ;
   else if (base_start > add_start && base_start < add_end)
      m_coverage -= add_arc->pastEndPosition() - base_arc->startPosition() ;
   // flag the covered source words (there may be a gap between the arcs)
   allocSourceCover(source_span) ;
   source_word_info = FrNewN(WordInfo,source_span) ;
   m_match_wc = source_span ;
   for (size_t i = 0 ; i < sourceWordSpan() ; i++)
      {
      source_word_info[i].init() ;
      }
   size_t offset = base_start - start_word ;
   LmBitFlags *cov = sourceCover() ;
   for (size_t i = 0 ; i < base_end - base_start ; i++)
      {
      if (base_arc->sourceCovered(i))
	 {
	 LmSetBit(cov,i+offset) ;
	 source_word_info[i+offset] = base_arc->source_word_info[i] ;
	 }
      }
   offset = add_start - start_word ;
   for (size_t i = 0 ; i < add_end - add_start ; i++)
      {
      if (add_arc->sourceCovered(i))
	 {
	 LmSetBit(cov,i+offset) ;
	 if (source_word_info[i+offset].surface() == 0)
	    source_word_info[i+offset] = add_arc->source_word_info[i] ;
	 }
      }
   // update the source word count
   initSourceWC() ;
   // now plug in the new target text
   target_word_stats = stats ;
   m_arclen = num_words ;
   makeTargetText() ;
   TRACE(4,(cout<<"Combined arc is:\n",dump(cout),cout<<endl));
   return ;
}

//----------------------------------------------------------------------

ChartArc::ChartArc(MTEngine *engine, char *source, char *translation,
		   const FrList *alignment, size_t start, int cover,
		   const LmFeatures &features,
		   LmNGramModel **ngmodels, const FrList *morph,
		   const FrList *trg_restrict, ParseChart *chart,
		   ChartArc *nextarc)
{
   init() ;
   setNext(nextarc) ;
   (void)morph ;
   m_startpos = start ;
   arctype = engine ? (1 << engine->engineID()) : (1<<CE_none) ;
   m_coverage = cover ;
   m_occurrences = 1 ;
   setScore(features.score()) ;
   setQuality(features.quality()) ;
   setWeight(features.weight()) ;
   setDocContext(features.docContext()) ;
   setSentContext(features.sentContext()) ;
   setPhraseContext(features.phraseContext()) ;
   setFutureUtility(0.0) ;
   m_untrans = 0.0 ;
   char *src_start = source ;
   FrSkipWhitespace(src_start) ;
   source_text = FrDupString(src_start) ;
   FrFree(source) ;
   size_t words = m_source_wc = LmCountWords(source_text) ;
   setSourceSpan(words) ;
   m_models = ngmodels ;
   m_chart = chart ;
   if (chart)
      m_chunkingbonus = chart->chunkingBonus(start,start+cover) ;
   if (engine)
      {
      setWeight(this->weight() * engine->engineWeight()) ;
      m_lengthbonus
	 += LmNGramModel::log(engine->lengthBonus(sourceWordSpan())) ;
      }
   else
      {
      // this is a dummy arc
      m_untrans = LM_DUMMYARC_PENALTY * sourceWordSpan() ;
      setDecoration(untrans_prefix,untrans_suffix) ;
      }
   allocSourceCover(coverage()) ; 	// wastes a bit of space, but we don't
					//  know word boundaries yet
   if (m_source_cover)
      LmSetBits(sourceCover(),0,coverage()) ;
   source_word_info = makeWordInfo(source_text,sourceWordSpan()) ;
   if (!source_word_info)
      {
      m_match_wc = 0 ;
      FrNoMemory("while building chart arc") ;
      return ;
      }
   m_match_wc = sourceWordSpan() ;
   const char *ttext ;
   if (translation)
      {
      ttext = translation ;
      FrSkipWhitespace(ttext) ;
      }
   else
      ttext = "" ;
   char **wordlist = 0 ;
   m_arclen = LmNGramModel::string2words(ttext,wordlist) ;
   FrFree(translation) ;
   target_word_stats = FrNewN(TargetWordStats,m_arclen) ;
   size_t skipped = 0 ;
   size_t i ;
   for (i = 0 ; i < arcLength() ; i++)
      {
      if (Fr_stricmp(wordlist[i],question_marker) == 0)
	 {
	 question = true ;
	 skipped++ ;
	 }
      else
	 {
	 bool is_gap = EbIsGapMarker(wordlist[i]) ;
	 bool unk_gap = EbIsUnknownGapMarker(wordlist[i]) ;
	 // always skip gap markers with no known source alignment (we can't
	 //   deal with them), and skip all gap markers if we're not
	 //   interleaving arcs
	 if (unk_gap || (is_gap && !allow_jigsaw_combination))
	    {
	    skipped++ ;
	    FrFree(wordlist[i]) ;
	    wordlist[i] = 0 ;
	    }
	 else
	    {
	    FrSymbol *wordsym = makeSymbol(wordlist[i]) ;
	    TargetWord *tw = new TargetWord(models(),wordsym,this) ;
	    target_word_stats[i-skipped].init(tw,this) ;
	    if (is_gap)
	       has_gap_markers = true ;
	    if (is_gap && EbIsEmbeddedGapMarker(wordlist[i]))
	       {
	       size_t loc = EbGapFillerLocation(wordlist[i],0,0) ;
	       if (loc != 0 && loc < coverage() && sourceCovered(loc))
		  {
		  LmClearBit(sourceCover(),loc) ; // not actually covered!
		  if (m_source_wc > 0)
		     m_source_wc-- ;
		  }
	       }
	    }
	 }
      }
   // ensure proper initialization of all elements, especially those not used
   for (i = 1 ; i <= skipped ; i++)
      target_word_stats[arcLength()-i].init(0,0) ;
   // ensure that target_text is consistent with what actually got put into
   //   the ChartArcElts
   if (arcLength() == skipped && skipped > 0)
      {
      skipped-- ;			// want length == 1 after sub. skipped
      TargetWord *tw = new TargetWord(models(),sym_empty,this) ;
      target_word_stats[0].init(tw,this) ;
      target_text = FrDupString("") ;
      }
   else
      {
      size_t i ;
      size_t len = 0 ; 
      for (i = 0 ; i < arcLength() ; i++)
	 {
	 if (wordlist[i])
	    len += strlen(wordlist[i]) + 1 ;
	 }
      target_text = FrNewN(char,len+1) ;
      if (target_text)
	 {
	 target_text[0] = '\0' ;
	 char *targ = target_text ;
	 for (i = 0 ; i < arcLength() ; i++)
	    {
	    if (wordlist[i])
	       {
	       strcpy(targ,wordlist[i]) ;
	       targ = strchr(targ,'\0') ;
	       *targ++ = ' ' ;
	       }
	    }
	 if (targ != target_text)
	    targ[-1] = '\0' ;		// properly terminate string
	 }
      }
   // release the list of individual words
   for (size_t j = 0 ; j < arcLength() ; j++)
      FrFree(wordlist[j]) ;
   FrFree(wordlist) ;      
   m_arclen -= skipped ;
   if (alignment)
      {
      // alignment information is, for each target word, a list of all source
      //   words contributing to that target word
      for (i=0 ; alignment && i<arcLength() ; i++, alignment=alignment->rest())
	 {
	 TargetWord *tw = target_word_stats[i].targetWord() ;
	 if (tw)
	    tw->setSourceWords((FrList*)alignment->first()) ;
	 }
      has_alignments = true ;
      }
   else
      {
      // if no explicit alignment information, just set the source words
      //   that give rise to each target word to simply be every source
      //   word covered by the arc
      size_t end = startPosition() + coverage() - 1 ;
      for (i = 0 ; i < arcLength() ; i++)
	 {
	 TargetWord *tw = target_word_stats[i].targetWord() ;
	 if (tw)
	    tw->setSourceWords(startPosition(),end) ;
	 }
      }
   if (trg_restrict)
      {
      // add in target-word classes that restrict gap-filler matching
      //  restriction info is, for each target word, a list of all acceptable
      //  matching classes (FIXME: for now, only first element is used)
      for (i = 0 ;
	   trg_restrict && i < arcLength() ; 
	   i++, trg_restrict=trg_restrict->rest())
	 {
	 const FrObject *restrict = trg_restrict->first() ;
	 if (restrict && restrict->consp())
	    restrict = ((FrList*)restrict)->first() ;
	 const char *rest_name = FrPrintableName(restrict) ;
	 if (rest_name)
	    {
	    TargetWord *tw = target_word_stats[i].targetWord() ;
	    if (tw)
	       tw->setMatchClass(makeSymbol(rest_name)) ;
	    }
	 }
      }
   // check whether this is an untranslated arc
   if (engine && arcLength() == sourceWordSpan())
      {
      bool untranslated = arcLength() ? true : false ;
      for (size_t j = 0 ; j < arcLength() ; j++)
	 {
	 const char *w = source_word_info[j].surface() ;
	 const FrSymbol *sym = nthWord(j) ;
	 if (w && sym && Fr_stricmp(sym->symbolName(),w,lowercase_table) != 0)
	    {
	    untranslated = false ;
	    break ;
	    }
	 }
      if (untranslated)
	 m_untrans = LmNGramModel::log(engine->untranslatedPenalty()) ;
      }
   else if (!engine && arcLength() == 0)
      m_untrans += LM_DUMMYARC_PENALTY ; // bias against eliding untrans text
   // update the untranslated-penalty
   if (m_untrans)
      {
      for (size_t i = 0 ; i < arcLength() ; i++)
	 target_word_stats[i].setUntransPenalty(untransPenalty()) ;
      }
   return ;
}

//----------------------------------------------------------------------

ChartArc::~ChartArc()
{
   FrFree(source_text) ;	source_text = 0 ;
   FrFree(target_text) ;	target_text = 0 ;
   FrFree(target_prefix) ;	target_prefix = 0 ;
   FrFree(target_suffix) ;	target_suffix = 0 ;
   FrFree(m_successors) ;	m_successors = 0 ;
   FrFree(m_subsumes) ;		m_subsumes = 0 ;
   freeSourceCover() ;
   m_numsubsumed = 0 ;
   m_numsuccessors = 0 ;
   if (target_word_stats)
      {
      for (size_t i = 0 ; i < m_arclen ; i++)
	 {
	 TargetWord *tw = target_word_stats[i].targetWord() ;
	 if (tw)
	    {
	    tw->removeReference() ;
	    tw->free() ;
	    }
	 }
      FrFree(target_word_stats) ;  target_word_stats = 0 ;
      }
   if (source_word_info)
      {
      for (size_t i = 0 ; i < matchWordCount() ; i++)
	 source_word_info[i].WordInfo::~WordInfo() ;
      FrFree(source_word_info) ;
      }
   return ;
}

//----------------------------------------------------------------------

void ChartArc::initUserScores()
{
   const FrStruct *metadata = metaData() ;
   if (metadata)
      {
      const FrList *userscores = (FrList*)metadata->get("SC") ;
      if (userscores && userscores->consp())
	 {
	 has_user_scores = true ;
	 for (size_t i = 0 ; i < MAX_USER_SCORES && userscores ; i++)
	    {
	    const FrObject *uscore = userscores->first() ;
	    userscores = userscores->rest() ;
	    if (uscore && uscore->numberp())
	       {
	       if (logarithmic_user_scores)
		  m_userscores[i] = uscore->floatValue() ;
	       else
		  m_userscores[i] = LmNGramModel::log(uscore->floatValue()) ;
	       }
	    else
	       m_userscores[i] = 0.0 ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void ChartArc::initSourceWC()
{
   m_source_wc = 0 ;
   if (sourceCover())
      {
      for (size_t i = 0 ; i < sourceWordSpan() ; i++)
	 {
	 if (sourceCovered(i))
	    m_source_wc++ ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void ChartArc::allocSourceCover(size_t source_span)
{
   if (source_span < LM_BITS_PER_ENTRY)
      {
      m_source_cover = 0 ;
      LmSetBit((LmBitFlags*)&m_source_cover,0) ;
      }
   else
      m_source_cover = LmAllocBitFlags(source_span) ;
   return ;
}

//----------------------------------------------------------------------

void ChartArc::freeSourceCover()
{
   if (sourceCover() != (LmBitFlags*)&m_source_cover)
      FrFree(m_source_cover) ;
   m_source_cover = 0 ;
   return ;
}

//----------------------------------------------------------------------

void ChartArc::makeTargetText()
{
   FrFree(target_text) ;
   size_t textlen = 0 ;
   for (size_t i = 0 ; i < arcLength() ; i++)
      {
      if (targetWordInfo(i))
	 textlen += strlen(targetWordInfo(i)->name()->symbolName()) + 1 ;
      }
   target_text = FrNewN(char,textlen+1) ;
   if (target_text)
      {
      target_text[0] = '\0' ;
      char *targ = target_text ;
      for (size_t i = 0 ; i < arcLength() ; i++)
	 {
	 if (targetWordInfo(i))
	    {
	    strcpy(targ,targetWordInfo(i)->name()->symbolName()) ;
	    targ = strchr(targ,'\0') ;
	    *targ++ = ' ' ;
	    }
	 }
      if (targ != target_text)
	 targ[-1] = '\0' ;		// properly terminate string
      }
   return ;
}

//----------------------------------------------------------------------

ComponentArcInfo *ChartArc::mergeSubsumedArcs(const ChartArc *other,
					      size_t &num_subsumed_arcs,
					      size_t trg_offset) const
{
   // allocate enough for all of the subsumed arcs of both this and other
   //   arc, plus this and the other arc
   size_t num_subsumed = numSubsumedArcs() + other->numSubsumedArcs() + 2 ;
   ComponentArcInfo *subsumed = FrNewN(ComponentArcInfo,num_subsumed) ;
   if (subsumed)
      {
      // merge the two sorted lists of subsumed arcs
      size_t count(0), i(0), j(0), k(0) ;
      const ComponentArcInfo *sub1 = subsumedArcs() ;
      const ComponentArcInfo *sub2 = other->subsumedArcs() ;
      ComponentArcInfo sub3[3] ;
      if (this->arcID() < other->arcID())
	 {
	 sub3[0].init(this,0,0,true) ;
	 sub3[1].init(other,0,trg_offset,true) ;
	 }
      else
	 {
	 sub3[0].init(other,0,trg_offset,true) ;
	 sub3[1].init(this,0,0,true) ;
	 }
      sub3[2].init(0,0,0) ;
      while (i < numSubsumedArcs() && j < other->numSubsumedArcs())
	 {
	 if (k < 2 && sub3[k].arc()->arcID() < sub1[i].arc()->arcID() &&
	     sub3[k].arc()->arcID() < sub2[j].arc()->arcID())
	    {
	    // we assume that neither arc is on the other's subsumed list,
	    //   or other stuff would break
	    subsumed[count++] = sub3[k++] ;
	    }
	 else if (sub1[i].arc()->arcID() < sub2[j].arc()->arcID())
	    {
	    subsumed[count++] = sub1[i++] ;
	    }
	 else if (sub1[i].arc()->arcID() > sub2[j].arc()->arcID())
	    {
	    subsumed[count] = sub2[j++] ;
	    subsumed[count++].incrTargetPosition(trg_offset) ;
	    }
	 else
	    {
	    // same arc, so only copy one instance
	    subsumed[count++] = sub1[i++] ;
	    j++ ;
	    }
	 }
      while (i < numSubsumedArcs())
	 {
	 if (k < 2 && sub3[k].arc()->arcID() < sub1[i].arc()->arcID())
	    subsumed[count++] = sub3[k++] ;
	 else
	    subsumed[count++] = sub1[i++] ;
	 }
      while (j < other->numSubsumedArcs())
	 {
	 if (k < 2 && sub3[k].arc()->arcID() < sub2[j].arc()->arcID())
	    subsumed[count++] = sub3[k++] ;
	 else
	    subsumed[count++] = sub2[j++] ;
	 }
      while (k < 2)
	 {
	 subsumed[count++] = sub3[k++] ;
	 }
      num_subsumed_arcs = count ;
      }
   else
      num_subsumed_arcs = 0 ;
   return subsumed ;
}

//----------------------------------------------------------------------

ChartArc *ChartArc::combineArcs(const ChartArc *arc1, const ChartArc *arc2,
				size_t trg_overlap)
{
   ChartArc *new_arc = 0 ;
   if (arc1 && arc2)
      {
      size_t new_arclen = arc1->arcLength() ;
      if (trg_overlap < arc2->arcLength())
	 new_arclen += (arc2->arcLength() - trg_overlap) ;
      TargetWordStats *twords = FrNewN(TargetWordStats,new_arclen) ;
      size_t new_start = 0 ;
      if (trg_overlap < arc1->arcLength())
	 new_start = arc1->arcLength() - trg_overlap ;
      size_t new_end = new_start + arc2->arcLength() ;
      LmUSHORT OOV_count = 0 ;
      LmMergeTargetWords(twords,new_arclen,
			 arc1->targetWordStats(),arc1->arcLength(),
			 arc2->targetWordStats(),new_start,new_end,
			 0,OOV_count) ;
      new_arc = new ChartArc(arc1,arc2,twords,new_arclen,new_start) ;
      size_t pos = minimum(arc1->startPosition(),arc2->startPosition()) ;
      new_arc->setStart(pos) ;
      }
   return new_arc ;
}

//----------------------------------------------------------------------

void ChartArc::setWeight(double weight)
{
   m_weight = weight ;
   m_logweight = LmNGramModel::log(weight) ;
   return ;
}

//----------------------------------------------------------------------

void ChartArc::setScore(double score)
{
   m_score = score ;
   m_logscore = LmNGramModel::log(score) ;
   return ;
}

//----------------------------------------------------------------------

void ChartArc::setQuality(double qual)
{
   m_quality = qual ;
   m_logquality = LmNGramModel::log(qual) ;
   return ;
}

//----------------------------------------------------------------------
// IMPORTANT NOTE: needs to stay synchronized with BFSNode::updateNodeInfo!

void ChartArc::setFutureUtility(LmNGramModel **models)
{
   if (weightof_future == 0.0)
      m_futureutility = 0.0 ;
   else
      {
      bool cues = use_context_cues ;
      use_context_cues = false ;
      LmNgramScore(models,target_word_stats,arcLength()) ;
      use_context_cues = cues ;
      double lmscore = 0.0 ;
      size_t word_count = 0 ;
      double weight = 0.0 ;
      double score = 0.0 ;
      double quality = 0.0 ;
      double len_bonus = 0.0 ;
      double chunk_bonus = 0.0 ;
      double untrans = 0.0 ;
      for (size_t i = 0 ; i < arcLength() ; i++)
	 {
	 const TargetWordStats *tw = targetWordStats(i) ;
	 if (tw->name() != symEPSILON)
	    {
	    word_count++ ;
	    weight += tw->weight() ;
	    score += tw->score() ;
	    quality += tw->quality() ;
	    len_bonus += tw->lengthBonus() ;
	    chunk_bonus += tw->chunkingBonus() ;
	    untrans += tw->untransPenalty() ;
	    if (tw->probabilityKnown())
	       {
	       lmscore += target_word_stats[i].probability() ;
	       ((TargetWordStats*)tw)->invalidateProbability() ;
	       }
	    }
	    if (moses_style_scoring) break;
	 }
      if (word_count == 0)
	 {
	 lmscore = 0.001 ;
	 if (!models || !models[0] || models[0]->usingLogSpace())
	    lmscore = LmNGramModel::log(lmscore) ;
	 word_count = 1 ;
	 }
      double userscore = 0.0 ;
      for (size_t i = 0 ; i < MAX_USER_SCORES ; i++)
	 {
	 userscore += (word_count * m_userscores[i] * weightof_user[i]) ;
	 }
      if (moses_style_scoring) lmscore = 0.0;
      m_futureutility = (weightof_arcweight * weight
			 + weightof_score * score
			 + weightof_quality * quality
			 + weightof_lengthbonus * len_bonus
			 + weightof_chunking * chunk_bonus
			 + weightof_untrans * untrans
			 + userscore + lmscore) ;
      m_futureutility /= word_count ;
      }
   return ;
}

//----------------------------------------------------------------------

void ChartArc::setDecoration(const char *prefix, const char *suffix)
{
   FrFree(target_prefix) ;
   FrFree(target_suffix) ;
   target_prefix = FrDupString(prefix) ;
   target_suffix = FrDupString(suffix) ;
   return ;
}

//----------------------------------------------------------------------

void ChartArc::setChunkingBonus(double chbonus)
{
   m_chunkingbonus = chbonus ;
   if (target_word_stats)
      {
      for (size_t i = 0 ; i < arcLength() ; i++)
	 {
	 target_word_stats[i].setChunkingBonus(chbonus) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void ChartArc::setChunkingBonus(const FrTextSpan *span)
{
   // based on code from Jaedy
   const FrObject *c = span->getMetaData("CHUNKBONUS") ;
   if (c)
      {
      double chunking_bonus = 0 ;
      if (c->consp())
	 chunking_bonus = ((FrList*)c)->first()->floatValue() ;
      else if (c->numberp())
	 chunking_bonus = c->floatValue() ;
      if (chunking_bonus > chunkingBonus())
	 setChunkingBonus(chunking_bonus);
      }
   return ;
}

//----------------------------------------------------------------------

void ChartArc::setSuccessors(ChartArcSuccessor *succ, size_t num_succ)
{
   FrFree(m_successors) ;
   m_successors = 0 ;
   m_numsuccessors = 0 ;
   if (num_succ > 0)
      {
      m_successors = FrNewN(ChartArcSuccessor,num_succ) ;
      if (m_successors)
	 {
	 m_numsuccessors = num_succ ;
	 for (size_t i = 0 ; i < num_succ ; i++)
	    m_successors[i] = succ[i] ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

bool ChartArc::subsumes(const ChartArc *other) const
{
   if (m_subsumes && other)
      {
      for (size_t i = 0 ; i < m_numsubsumed ; i++)
	 {
	 if (m_subsumes[i].arc() == other)
	    return true ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

void ChartArc::setSourceAlignment(size_t wordnum,size_t srcstart,size_t srcend)
{
   if (wordnum < arcLength() && targetWordStats())
      {
      TargetWord *tw = targetWordStats()[wordnum].targetWord() ;
      if (tw)
	 tw->setSourceWords(srcstart,srcend) ;
      }
   return ;
}

//----------------------------------------------------------------------

bool ChartArc::allowableArc(const LmBitFlags *previous_coverage,
			    size_t src_overlap) const
{
   assertq (previous_coverage != 0) ;
   // check coverage of each of the input words corresponding
   //   to the arc's location in the chart, except those overlapping the
   //   previous arc
   size_t startword = chart()->wordIndex(startPosition()) ;
   size_t end = startword + sourceWordSpan() ;
   for (size_t i = startword + src_overlap ; i < end ; i++)
      {
      if (LmGetBit(previous_coverage,i))
	 {
	 return false ;
	 }
      }
   return true ;
}

//----------------------------------------------------------------------

bool ChartArc::canFillGap(const ChartArc *successor, size_t /*srcoverlap*/,
			  size_t &trgoverlap) const
{
   trgoverlap = 0 ;
   if (!hasGapMarkers() || !successor)
      return false ;
   FrLocalAllocC(size_t,fillers,1024,arcLength()+1) ;
   if (!fillers)
      return false ;
   // check which words in the translation are gaps that must be filled
   size_t numgaps = 0 ;
   size_t i ;
   for (i = 0 ; i < arcLength() ; i++)
      {
      // find gaps that are to be filled from words to the right of the
      //   current arc
      const TargetWord *tw = target_word_stats[i].targetWord() ;
      if (!tw)
	 continue ;
      size_t fillpos = tw->gapFillerLocation() ;
      if (fillpos != EBMT_GAP_FILLER_NOTGAP &&
	  fillpos != EBMT_GAP_FILLER_UNKNOWN)
	 {
	 fillers[i] = fillpos ;
	 numgaps++ ;
	 }
      }
   // the simple case: the new arc fills in one or more contiguous gapped words
   //   and nothing else
   for (i = 0 ; i < arcLength() ; i++)
      {
      if (fillers[i])
	 break ;
      }
   size_t firstgap = i ;
   bool sequential = true ;
   for (i = i+1 ; i < arcLength() ; i++)
      {
      if (!fillers[i])
	 break ;
      if (fillers[i] != fillers[i-1] + 1)
	 sequential = false ;
      }
   bool left_filler = (fillers[firstgap] < startPosition()) ;
   if (!successor->hasAlignments())
      {
      FrLocalFree(fillers) ;
      // without alignment information, we are much more limited in what types
      //   of overlaps can be used: we can fill the gap only by jamming the
      //   entire successor into the gap, which means that the gapped words
      //   must all be contiguous and monotonically aligned, and the successor
      //   must not itself have any gaps
      if (i - firstgap == numgaps && sequential && 
	  successor->arcLength() == numgaps && !successor->hasGapMarkers() &&
	  (!left_filler || (successor->pastEndPosition() == startPosition())))
	 {
	 trgoverlap = arcLength() - firstgap ;
	 return true ;
	 }
      else
	 return false ;
      }
   else if (sequential && i - firstgap == numgaps &&
	    !successor->hasGapMarkers())
      {
      // check whether we can jam the successor into the gap
//FIXME!!!
      }
   FrLocalFree(fillers) ;
   if (i - firstgap == numgaps && sequential &&
       successor->arcLength() == numgaps && !successor->hasGapMarkers() &&
       (!left_filler || (successor->pastEndPosition() == startPosition())))
      {
      trgoverlap = arcLength() - firstgap ;
      return true ;
      }
   // sorry, can't fill in any gaps using that arc....
   return false ;
}

//----------------------------------------------------------------------

void ChartArc::updateInputCover(LmBitFlags *overall_coverage,
				LmUSHORT &bytecover,
				const size_t *boundaries) const
{
   if (overall_coverage)
      {
      // full coverage for each word corresponding to the arc's
      //   position in the chart, unless the source word generates
      //   a gap marker in the target
      size_t start = chart()->wordIndex(startPosition()) ;
      size_t end = chart()->wordIndex(startPosition() + coverage()) ;
      for (size_t i = start ; i < end ; i++)
	 {
	 if ((!sourceCover() || sourceCovered(i-start)) &&
	     !LmGetBit(overall_coverage,i))
	    {
	    LmSetBit(overall_coverage,i) ;
	    if (boundaries[i+1] > boundaries[i])
	       bytecover += (LmUSHORT)(boundaries[i+1] - boundaries[i]) ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void ChartArc::mergeArc(ChartEntryType type, const LmFeatures &features,
			double weight)
{
   if ((arctype & (1<<type)) == 0)
      {
      // update agreement bonus if we haven't used this engine yet
      arctype |= (1<<type) ;
      m_occurrences++ ;
      }
   double score = features.score() ;
   if (score < 0.0)
      score = 0.0 ;
   double quality = features.quality() ;
   double this_weight = this->weight() ;
   double new_weight = (this_weight + weight) ;
   setScore(((this->score() * this_weight) + (score * weight))
	    / new_weight) ;
   setQuality(((this->quality() * this_weight) + (quality*weight))
	      / new_weight) ;
   setDocContext(((this->docContext() * this_weight)
		  + (features.docContext() * weight))
		 / new_weight) ;
   setSentContext(((this->sentContext() * this_weight)
		   + (features.sentContext() * weight))
		  / new_weight) ;
   setPhraseContext(((this->phraseContext() * this_weight)
		     + (features.phraseContext() * weight))
		    / new_weight) ;
   setWeight(new_weight) ;
   return ;
}

//----------------------------------------------------------------------

void ChartArc::mergeArc(MTEngine *engine, const LmFeatures &features,
			double weight)
{
   mergeArc(engine->engineID(),features,weight) ;
   return ;
}

//----------------------------------------------------------------------

bool ChartArc::merge(MTEngine *engine, const char *source,
		     const char *translation, size_t cover,
		     const LmFeatures &features, ChartArc **prev_arc)
{
   ChartArc *arc = (ChartArc*)this ;

   // scan down the list of arcs, merging the new arc with every arc that
   //   has the same target text modulo case, but if we have any
   //   case-sensitive models, only report that the new arc has been merged
   //   if we have an exact match including case
   bool exact_match = false ;
   double weight = features.weight() ;
   double max_weight = -1 ;
   for ( ; arc ; arc = arc->next())
      {
      if (arc->coverage() == cover &&
	  (ignore_source_morphology ||
	   strcmp(arc->source_text,source) == 0))
	 {
	 if (Fr_stricmp(arc->target_text,translation,lowercase_table) == 0)
	    {
	    arc->mergeArc(engine,features,weight*engine->engineWeight()) ;
	    if (!LmCaseSensitiveModel())
	       return true ;
	    else
	       {
	       // if requested, return the case-folded matching arc with the
	       //   highest weight, which will be the one that was first added
	       //   and has thus had all others merged in
	       if (prev_arc && arc->weight() > max_weight)
		  {
		  *prev_arc = arc ;
		  max_weight = arc->weight() ;
		  }
	       if (!exact_match &&
		   strcmp(arc->target_text,translation) == 0)
		  exact_match = true ;
	       }
	    }
	 }
      }
   return exact_match ;
}

//----------------------------------------------------------------------

ChartArc *ChartArc::reverseList()
{
   ChartArc *prev = 0 ;
   ChartArc *curr = this ;
   while (curr)
      {
      ChartArc *nxt = curr->next() ;
      curr->setNext(prev) ;
      prev = curr ;
      curr = nxt ;
      }
   return prev ;
}

//----------------------------------------------------------------------

ostream &operator << (ostream &output, const ChartArc *arc)
{
   for (size_t i = 0 ; i < arc->arcLength() ; i++)
      {
      const FrSymbol *twname = arc->nthWord(i) ;
      const char *w = (twname ? twname->symbolName() : "") ;
      if (*w == '\\' || *w == '"')
	 output << '\\' ;
      output << w ;
      if (i < arc->arcLength()-1)
	 output << ' ' ;
      }
   return output ;
}

//----------------------------------------------------------------------

ostream &ChartArc::dump(ostream &output) const
{
   output << '\t' << arc_type_name() << ": \"" << source_text
	  << "\" (len " << coverage() << ",wds " << sourceWordSpan()
	  << ") --> \"" ;
   double total_weight = 0.0 ;
   for (size_t m = 0 ; models() ; m++)
      {
      LmNGramModel *model = models()[m] ;
      if (!model)	
	 break ;
      double weight = model->weight() ;
      total_weight += weight ;
      for (size_t i = 0 ; i < arcLength() ; i++)
	 {
	 if (m == 0)
	    {
	    const FrSymbol *twname = nthWord(i) ;
	    const char *w = (twname ? twname->symbolName() : "") ;
	    if (*w == '\\' || *w == '"')
	       output << '\\' ;
	    output << w ;
	    if (i < arcLength()-1)
	       output << ' ' ;
	    }
	 }
      }
   output << "\" (sc " << score() << '+' << lengthBonus()
	  << " wt " << weight() << ')' ;
   if (show_metadata)
      {
      FrList *meta = LmPrintableMetadata(metaData(),true) ;
      output << ' ' << meta ;
      free_object(meta) ;
      }
   output << endl ;
   return output ;
}

//----------------------------------------------------------------------

size_t ChartArc::maxEngines()
{
   return lengthof(arc_type_names) ;
}

//----------------------------------------------------------------------

ChartEntryType ChartArc::allocateArcType(FrSymbol *tag)
{
   if (!tag || num_arc_types >= lengthof(arc_type_names))
      return CE_none ;
   const char *tagstr = tag->symbolName() ;
   if (*tagstr == ':')
      tagstr++ ;
   arc_type_names[num_arc_types] = FrDupString(tagstr) ;
   return (ChartEntryType)(num_arc_types++) ;
}

//----------------------------------------------------------------------

const char *ChartArc::arc_type_name() const
{
   if (!arctype)
      return arc_type_names[0] ;
   static char buffer[1000] ;
   unsigned size = 0 ;
   for (unsigned i = 0 ; i < num_arc_types && size < lengthof(buffer) ; i++)
      {
      if ((arctype & (1<<i)) != 0)
	 {
	 unsigned namelen = strlen(arc_type_names[i]) ;
	 if (size + namelen >= lengthof(buffer))
	    break ;
	 if (size)
	    buffer[size++] = '+' ;
	 strcpy(buffer+size,arc_type_names[i]) ;
	 size += namelen ;
	 }
      }
   buffer[size] = '\0' ;
   return buffer ;
}

//----------------------------------------------------------------------

void ChartArc::freeArcTypes()
{
   for (size_t i = prealloc_arc_types ; i < lengthof(arc_type_names) ; i++)
      {
      FrFree(arc_type_names[i]) ;
      arc_type_names[i] = 0 ;
      }
   num_arc_types = prealloc_arc_types ;
   return ;
}

//----------------------------------------------------------------------

void dump_arc_info(ostream &out, const ChartArc *arc)
{
   if (arc)
      arc->dump(out) ;
   else
      out << endl ;
   return ;
}

//----------------------------------------------------------------------

ostream &dump_arc_list(ostream &out, TargetWordList *wordlist)
{
   if (wordlist)
      {
      if (wordlist->numArcs() > 0)
	 {
	 for (size_t i = 0 ; i < wordlist->numArcs() ; i++)
	    {
	    const ChartArc *arc = wordlist->arc(i) ;
	    if (arc)
	       dump_arc_info(out,arc) ;
	    }
	 }
      else
	 {
	 const TargetWord * const *words = wordlist->words() ;
	 size_t num_words = wordlist->twlLength() ;
	 ChartArc *arc = words[0]->sourceArc() ;
	 ChartArc *prev_arc = 0 ;
	 for (size_t i = 1 ; i <= num_words ; i++)
	    {
	    if (arc && arc != prev_arc)
	       {
	       dump_arc_info(out,arc) ;
	       prev_arc = arc ;
	       }
	    if (i < num_words)
	       arc = words[i]->sourceArc() ;
	    }
	 }
      }
   return out ;
}

//----------------------------------------------------------------------

const FrSymbol *ChartArc::nthWord(size_t n) const
{
   const TargetWord *tw ;
   if (n < arcLength() && (tw = targetWordInfo(n)) != 0)
      return tw->name() ;
   else
      return 0 ;
}

//----------------------------------------------------------------------

LmWordID_t ChartArc::nthWordID(size_t n, size_t modelnum) const
{
   if (n < arcLength() && targetWordStats(n))
      {
      TargetWord *tw = targetWordStats(n)->targetWord() ;
      return tw ? tw->ID(modelnum) : 0 ;
      }
   else
      return 0 ;
}

//----------------------------------------------------------------------

bool ChartArc::sourceCovered(size_t N) const
{
   return (N < sourceWordSpan()) ? LmGetBit(sourceCover(),N) : false ;
}

//----------------------------------------------------------------------

FrSymbol *ChartArc::sourceWord(size_t N) const
{
   return (N < sourceWordSpan()) ? source_word_info[N].symbol() : 0 ;
}

//----------------------------------------------------------------------

FrSymbol *ChartArc::targetWord(size_t N) const
{
   const TargetWord *tw = targetWordInfo(N) ;
   return tw ? (FrSymbol*)tw->name() : 0 ;
}

//----------------------------------------------------------------------

const TargetWordStats *ChartArc::targetWordStats(size_t N) const
{
   return (target_word_stats && N < m_arclen) ? &target_word_stats[N] : 0 ;
}

//----------------------------------------------------------------------

const TargetWord *ChartArc::targetWordInfo(size_t N) const
{
   return (target_word_stats && N < m_arclen)
      ? target_word_stats[N].targetWord() : 0 ;
}

//----------------------------------------------------------------------

FrList *ChartArc::sourceAlignments() const
{
   FrList *align = 0 ;
   FrList **end = &align ;
   for (size_t i = 0 ; i < arcLength() ; i++)
      {
      const TargetWord *tw = target_word_stats[i].targetWord() ;
      if (tw)
	 {
	 FrObject *al = tw->sourceAlignment() ;
	 if (al && !((FrList*)al)->rest())
	    {
	    FrList *alist = (FrList*)al ;
	    al = poplist(alist) ;
	    }
	 align->pushlistend(al,end) ;
	 }
      else
	 align->pushlistend(0,end) ;
      }
   *end = 0 ;				// ensure correct termination of list
   return align ;
}

//----------------------------------------------------------------------

void ChartArc::setFillerLocations()
{
   if (chart())
      {
      size_t arc_start = chart()->wordIndex(startPosition()) ;
      for (size_t i = 0 ; i < arcLength() ; i++)
	 {
	 TargetWord *tw = target_word_stats[i].targetWord() ;
	 tw->setFillerLocation(arc_start) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void ChartArc::addConflict(const ChartArc *other, size_t total_arcs)
{
   if (other && other->arcID() < total_arcs)
      {
      if (m_conflicts.numConflicts() == 0)
	 m_conflicts.init(0,total_arcs) ;
      m_conflicts.addConflict(other->arcID()) ;
      }
   return ;
}

/************************************************************************/
/*	Procedural interface to class ChartArc				*/
/************************************************************************/

template <class T> void LmMergeTargetWords(T newtw[], size_t wordcount,
					   const T oldtw[], size_t prev,
					   const TargetWordStats tw[],
					   size_t new_start,
					   size_t new_end,
					   BFSNode *node,
					   LmUSHORT &OOV_count
   					  )
{
   // copy words from 'oldtw' and 'tw' into 'newtw', making appropriate
   //   adjustments along the way, such as replacing gap markers
   for (size_t i = 0 ; i < new_start ; i++)
      {
      // copy everything before the start of the new arc
      newtw[i].init(oldtw[i]) ;
      }
   for (size_t i = new_start ; i < wordcount ; i++)
      {
      if (i < prev)
	 {
	 // we're still within the old node's text, so keep the existing words
 assert(oldtw[i].IDs() != 0) ; //!!!
	 newtw[i].init(oldtw[i]) ;
	 if (i < new_end)
	    {
	    // we're in the overlap region, so check for fillable gap markers
	    size_t new_loc = i - new_start ;
	    newtw[i].addCover(&tw[new_loc]) ;
	    if (newtw[i].ID(0) == LmVOCAB_GAP_MARKER)
	       {
	       if (tw[new_loc].ID(0) != LmVOCAB_GAP_MARKER)
		  {
		  size_t old_len = string_length(newtw[i]) ;
		  newtw[i].setWord(tw[new_loc].targetWord()) ;
		  if (node)
		     {
		     node->decrGapMarkers() ;
		     node->gapFilled() ;
		     node->adjustByteLength(string_length(newtw[i]) - old_len);
		     }
		  }
	       }
	    else if (node && tw[new_loc].ID(0) == LmVOCAB_GAP_MARKER)
	       node->gapFilled() ;
	    }
	 }
      else if (i < new_end)
	 {
	 // we've passed the end of the old node's text, so copy from the
	 //   new arc, updating OOV and gap-marker statistics as we go
 assert(tw[i-new_start].IDs() != 0) ; //!!!
	 newtw[i].init(tw[i-new_start]) ;
	 if (node && newtw[i].ID(0) == LmVOCAB_GAP_MARKER)
	    node->incrGapMarkers() ;
	 else if (newtw[i].ID(0) == LmVOCAB_WORD_NOT_FOUND)
	    OOV_count++ ;
	 if (node)
	    node->adjustByteLength(string_length(newtw[i])) ;
	 }
      else if (node)
	 {
	 // the text is now complete, so we need to insert the appropriate
	 //   sentence ender(s)
	 if (node->isQuestion())
	    newtw[i++].init(node->getParseChart()->questionMark(),0,1) ;
	 if (use_context_cues)
	    newtw[i].init(node->getParseChart()->endSentence(),0,1) ;
	 }
      }
   return ;
}

// explicit instantiation
template void LmMergeTargetWords(TargetWordRef newtw[], size_t wordcount,
				 const TargetWordRef oldtw[], size_t prev,
				 const TargetWordStats tw[],
				 size_t new_start,
				 size_t new_end,
				 BFSNode *node,
				 LmUSHORT &OOV_count) ;


//----------------------------------------------------------------------

// end of file lmarcs.cpp //
