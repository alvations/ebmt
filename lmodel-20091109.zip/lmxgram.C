/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmxgram.cpp	fixed-length smoothed n-gram language model	*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2006,2007,2008,2009 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include <cmath>
#include "lmngram.h"
#include "lmxgram.h"

/************************************************************************/
/*	Manifest constants for this module				*/
/************************************************************************/

#define DEFAULT_SMOOTHING 0.5

/************************************************************************/
/*	Global variables for this module				*/
/************************************************************************/

static size_t num_discount_levels = NUM_DISCOUNT_LEVELS ;

/************************************************************************/
/*	Helper Functions						*/
/************************************************************************/

static void touch_memory(void *address, size_t size)
{
   static int dummy_counter = 0 ;
   char *mem = (char*)address ;
   FrWillNeedMemory(mem,size) ;
   size_t count = 0 ;
   char *end = mem + size ;
   // code to touch the specified region of a memory-mapped file to force it
   //   into RAM.  Some of the convolution is to prevent the compiler from
   //   optimizing away the entire code
   for ( ; mem < end ; mem += 1024)
      count += *mem ;
   dummy_counter = count ;
   return ;
}

/************************************************************************/
/*	Methods for class LmNgramFileHeader				*/
/************************************************************************/

LmNgramFileHeader::LmNgramFileHeader(size_t rank)
{
   memcpy(m_signature,LmSIGNATURE,sizeof(LmSIGNATURE)) ;
   m_version = 1 ;
   m_rank = (uint8_t)rank ;
   m_wordID_bits = (uint8_t)LmWORDID_BITS ;
   m_countID_bits = (uint8_t)LmCOUNTID_BITS ;
   m_countofcounts_max = (uint8_t)LmCOUNTOFCOUNTS_MAX ;
   m_flags = (uint8_t)0 ;
   setCountIDmax(0) ;
   setCountIDoffset(0) ;
   setCountOfCounts(0) ;
   setGlobalDiscounts(0) ;
   setTrainingSize(0) ;
   setVocabOffset(0) ;
   setSuffArraySize(0) ;
   setSuffArrayOffset(0) ;
   for (size_t i = 0 ; i < lengthof(m_reserved) ; i++)
      FrStore64(0,&m_reserved[i]) ;
   return ;
}

//----------------------------------------------------------------------

bool LmNgramFileHeader::read(FILE *fp)
{
   if (fp)
      return fread(this,sizeof(*this),1,fp) == 1 ;
   return false ;
}

//----------------------------------------------------------------------

bool LmNgramFileHeader::write(FILE *fp) const
{
   if (fp)
      return Fr_fwrite(this,sizeof(*this),fp) ;
   return false ;
}

/************************************************************************/
/*	Methods for class LmCountMap					*/
/************************************************************************/

LmCountMap::LmCountMap(size_t numcounts)
{
   if (numcounts <= IDENTITY_MAP)
      numcounts = IDENTITY_MAP + 1 ;
   m_counts = FrNewC(uint32_t,numcounts+1) ;
   if (m_counts)
      {
      m_allocated = true ;
      m_numcounts = numcounts ;
      for (size_t i = 1 ; i < IDENTITY_MAP ; i++)
	 FrStoreLong(i,&m_counts[i]) ;
      }
   else
      {
      m_allocated = false ;
      m_numcounts = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

LmCountMap::LmCountMap(size_t numcounts, char *counts)
{
   m_allocated = false ;
   m_counts = (uint32_t*)counts ;
   if (counts)
      m_numcounts = numcounts ;
   else
      m_numcounts = 0 ;
   return ;
}

//----------------------------------------------------------------------

LmCountMap::LmCountMap(size_t numcounts, FILE *fp)
{
   m_counts = FrNewN(uint32_t,numcounts) ;
   if (m_counts &&
       fread(m_counts,sizeof(m_counts[0]),m_numcounts,fp) == m_numcounts)
      {
      m_numcounts = numcounts ;
      m_allocated = true ;
      }
   else
      {
      m_numcounts = 0 ;
      FrFree(m_counts) ;
      m_counts = 0 ;
      m_allocated = false ;
      }
   return ;
}

//----------------------------------------------------------------------

LmCountMap::~LmCountMap()
{
   if (m_allocated)
      FrFree(m_counts) ;
   m_counts = 0 ;
   return ;
}

//----------------------------------------------------------------------

bool LmCountMap::write(FILE *fp) const
{
   if (fp && m_counts)
      return Fr_fwrite(m_counts,sizeof(m_counts[0]),m_numcounts,fp) ;
   return false ;
}

//----------------------------------------------------------------------

uint32_t LmCountMap::count(size_t countID) const
{
   if (countID < m_numcounts)
      return FrLoadLong(&m_counts[countID]) ;
   else
      return 0 ;
}

//----------------------------------------------------------------------

uint32_t LmCountMap::countID(size_t count)
{
   // first, see whether we were able to use the identity mapping for the count
   if (count < m_numcounts && FrLoadLong(&m_counts[count]) == count)
      return (uint32_t)count ;
   // no identity mapping, so now scan for the value
   for (size_t i = IDENTITY_MAP ; i < m_numcounts ; i++)
      {
      if (FrLoadLong(&m_counts[i]) == count)
	 return (uint32_t)i ; 
      }
   // value not in the map, so if we don't already have a local copy of the
   //   map, make one so that we can write to it
   if (!m_allocated)
      {
      uint32_t *newcounts = FrNewN(uint32_t,m_numcounts+1) ;
      if (newcounts)
	 {
	 m_allocated = true ;
	 memcpy(newcounts,m_counts,m_numcounts*sizeof(m_counts[0])); 
	 m_counts = newcounts ;
	 }
      }
   // value not yet in the map, so see whether we can use the identity mapping
   if (count < m_numcounts && FrLoadLong(&m_counts[count]) == 0)
      {
      FrStoreLong(count,&m_counts[count]) ;
      return (uint32_t)count ;
      }
   // value not yet in the map, but we can't use the identity mapping because
   //   some other value has already taken that slot, so scan for an empty
   //   position in the map; we can skip the first part of the map because
   //   it is set up with identity mappings by definition
   for (size_t i = IDENTITY_MAP ; i < m_numcounts ; i++)
      {
      if (FrLoadLong(&m_counts[i]) == 0)
	 {
	 FrStoreLong((uint32_t)count,&m_counts[i]) ;
	 return i ;
	 }
      }
   // uh oh, map is full but we didn't find a match for the given count, so
   //  search for the nearest count that is already present in the map
   uint32_t best_diff = UINT32_MAX ;
   size_t best_index = ~0 ;
   for (size_t i = IDENTITY_MAP ; i < m_numcounts ; i++)
      {
      uint32_t c = FrLoadLong(&m_counts[i]) ;
      uint32_t diff = (c < count) ? (count - c) : (c - count) ;
      if (diff < best_diff)
	 {
	 best_index = i ;
	 best_diff = diff ;
	 }
      }
   return (uint32_t)best_index ;
}

//----------------------------------------------------------------------

size_t LmCountMap::numCountsUsed() const
{
   size_t used = 0 ;
   for (size_t i = 0 ; i < numCounts() ; i++)
      {
      if (count(i) != 0)
	 used++ ;
      }
   return used ;
}

/************************************************************************/
/*	Methods for class LmCountOfCounts				*/
/************************************************************************/

LmCountOfCounts::LmCountOfCounts()
{
   for (size_t i = 0 ; i <= LmCOUNTOFCOUNTS_MAX ; i++)
      {
      m_freqs[i] = 0 ;
      m_conts[i] = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

LmCountOfCounts::LmCountOfCounts(const char *data)
{
   for (size_t i = 1 ; i <= LmCOUNTOFCOUNTS_MAX ; i++)
      {
      m_freqs[i] = FrLoadLong(data) ;
      data += sizeof(m_freqs[i]) ;
      }
   for (size_t i = 1 ; i <= LmCOUNTOFCOUNTS_MAX ; i++)
      {
      m_conts[i] = FrLoadLong(data) ;
      data += sizeof(m_conts[i]) ;
      }
   return ;
}

//----------------------------------------------------------------------

void LmCountOfCounts::clearContinuations()
{
   for (size_t i = 0 ; i <= LmCOUNTOFCOUNTS_MAX ; i++)
      m_conts[i] = 0 ;
   return ;
}

//----------------------------------------------------------------------

bool LmCountOfCounts::write(FILE *fp) const
{
   if (fp)
      {
      uint32_t value ;
      bool success = true ;
      for (size_t i = 1 ; i <= LmCOUNTOFCOUNTS_MAX && success ; i++)
	 {
	 FrStoreLong(m_freqs[i],&value) ;
	 success = Fr_fwrite(&value,sizeof(value),fp) ;
	 }
      for (size_t i = 1 ; i <= LmCOUNTOFCOUNTS_MAX && success ; i++)
	 {
	 FrStoreLong(m_conts[i],&value) ;
	 success = Fr_fwrite(&value,sizeof(value),fp) ;
	 }
      return success ;
      }
   return false ;
}

/************************************************************************/
/*	Methods for class LmNgramDiscounts				*/
/************************************************************************/

LmNgramDiscounts::LmNgramDiscounts()
{
   for (size_t i = 0 ; i < LmCOUNTOFCOUNTS_MAX ; i++)
      FrStoreLong(LmDISCOUNT_SCALE_FACTOR,&m_discounts[i]) ; // set to 1.0
   return ;
}

//----------------------------------------------------------------------

bool LmNgramDiscounts::read(FILE *fp)
{
   if (fp)
      return fread(m_discounts,sizeof(m_discounts[0]),
		   lengthof(m_discounts),fp) == lengthof(m_discounts) ;
   return false ;
}

//----------------------------------------------------------------------

bool LmNgramDiscounts::write(FILE *fp) const
{
   if (fp)
      return Fr_fwrite(m_discounts,sizeof(m_discounts[0]),
		       lengthof(m_discounts),fp) ;
   return false ;
}

/************************************************************************/
/*	Methods for class LmRecordPointerRecord				*/
/************************************************************************/

LmRecordPointerRecord::LmRecordPointerRecord()
{
   FrStoreLong(0,&m_count) ;
   FrStoreLong(0,&m_reserved) ;
   FrStore64(0,&m_records) ;
   FrStore64(0,&m_pointers) ;
   FrStore64(0,&m_discounts) ;
   return ;
}

//----------------------------------------------------------------------

bool LmRecordPointerRecord::write(FILE *fp) const
{
   if (fp)
      return Fr_fwrite(this,sizeof(*this),fp) ;
   return false ;
}

/************************************************************************/
/*	Methods for class LmUnigramRecord				*/
/************************************************************************/

//----------------------------------------------------------------------

bool LmUnigramRecord::write(FILE *fp) const
{
   if (fp)
      return Fr_fwrite(this,sizeof(*this),fp) ;
   return false ;
}

/************************************************************************/
/*	Methods for class LmNgramRecord					*/
/************************************************************************/

bool LmNgramRecord::write(FILE *fp) const
{
   if (fp)
      return Fr_fwrite(this,sizeof(*this),fp) ;
   return false ;
}

/************************************************************************/
/*	Methods for class LmNGramsFile					*/
/************************************************************************/

LmNGramsFile::LmNGramsFile(const char *filename, size_t max_rank_to_use,
			   bool allow_mmap, bool preload)
{
   m_vocab = 0 ;
   m_vocabsize = 0 ;
   m_surfvocab = 0 ;
   m_stopwords = 0 ;
   m_fmap = 0 ;
   m_smoothing = FrLMSmooth_SimpKN ;
   m_case_sensitive = false ;
   m_char_based = false ;
   m_include_spaces = false ;
   m_affix_sizes = 0 ;
   if (!verifyFormat(filename))
      {
      FrWarningVA("invalid file format in %s",filename) ;
      m_vocabsize = 0 ;
      m_OK = false ;
      }
   else
      {
      m_OK = true ;
      off_t vocab_offset = 0 ;
      if (allow_mmap)
	 {
	 m_fmap = FrMapFile(filename,FrM_READONLY) ;
	 if (m_fmap)
	    {
	    char *base = (char*)FrMappedAddress(m_fmap) ;
	    LmNgramFileHeader *header = (LmNgramFileHeader*)base ;
	    m_maxlength = header->m_rank ;
	    m_case_sensitive = header->isCaseSensitive() ;
	    m_char_based = header->isCharBased() ;
	    m_include_spaces = header->includesSpaces() ;
	    m_affix_sizes = header->affixSizes() ;
	    if (allocPerRankData())
	       {
	       m_numcounts = header->countIDmax() ;
	       m_counts = new LmCountMap(m_numcounts,
					 base+header->countIDoffset()) ;
	       m_discounts = (LmNgramDiscounts*)(base +
						 header->globalDiscounts()) ;
	       char *c_of_c = (base + header->countOfCounts()) ;
	       loadCountOfCounts(c_of_c) ;
	       m_numtokens = FrLoad64(&header->m_trainingsize) ;
	       vocab_offset = header->vocabOffset() ;
	       loadRecords(base + sizeof(*header),0,base,
			   preload?max_rank_to_use:2) ;
	       }
	    if (vocab_offset)
	       {
	       m_vocab = new FrVocabulary(m_fmap,filename,vocab_offset) ;
	       if (m_vocab)
		  {
		  off_t offset = vocab_offset + m_vocab->totalDataSize() ;
		  m_surfvocab = new FrVocabulary(m_fmap,filename,offset) ;
		  if (m_surfvocab)
		     {
		     offset += m_surfvocab->totalDataSize() ;
		     m_stopwords = new FrVocabulary(m_fmap,filename,offset) ;
		     if (m_surfvocab->numWords() == 0)
			{
			delete m_surfvocab ;
			m_surfvocab = 0 ;
			}
		     if (m_stopwords && m_stopwords->numWords() == 0)
			{
			delete m_stopwords ;
			m_stopwords = 0 ;
			}
		     }
		  }
	       }
	    }
	 }
      if (!m_fmap)			// were we unable to mmap the file?
	 {
	 // load the model by allocating memory and reading in the file
	 FILE *fp = fopen(filename,FrFOPEN_READ_MODE) ;
	 LmNgramFileHeader header ;
	 if (fp &&
	     fread(&header,sizeof(char),sizeof(header),fp) == sizeof(header))
	    {
	    m_maxlength = header.m_rank ;
	    m_numcounts = header.countIDmax() ;
	    m_case_sensitive = header.isCaseSensitive() ;
	    m_char_based = header.isCharBased() ;
	    m_include_spaces = header.includesSpaces() ;
	    m_affix_sizes = header.affixSizes() ;
	    if (allocPerRankData())
	       {
	       fseek(fp,header.countIDoffset(),SEEK_SET) ;
	       m_counts = new LmCountMap(m_numcounts,fp) ;
	       if (!m_counts || !m_counts->OK())
		  {
		  m_numcounts = 0 ;
		  m_OK = false ;
		  }
	       m_discounts = FrNewN(LmNgramDiscounts,m_maxlength) ;
	       if (!m_discounts ||
		   fseek(fp,header.globalDiscounts(),SEEK_SET) ||
		   (fread(m_discounts,sizeof(m_discounts[0]),m_maxlength,fp)
		    != m_maxlength))
		  m_OK = false ;
	       FrLocalAllocC(char,c_of_c,2048,
			     (sizeof(LmCountOfCounts)*m_maxlength)) ;
	       fseek(fp,header.countOfCounts(),SEEK_SET) ;
	       if (fread(c_of_c,LmCountOfCounts::dataSize(),m_maxlength,fp)
		   != m_maxlength)
		  m_OK = false ;
	       else
		  loadCountOfCounts(c_of_c) ;
	       FrLocalFree(c_of_c) ;
	       fseek(fp,sizeof(header),SEEK_SET) ;
	       size_t buflen = (sizeof(header) +
				m_maxlength*sizeof(LmRecordPointerRecord)) ;
	       FrLocalAlloc(char,buf,1024,buflen) ;
	       if (buf)
		  {
		  fread(buf,sizeof(char),buflen,fp) ;
		  loadRecords(buf,fp,0,max_rank_to_use) ;
		  FrLocalFree(buf) ;
		  }
	       vocab_offset = header.vocabOffset() ;
	       }
	    if (vocab_offset)
	       {
	       m_vocab = new FrVocabulary(fp,filename,vocab_offset) ;
	       if (m_vocab)
		  {
		  off_t offset = vocab_offset + m_vocab->totalDataSize() ;
		  m_surfvocab = new FrVocabulary(fp,filename,offset) ;
		  if (m_surfvocab)
		     {
		     offset += m_surfvocab->totalDataSize() ;
		     m_stopwords = new FrVocabulary(fp,filename,offset) ;
		     if (m_surfvocab->numWords() == 0)
			{
			delete m_surfvocab ;
			m_surfvocab = 0 ;
			}
		     if (m_stopwords && m_stopwords->numWords() == 0)
			{
			delete m_stopwords ;
			m_stopwords = 0 ;
			}
		     }
		  }
	       }
	    }
	 if (fp)
	    fclose(fp) ;
	 }
      }
   if (m_record_counts)
      m_vocabsize = ngramCount(1) ; // vocab size is same as #unigrams
   m_uniform = 1.0 / (m_vocabsize + 1) ;
   computeSmoothingFactors(1) ;		// the speed hit from on-the-fly
					// calc is so big that we always
					// precompute unigram smoothing
   return ;
}

//----------------------------------------------------------------------

LmNGramsFile::~LmNGramsFile()
{
   delete m_vocab ;			m_vocab = 0 ;
   delete m_surfvocab ;			m_surfvocab = 0 ;
   delete m_stopwords ;			m_stopwords = 0 ;
   if (m_fmap)
      {
      FrUnmapFile(m_fmap) ;
      m_fmap = 0 ;
      }
   else
      {
      for (size_t i = 1 ; i < m_maxlength ; i++)
	 FrFree(m_ngram_records[i]) ;
      for (size_t i = 0 ; i+1 < m_maxlength ; i++)
	 {
	 FrFree(m_ngram_next[i]) ;
	 FrFree(m_ngram_disc[i]) ;
	 }
      m_maxlength = 0 ;
      FrFree(m_unigrams) ;
      FrFree(m_discounts) ;
      }
   m_unigrams = 0 ;
   m_discounts = 0 ;
   FrFree(m_record_counts) ;		m_record_counts = 0 ;
   FrFree(m_ngram_records) ;		m_ngram_records = 0 ;
   FrFree(m_ngram_next) ;		m_ngram_next = 0 ;
   FrFree(m_ngram_disc) ;		m_ngram_disc = 0 ;
   delete m_counts ;			m_counts = 0 ;
   delete [] m_countofcounts ;		m_countofcounts = 0 ;
   delete [] m_cumcounts ;		m_cumcounts = 0 ;
   return ;
}

//----------------------------------------------------------------------

bool LmNGramsFile::verifyFormat(const char *filename)
{
   FILE *fp = fopen(filename,FrFOPEN_READ_MODE) ;
   bool success = false ;
   if (fp)
      {
      LmNgramFileHeader header ;
      if (fread(&header,sizeof(char),sizeof(header),fp) == sizeof(header))
	 {
	 if (memcmp(header.m_signature,LmSIGNATURE,
		    sizeof(header.m_signature)) == 0 &&
	     header.m_version == 1 &&
	     header.m_wordID_bits == LmWORDID_BITS &&
	     header.m_countID_bits == LmCOUNTID_BITS &&
	     header.m_countofcounts_max == LmCOUNTOFCOUNTS_MAX)
	    success = true ;
	 }
      fclose(fp) ;
      }
   return success ;
}

//----------------------------------------------------------------------

bool LmNGramsFile::allocPerRankData()
{
   m_ngram_records = FrNewC(LmNgramRecord*,m_maxlength+1) ;
   m_ngram_next = FrNewC(uint32_t*,m_maxlength+1) ;
   m_ngram_disc = FrNewC(uint32_t*,m_maxlength+1) ;
   m_record_counts = FrNewC(size_t,m_maxlength+1) ;
   m_countofcounts = new LmCountOfCounts[m_maxlength+1] ;
   m_cumcounts = new LmCountOfCounts[m_maxlength+1] ;
   return (m_ngram_records && m_ngram_next && m_ngram_disc &&
	   m_record_counts && m_countofcounts && m_cumcounts) ;
}

//----------------------------------------------------------------------

void LmNGramsFile::loadCountOfCounts(const char *data)
{
   if (m_countofcounts)
      {
      for (size_t i = 1 ; i <= m_maxlength ; i++)
	 {
	 new (&m_countofcounts[i]) LmCountOfCounts(data) ;
	 data += LmCountOfCounts::dataSize() ;
	 }
      for (size_t i = 0 ; i <= m_maxlength ; i++)
	 {
	 size_t freq = 0 ;
	 size_t cont = 0;
	 for (int j = LmCOUNTOFCOUNTS_MAX-1 ; j >= 0 ; j--)
	    {
	    freq += m_countofcounts[i].frequency(j) ;
	    cont += m_countofcounts[i].continuations(j) ;
	    m_cumcounts[i].setFrequency(j,freq) ;
	    m_cumcounts[i].setContinuations(j,cont) ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void LmNGramsFile::loadRecords(const char *recptrs, FILE *fp,
			       const char *mappedmem, size_t max_preload_rank) 
{
   LmRecordPointerRecord *pointers = ((LmRecordPointerRecord*)recptrs) - 1 ;
   m_record_counts[0] = 0 ;
   for (unsigned int i = 1 ; i <= m_maxlength ; i++)
      {
      size_t count = pointers[i].count() ;
      m_record_counts[i] = count ;
      if (mappedmem)
	 {
	 if (i == 1)
	    {
	    m_unigrams = (LmUnigramRecord*)(mappedmem + pointers[i].records());
	    if (i <= max_preload_rank)
	       touch_memory(m_unigrams,sizeof(LmUnigramRecord)*count) ;
	    }
	 else
	    {
	    m_ngram_records[i]
	       = (LmNgramRecord*)(mappedmem + pointers[i].records()) ;
	    if (i <= max_preload_rank)
	       touch_memory(m_ngram_records[i],sizeof(LmNgramRecord)*count) ;
	    }
	 if (i < m_maxlength)
	    {
	    if (pointers[i].pointers())
	       {
	       m_ngram_next[i] = (uint32_t*)(mappedmem + pointers[i].pointers()) ;
	       if (i < max_preload_rank)
		  touch_memory(m_ngram_next[i],sizeof(uint32_t)*count+1) ;
	       }
	    else
	       m_ngram_next[i] = 0 ;
	    if (pointers[i].discounts())
	       {
	       m_ngram_disc[i] = (uint32_t*)(mappedmem + pointers[i].discounts());
	       if (i < max_preload_rank)
		  touch_memory(m_ngram_disc[i],sizeof(uint32_t)*count) ;
	       }
	    else
	       m_ngram_disc[i] = 0 ;
	    }
	 }
      else
	 {
	 // allocate memory and read the data from the model file
	 void *where ;
	 size_t recsize ;
	 if (i == 1)
	    {
	    m_unigrams = FrNewN(LmUnigramRecord,count) ;
	    where = m_unigrams ;
	    recsize = sizeof(LmUnigramRecord) ;
	    }
	 else
	    {
	    m_ngram_records[i] = FrNewN(LmNgramRecord,count) ;
	    where = m_ngram_records[i] ;
	    recsize = sizeof(LmNgramRecord) ;
	    }
	 m_ngram_next[i] = FrNewN(uint32_t,count+1) ;
	 m_ngram_disc[i] = 0 ;
	 if (pointers[i].discounts())
	    m_ngram_disc[i] = FrNewN(uint32_t,count) ;
	 if (!m_ngram_records[i] || !m_ngram_next[i] || !m_ngram_disc[i])
	    {
	    m_OK = false ;
	    FrFree(m_ngram_records[i]) ;
	    FrFree(m_ngram_next[i]) ;
	    FrFree(m_ngram_disc[i]) ;
	    FrNoMemory("while loading ngram data") ;
	    break ;
	    }
	 if (fseek(fp,(off_t)pointers[i].records(),SEEK_SET) != 0 ||
	     fread(where,recsize,count,fp) != count)
	    {
	    m_OK = false ;
	    FrWarningVA("error reading ngram records for rank %u from language model file",
			i) ;
	    }
	 if (i == m_maxlength)
	    continue ;
	 if (fseek(fp,(off_t)pointers[i].pointers(),SEEK_SET) != 0 ||
	     fread(m_ngram_next[i],sizeof(uint32_t),count+1,fp) != count+1)
	    {
	    m_OK = false ;
	    FrWarningVA("error reading ngram pointers for rank %u from language model file",
			i) ;
	    }
	 if (m_ngram_disc[i] &&
	     (fseek(fp,(off_t)pointers[i].discounts(),SEEK_SET) != 0 ||
	      fread(m_ngram_disc[i],sizeof(uint32_t),count,fp) != count))
	    {
	    m_OK = false ;
	    FrWarningVA("error reading ngram discounts for rank %u from language model file",
			i) ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void LmNGramsFile::computeSmoothingFactors(size_t rank)
{
   if (rank > 0 && rank < maxNgramLength() && !m_ngram_disc[rank])
      {
      uint32_t *discounts = FrNewN(uint32_t,m_record_counts[rank]) ;
      if (discounts)
	 {
	 for (size_t i = 0 ; i < m_record_counts[rank] ; i++)
	    FrStoreLong((uint32_t)(smoothingFactor(rank,i) *
				   LmDISCOUNT_SCALE_FACTOR + 0.5),
			&discounts[i]) ;
	 m_ngram_disc[rank] = discounts ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

double LmNGramsFile::discountFactor(size_t rank, size_t count) const
{
   return (rank > 0 && rank <= m_maxlength && m_discounts)
      ? m_discounts[rank-1].discount(count)
      : 0.0 ;
}

//----------------------------------------------------------------------

double LmNGramsFile::smoothingFactor(const LmNgramDiscounts *discounts,
				     const LmCountOfCounts *counts,
				     size_t total_count)
{
   double smooth = 0.0 ;
   for (size_t i = 1 ; i <= LmCOUNTOFCOUNTS_MAX ; i++)
      {
      smooth += discounts->discount(i) * counts->continuations(i) ;
      }
   if (total_count)
      smooth /= total_count ;
   if (smooth > 1.999)    // just to be sure we don't overflow....
      smooth = 1.999 ;
   return smooth ;
}

//----------------------------------------------------------------------

double LmNGramsFile::smoothingFactor(size_t rank, uint32_t index) const
{
   if (rank < m_maxlength && index < m_record_counts[rank])
      {
      if (m_ngram_disc && m_ngram_disc[rank])
	 {
	 uint32_t *discount = &m_ngram_disc[rank][index] ;
	 return FrLoadLong(discount) / (double)LmDISCOUNT_SCALE_FACTOR ;
	 }
      else if (m_ngram_next[rank])
	 {
	 // compute the smoothing factor on the fly
	 size_t lo = FrLoadLong(&m_ngram_next[rank][index]) ;
	 size_t hi = FrLoadLong(&m_ngram_next[rank][index+1]) ; 
	 LmCountOfCounts counts ;
	 for (size_t i = lo ; i < hi ; i++)
	    {
	    size_t freq = getCount(rank+1,i) ;
	    counts.incrContinuations(freq) ;
	    }
	 return smoothingFactor(&m_discounts[rank-1],&counts,
				getCount(rank,index)) ;
	 }
      }
   // use a default smoothing factor
   return DEFAULT_SMOOTHING / (rank+1) ;
}

//----------------------------------------------------------------------

uint32_t LmNGramsFile::locateNext(LmWordID_t ID, size_t rank,
				  uint32_t index) const
{
   if (rank == 0)
      {
      // if this is the first word in an ngram, the index is simply the word ID
      return ID ;
      }
   else if (rank < maxNgramLength() && index < m_record_counts[rank] &&
	    ID < m_vocabsize)
      {
      // perform a binary search 
      uint32_t lo = FrLoadLong(&m_ngram_next[rank][index]) ;
      uint32_t hi = FrLoadLong(&m_ngram_next[rank][index+1]) ;
      while (hi > lo)
	 {
	 uint32_t mid = lo + (hi - lo) / 2 ;
	 LmWordID_t midval = m_ngram_records[rank+1][mid].wordID() ;
	 if (ID > midval)
	    lo = mid + 1 ;
	 else if (ID < midval)
	    hi = mid ;
	 else
	    return mid ;
	 }
      }
   // if we get here, there was no match
   return FrVOCAB_WORD_NOT_FOUND ;
}

//----------------------------------------------------------------------

uint32_t LmNGramsFile::getCount(size_t rank, uint32_t index) const
{
   if (rank <= 1)
      {
      if (m_unigrams && index < m_vocabsize)
	 return m_unigrams[index].frequency() ;
      }
   else if (rank <= maxNgramLength() && index < m_record_counts[rank])
      {
      assertq(m_ngram_records != 0 && m_ngram_records[rank] != 0) ;
      LmNgramRecord *rec = &m_ngram_records[rank][index] ;
      return rec->wordCount(m_counts) ;
      }
   return 0 ;
}

//----------------------------------------------------------------------

size_t LmNGramsFile::recordOffset(const LmWordID_t *IDs, size_t numIDs) const
{
   if (numIDs > 0)
      {
      if (!IDs)
	 return m_record_counts[numIDs] ;
      LmWordID_t index = IDs[0] ;
      for (size_t i = 1 ; i < numIDs && index != LmVOCAB_WORD_NOT_FOUND ; i++)
	 {
	 index = locateNext(IDs[i],i,index) ;
	 }
      return index ;
      }
   return FrVOCAB_WORD_NOT_FOUND ;
}

//----------------------------------------------------------------------

uint32_t LmNGramsFile::frequency(const LmWordID_t *IDs, size_t numIDs,
				 uint32_t *rec_index) const
{
   if (numIDs == 0)
      return m_numtokens > UINT32_MAX ? UINT32_MAX : (uint32_t)m_numtokens ;
   else
      {
      LmWordID_t index = IDs[0] ;
      for (size_t i = 1 ; i < numIDs && index != LmVOCAB_WORD_NOT_FOUND ; i++)
	 {
	 index = locateNext(IDs[i],i,index) ;
	 }
      if (rec_index)
	 *rec_index = index ;
      return getCount(numIDs,index) ;
      }
}

//----------------------------------------------------------------------

uint32_t LmNGramsFile::frequency(size_t prev_rank, LmWordID_t ID,
				 uint32_t index) const
{
   index = locateNext(ID,prev_rank,index) ;
   return getCount(prev_rank+1,index) ;
}

//----------------------------------------------------------------------

uint32_t LmNGramsFile::frequency(size_t prev_rank, LmWordID_t ID,
				 uint32_t *index) const
{
   *index = locateNext(ID,prev_rank,*index) ;
   return getCount(prev_rank+1,*index) ;
}

//----------------------------------------------------------------------

static double mean_smoothing_weight(FrLMSmoothing smoothing, size_t len)
{
   switch (smoothing)
      {
      case FrLMSmooth_CubeMean: return (len * len * len) ;
      case FrLMSmooth_QuadMean: return (len * len) ;
      case FrLMSmooth_WtMean:	return len ;
      case FrLMSmooth_ExpMean:  return ::pow(2.0,len) ;
      default:			return 1.0 ;
      }
}

//----------------------------------------------------------------------

void LmNGramsFile::initZerogram(FrNGramHistory *history) const
{
   history->setIndex(0) ;
   history->setCount(m_numtokens > UINT32_MAX
		     ? UINT32_MAX : (uint32_t)m_numtokens) ;
//   history->setSmoothing(DEFAULT_SMOOTHING) ;
   return ;
}

//----------------------------------------------------------------------

double LmNGramsFile::rawCondProbability(const LmWordID_t *history,
					size_t histlen, LmWordID_t ID,
					size_t class_size) const
{
   if (histlen == 0 || !history)
      {
      if (ID < m_vocabsize)
	 return m_unigrams[ID].frequency() / (double)m_numtokens ;
      else
	 return m_uniform ;
      }
   uint32_t index = 0 ;
   size_t allcounts = frequency(history,histlen,&index) ;
   if (allcounts)
      {
      size_t count = frequency(histlen,ID,index) ;
      return count / (double)(allcounts * class_size) ;
      }
   else
      return 0.0 ;
}

//----------------------------------------------------------------------

double LmNGramsFile::rawCondProbability(FrNGramHistory *history,
					size_t histlen, LmWordID_t ID,
					size_t class_size) const
{
   if (!history)
      {
      if (ID < m_vocabsize)
	 return m_unigrams[ID].frequency() / (double)m_numtokens ;
      else
	 return m_uniform ;
      }
   else if (histlen == 0)
      {
      if (ID < m_vocabsize)
	 {
	 size_t allcounts = m_numtokens ;
	 size_t count = m_unigrams[ID].frequency() ;
	 history[1].setIndex(ID) ;
	 history[1].setCount(count) ;
	 return count / (double)(allcounts * class_size) ;
	 }
      else
	 {
	 history[1].setIndex(LmVOCAB_WORD_NOT_FOUND) ;
	 history[1].setCount(0) ;
	 return m_uniform ;
	 }
      }
   size_t allcounts = history[histlen].count() ;
   if (allcounts)
      {
      uint32_t index = history[histlen].index() ;
      size_t count = frequency(histlen,ID,&index) ;
      history[histlen+1].setIndex(index) ;
      history[histlen+1].setCount(count) ;
      return count / (double)(allcounts * class_size) ;
      }
   else
      {
      history[histlen+1].setIndex(LmVOCAB_WORD_NOT_FOUND) ;
      history[histlen+1].setCount(0) ;
      return 0.0 ;
      }
}

//----------------------------------------------------------------------

size_t LmNGramsFile::longestMatch(const LmWordID_t *IDs, size_t numIDs) const
{
   if (!IDs || numIDs == 0)
      return 0 ;
   LmWordID_t index = IDs[0] ;
   size_t match = 0 ;
   for (size_t i = 1 ; i < numIDs && index != LmVOCAB_WORD_NOT_FOUND ; i++)
      {
      match++ ;
      index = locateNext(IDs[i],i,index) ;
      }
   if (index != LmVOCAB_WORD_NOT_FOUND)
      match++ ;
   return match ;
}

//----------------------------------------------------------------------

double LmNGramsFile::probabilityKN(const LmWordID_t *IDs, size_t numIDs,
				   size_t *max_exist) const
{
   double prob = m_uniform ;
   LmWordID_t last_ID = IDs[numIDs-1] ;
   // if the predicted word is a member of an equivalence class, we
   //   need to divide by the size of the class in order to estimate
   //   the average probability for one member of the class instead of
   //   the total probability of encountering any member of the class
   size_t class_size = classSize(last_ID) ;
   size_t max_rank = 0 ;
   size_t rank ;
   for (rank = 1 ; rank <= numIDs ; rank++)
      {
      // get the conditional probability for the current rank and add it to
      //   the smoothed probability for the lower ranks
      uint32_t index = 0 ;
      size_t allcounts = frequency(IDs+numIDs-rank,rank-1,&index) ;
      prob *= smoothingFactor(rank-1,index) ;
      if (allcounts)
	 {
	 size_t count = frequency(rank-1,last_ID,index) ;
	 if (count)
	    {
	    double discount = discountFactor(rank,count) ;
	    prob += ((count - discount) / (allcounts * class_size)) ;
	    max_rank = rank ;
	    }
	 }
      else
	 break ;
      }
   if (max_exist && max_rank > *max_exist)
      *max_exist = max_rank ;
   // apply smoothing factor for all ranks which have no occurrences in the
   //   training data
   for (rank = rank + 1 ; rank <= numIDs ; rank++)
      {
      prob *= smoothingFactor(rank-1,LmVOCAB_WORD_NOT_FOUND) ;
      }
   return prob ;
}

//----------------------------------------------------------------------

double LmNGramsFile::probabilityKN(const FrNGramHistory *history,
				   FrNGramHistory *newhistory, size_t numIDs,
				   LmWordID_t ID, size_t *max_exist) const
{
   double prob = m_uniform ;
   // if the predicted word is a member of an equivalence class, we
   //   need to divide by the size of the class in order to estimate
   //   the average probability for one member of the class instead of
   //   the total probability of encountering any member of the class
   size_t class_size = classSize(ID) ;
   size_t max_rank = 0 ;
   for (size_t rank = 1 ; rank <= numIDs ; rank++)
      {
      uint32_t index = history[rank-1].index() ;
      size_t allcounts = history[rank-1].count() ;
      size_t count ;
      prob *= smoothingFactor(rank-1,index) ;
      if (allcounts)
	 {
	 count = frequency(rank-1,ID,&index) ;
	 if (count)
	    {
	    double discount = discountFactor(rank,count) ;
	    prob += ((count - discount) / (allcounts * class_size)) ;
	    max_rank = rank ;
	    }
	 }
      else
	 {
	 index = LmVOCAB_WORD_NOT_FOUND ;
	 count = 0 ;
	 }
      // write the updated history entries
      newhistory[rank].setIndex(index) ;
      newhistory[rank].setCount(count) ;
//      newhistory[rank].setSmoothing(smoothingFactor(rank,index)) ;
      }
   if (max_exist && max_rank > *max_exist)
      *max_exist = max_rank ;
   return prob ;
}

//----------------------------------------------------------------------

double LmNGramsFile::probabilityMax(const LmWordID_t *IDs, size_t numIDs,
				    size_t *max_exist) const
{
   // if the predicted word is a member of an equivalence class, we
   //   need to divide by the size of the class in order to estimate
   //   the average probability for one member of the class instead of
   //   the total probability of encountering any member of the class
   LmWordID_t ID = IDs[numIDs-1] ;
   size_t class_size = classSize(ID) ;
   size_t maxrank = 0 ;
   double prob = 0.0 ;
   const LmWordID_t *lastID = &IDs[numIDs] ;
   for (size_t i = 0 ; i < numIDs ; i++)
      {
      double rawprob = rawCondProbability(lastID-i,i,ID,class_size) ;
      if (rawprob <= 0.0)
	 break ;
      else if (rawprob > prob)
	 prob = rawprob ;
      maxrank = i+1 ;
      }
   if (max_exist)
      *max_exist = maxrank ;
   return prob ;
}

//----------------------------------------------------------------------

double LmNGramsFile::probabilityMax(FrNGramHistory *history, size_t numIDs,
				    LmWordID_t ID, size_t *max_exist) const
{
   // if the predicted word is a member of an equivalence class, we
   //   need to divide by the size of the class in order to estimate
   //   the average probability for one member of the class instead of
   //   the total probability of encountering any member of the class
   size_t class_size = classSize(ID) ;
   size_t maxrank = 0 ;
   double prob = 0.0 ;
   for (size_t rank = numIDs ; rank > 0 ; rank--)
      {
      double rawprob = rawCondProbability(history,rank-1,ID,class_size) ;
      if (rawprob > prob)
	 prob = rawprob ;
      if (!maxrank && prob > 0.0)
	 {
	 maxrank = rank ;
	 if (max_exist)
	    *max_exist = maxrank ;
	 }
      }
   return prob ;
}

//----------------------------------------------------------------------

double LmNGramsFile::probabilityMean(const LmWordID_t *IDs, size_t numIDs,
				     size_t *max_exist) const
{
   // if the predicted word is a member of an equivalence class, we
   //   need to divide by the size of the class in order to estimate
   //   the average probability for one member of the class instead of
   //   the total probability of encountering any member of the class
   LmWordID_t ID = IDs[numIDs-1] ;
   size_t class_size = classSize(ID) ;
   size_t maxrank = 0 ;
   double totalwt = 0.0 ;
   double prob = 0.0 ;
   const LmWordID_t *lastID = &IDs[numIDs-1] ;
   for (size_t i = 0 ; i < numIDs ; i++)
      {
      double rawprob = rawCondProbability(lastID-i,i,ID,class_size) ;
      if (rawprob <= 0.0)
	 break ;
      maxrank = i+1 ;
      double wt = mean_smoothing_weight(smoothing(),maxrank) ;
      totalwt += wt ;
      prob += wt * rawprob ;
      }
   for (size_t i = maxrank ; i < numIDs ; i++)
      totalwt += mean_smoothing_weight(smoothing(),i+1) ;
   if (max_exist)
      *max_exist = maxrank ;
   return prob / totalwt ;
}

//----------------------------------------------------------------------

double LmNGramsFile::probabilityMean(FrNGramHistory *history, size_t numIDs,
				     LmWordID_t ID, size_t *max_exist) const
{
   // if the predicted word is a member of an equivalence class, we
   //   need to divide by the size of the class in order to estimate
   //   the average probability for one member of the class instead of
   //   the total probability of encountering any member of the class
   size_t class_size = classSize(ID) ;
   size_t maxrank = 0 ;
   double totalwt = 0.0 ;
   double prob = 0.0 ;
   for (size_t rank = numIDs ; rank > 0 ; rank--)
      {
      double rawprob = rawCondProbability(history,rank-1,ID,class_size) ;
      double wt = mean_smoothing_weight(smoothing(),rank) ;
      totalwt += wt ;
      prob += wt * rawprob ;
      if (!maxrank && rawprob > 0.0)
	 {
	 maxrank = rank ;
	 if (max_exist)
	    *max_exist = maxrank ;
	 }
      }
   return prob / totalwt ;
}

//----------------------------------------------------------------------

double LmNGramsFile::probabilityBackoff(const LmWordID_t *IDs, size_t numIDs,
					size_t *max_exist) const
{
   // if the predicted word is a member of an equivalence class, we
   //   need to divide by the size of the class in order to estimate
   //   the average probability for one member of the class instead of
   //   the total probability of encountering any member of the class
   LmWordID_t ID = IDs[numIDs-1] ;
   size_t class_size = classSize(ID) ;
   // get the raw, unsmoothed conditional probability
   double rawprob = rawCondProbability(IDs,numIDs-1,ID,class_size) ;
   // now apply the requested smoothing
   if (rawprob > 0.0 && max_exist && numIDs > *max_exist)
      *max_exist = numIDs ;
   if (rawprob > 0.0)
      return rawprob ;
   else if (smoothing() == FrLMSmooth_StupidBackoff)
      return FramepaC_StupidBackoff_alpha * probabilityBackoff(IDs+1,numIDs-1);
   else if (smoothing() == FrLMSmooth_Backoff)
      return probabilityBackoff(IDs+1,numIDs-1) ;
   else
      return 0.0 ;
}

//----------------------------------------------------------------------

double LmNGramsFile::probabilityBackoff(FrNGramHistory *history,
					size_t numIDs, LmWordID_t ID,
					size_t *max_exist) const
{
   // if the predicted word is a member of an equivalence class, we
   //   need to divide by the size of the class in order to estimate
   //   the average probability for one member of the class instead of
   //   the total probability of encountering any member of the class
   size_t class_size = classSize(ID) ;
   // get the raw, unsmoothed conditional probability
   double prob = 0.0 ;
   double backoff_factor = 0.0 ;
   if (smoothing() == FrLMSmooth_StupidBackoff)
      backoff_factor = FramepaC_StupidBackoff_alpha ;
   else if (smoothing() == FrLMSmooth_Backoff)
      backoff_factor = 1.0 ;
   double backoff = 0.0 ;
   for (size_t rank = numIDs ; rank > 0 ; rank--)
      {
      double rawprob = rawCondProbability(history,rank-1,ID,
					  class_size) ;
      if (rawprob > 0.0)
	 {
	 if (max_exist && rank > *max_exist)
	    *max_exist = rank ;
	 if (prob == 0.0)
	    prob = rawprob ;
	 }
      else
	 {
	 backoff_factor *= backoff ;
	 }
      }
   return prob * backoff_factor ;
}

//----------------------------------------------------------------------

double LmNGramsFile::probability(const LmWordID_t *IDs, size_t numIDs,
				 size_t *max_exist) const
{
   if (numIDs > maxNgramLength())
      {
      // if we are given more history than is present in the model, ignore
      //   the start of the history
      IDs += (numIDs - maxNgramLength()) ;
      numIDs = maxNgramLength() ;
      }
   if (numIDs > 0 && IDs)
      {
      switch (smoothing())
	 {
	 case FrLMSmooth_SimpKN:
	    return probabilityKN(IDs,numIDs,max_exist) ;
	 case FrLMSmooth_None:
	 case FrLMSmooth_Backoff:
	 case FrLMSmooth_StupidBackoff:
	    return probabilityBackoff(IDs,numIDs,max_exist) ;
	 case FrLMSmooth_Max:
	    return probabilityMax(IDs,numIDs,max_exist) ;
	 case FrLMSmooth_Mean:
	 case FrLMSmooth_WtMean:
	 case FrLMSmooth_QuadMean:
	 case FrLMSmooth_CubeMean:
	 case FrLMSmooth_ExpMean:
	    return probabilityMean(IDs,numIDs,max_exist) ;
	 default:
	    FrMissedCase("LmNGramsFile::probability") ;
	 }
      }
   return m_uniform ;
}

//----------------------------------------------------------------------

double LmNGramsFile::probability(FrNGramHistory *hist, size_t numIDs,
				 LmWordID_t ID, size_t *max_exist) const
{
   if (numIDs > maxNgramLength())
      {
      // if we are given more history than is present in the model, ignore
      //   the "extra" history
      numIDs = maxNgramLength() ;
      }
   if (numIDs > 0)
      {
      switch (smoothing())
	 {
	 case FrLMSmooth_SimpKN:
	    {
	    FrNGramHistory histbuf[numIDs+2] ;
	    double prob = probabilityKN(hist,histbuf,numIDs,ID,max_exist) ;
	    for (size_t i = 1 ; i <= numIDs ; i++)
	       hist[i] = histbuf[i] ;
	    return prob ;
	    }
	 case FrLMSmooth_None:
	 case FrLMSmooth_Backoff:
	 case FrLMSmooth_StupidBackoff:
	    return probabilityBackoff(hist,numIDs,ID,max_exist) ;
	 case FrLMSmooth_Max:
	    return probabilityMax(hist,numIDs,ID,max_exist) ;
	 case FrLMSmooth_Mean:
	 case FrLMSmooth_WtMean:
	 case FrLMSmooth_QuadMean:
	 case FrLMSmooth_CubeMean:
	 case FrLMSmooth_ExpMean:
	    return probabilityMean(hist,numIDs,ID,max_exist) ;
	 default:
	    FrMissedCase("LmNGramsFile::probability") ;
	 }
      }
   return m_uniform ;
}

//----------------------------------------------------------------------

double LmNGramsFile::probability(const char * const *words,
				 size_t numwords, size_t *max_exist) const
{
   FrLocalAllocC(LmWordID_t,IDs,128,numwords) ;
   if (IDs && m_vocab)
      {
      for (size_t i = 0 ; i < numwords ; i++)
	 {
	 IDs[i] = m_vocab->findID(words[i]) ;
	 }
      double prob = probability(IDs,numwords,max_exist) ;
      FrLocalFree(IDs) ;
      return prob ;
      }
   else if (IDs)
      {
      FrLocalFree(IDs) ;
      }
   else
      FrNoMemory("while converting words to wordIDs to compute ngram probability") ;
   return m_uniform ;
}

//----------------------------------------------------------------------

double LmNGramsFile::probability(const FrList *words) const
{
   size_t numwords = words->simplelistlength() ;
   if (numwords > 0 && m_vocab)
      {
      FrLocalAllocC(LmWordID_t,IDs,256,numwords) ;
      if (IDs)
	 {
	 for (size_t i = 0 ; i < numwords ; i++, words = words->rest())
	    {
	    IDs[i] = m_vocab->findID(FrPrintableName(words->first())) ;
	    }
	 double prob = probability(IDs,numwords) ;
	 FrLocalFree(IDs) ;
	 return prob ;
	 }
      else
	 FrNoMemory("while converting words to wordIDs to compute ngram probability") ;
      }
   return m_uniform ;
}

//----------------------------------------------------------------------

double LmNGramsFile::perplexity(size_t rank, bool use_entropy) const
{
   if (rank < 2 || rank > maxNgramLength())
      return -1 ;			// can't compute avg fan-out
   if (!m_ngram_next[rank-1])
      return -1 ;
   double perp = 0.0 ;
   for (size_t hist = 0 ; hist < ngramCount(rank-1) ; hist++)
      {
      uint32_t hist_freq = getCount(rank-1,hist) ;
      uint32_t total_freq = 0 ;
      uint32_t first_succ = FrLoadLong(&m_ngram_next[rank-1][hist]) ;
      uint32_t last_succ = FrLoadLong(&m_ngram_next[rank-1][hist+1]) ;
      if (use_entropy)
	 {
	 for (size_t i = first_succ  ; i < last_succ ; i++)
	    {
	    uint32_t freq = getCount(rank,i) ;
	    if (freq > hist_freq)
	       continue ;
	    double prob = freq / (double)hist_freq ;
	    perp -= prob * ::log(prob) / M_LN2 ; // convert ln(X) to log_2(X)
	    total_freq += freq ;
	    }
	 // account for predicted EOR, which isn't stored
	 if (total_freq < hist_freq)
	    {
	    double prob = (hist_freq - total_freq) / (double)hist_freq ;
	    perp -= prob * ::log(prob) / M_LN2 ; // convert ln(X) to log_2(X)
	    }
	 }
      else
	 {
	 uint32_t num_succ = last_succ - first_succ ;
	 if (num_succ > 0)
	    perp += ::log(num_succ) ;
	 }
      }
   if (use_entropy)
      return ::pow(2.0,perp / ngramCount(rank-1)) ;
   else
      return ::exp(perp / ngramCount(rank-1)) ;
}

//----------------------------------------------------------------------

static void dump_ngrams(FILE *outfp, size_t rank, size_t maxrank,
			size_t start, size_t end,
			const size_t *rec_counts,
			const LmUnigramRecord *unigrams,
			const LmNgramRecord * const *ngram_records,
			const uint32_t * const *next,
			const uint32_t * const *disc,
			FrVocabulary *vocab, const LmCountMap *countmap,
			LmWordID_t *IDs)
{
   if (rank > maxrank)
      return ;
   for (size_t i = start ; i < end ; i++)
      {
      LmWordID_t id ;
      uint32_t freq ;
      size_t csize = 0 ;
      if (rank == 1)
	 {
	 id = i ;
	 freq = unigrams[i].frequency() ;
	 csize = unigrams[i].classSize() ;
	 }
      else
	 {
	 id = ngram_records[rank][i].wordID() ;
	 freq = ngram_records[rank][i].wordCount(countmap) ;
	 }
      IDs[rank-1] = id ;
      for (size_t j = 0 ; j < rank ; j++)
	 {
	 const char *word = vocab->nameForID(IDs[j]) ;
	 fprintf(outfp,"%s ",word) ;
	 }
      fprintf(outfp,"(%lu",(unsigned long)freq) ;
      if (csize)
	 fprintf(outfp,"/%lu",(unsigned long)csize) ;
      if (disc[rank])
	 fprintf(outfp,",%g) @ %lu\n",
		 FrLoadLong(&disc[rank][i])/(double)LmDISCOUNT_SCALE_FACTOR,
		 (unsigned long)i) ;
      else
	 fprintf(outfp,")\n") ;
      if (rank < maxrank && next[rank])
	 dump_ngrams(outfp,rank+1,maxrank,FrLoadLong(&next[rank][i]),
		     FrLoadLong(&next[rank][i+1]),
		     rec_counts,unigrams,ngram_records,next,disc,vocab,
		     countmap,IDs) ;
      }
   return ;
}

//----------------------------------------------------------------------

bool LmNGramsFile::dump(FILE *outfp, const char *modelname,
			bool verbose) const
{
   bool success = false ;
   if (outfp)
      {
      success = true ;
      fprintf(outfp,"==== Dump of %s ====\n",modelname) ;
      if (OK())
	 {
	 if (m_counts)
	    fprintf(outfp,"Using %lu of %lu countIDs\n",
		    m_counts->numCountsUsed(),m_counts->numCounts()) ;
	 for (size_t rank = 1 ; rank <= maxNgramLength() ; rank++)
	    {
	    fprintf(outfp,"  %lu-grams: %lu",(unsigned long)rank,
		    ngramCount(rank)) ;
	    if (m_ngram_disc[rank])
	       fprintf(outfp," (smoothing precomputed)") ;
	    fprintf(outfp,"\n") ;
	    fprintf(outfp,"\tglobal discounts:") ;
	    size_t limit = LmCOUNTOFCOUNTS_MAX ;
	    if (num_discount_levels < limit)
	       limit = num_discount_levels ;
	    for (size_t i = 1 ; i <= limit ; i++)
	       {
	       fprintf(outfp," %g",discountFactor(rank,i)) ;
	       }
	    fprintf(outfp,"\n") ;
	    fprintf(outfp,"\tfrequencies:") ;
	    for (size_t i = 1 ; i <= LmCOUNTOFCOUNTS_MAX ; i++)
	       {
	       fprintf(outfp," %lu",
		       (unsigned long)m_countofcounts[rank].frequency(i)) ;
	       }
	    fprintf(outfp,"\n") ;
	    }
	 if (m_vocab)
	    {
	    if (verbose)
	       {
	       m_vocab->createReverseMapping() ;
	       FrLocalAllocC(LmWordID_t,IDs,128,maxNgramLength()) ;
	       dump_ngrams(outfp, 1,maxNgramLength(), 0,ngramCount(1),
			   m_record_counts, m_unigrams, m_ngram_records,
			   m_ngram_next, m_ngram_disc, m_vocab, m_counts,IDs) ;
	       FrLocalFree(IDs) ;
	       }
	    }
	 else
	    {
	    fprintf(outfp,
		    "**** unable to dump ngrams (no vocabulary) ****\n") ;
	    success = false ;
	    }
	 }
      else
	 fprintf(outfp,
		 "**** unable to dump ngrams file (data not valid) ****\n") ;
      fprintf(outfp,"==== end of dump ====\n") ;
      }
   return success ;
}

// end of file lmxgram.cpp //
