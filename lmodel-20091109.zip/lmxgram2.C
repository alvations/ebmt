/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lxngram2.cpp	fixed-length smoothed n-gram model generation	*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2006,2007,2008,2009 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmngram.h"
#include "lmxgram.h"
#include "lmglobal.h"

#ifdef FrSTRICT_CPLUSPLUS
#  include <cmath>
#else
#  include <math.h>
#endif /* FrSTRICT_CPLUSPLUS */

#ifdef __SUNOS__
#  include <sys/unistd.h>
#elif defined(unix)
#  include <unistd.h>
#elif defined(__MSDOS__) || defined(__WATCOMC__) || defined(_MSC_VER)
#  include <io.h>
#  include <dos.h>
#endif /* __SUNOS__ || unix || __MSDOS__ || _MSC_VER */

/************************************************************************/
/*	Types for this module						*/
/************************************************************************/

typedef bool ProcessFn(FILE *, va_list) ;

/************************************************************************/
/*	Helper functions						*/
/************************************************************************/

static FrList *get_file_list(const char *filename)
{
   FrList *files = 0 ;
   if (filename && *filename)
      {
      if (*filename == '@')
	 {
	 // read the list of files to use from the named file
	 bool piped ;
	 FILE *fp = FrOpenMaybeCompressedInfile(filename+1,piped) ;
	 if (fp)
	    {
	    FrList **end = &files ;
	    while (!feof(fp))
	       {
	       char line[FrMAX_LINE] ;
	       if (!fgets(line,sizeof(line),fp))
		  break ;
	       char *last = strchr(line,';') ;
	       if (last)
		  *last = '\0' ;
	       char *lineptr = line ;
	       FrTrimWhitespace(lineptr) ;
	       if (*lineptr)
		  files->pushlistend(new FrString(lineptr),end) ;
	       }
	    FrCloseMaybeCompressedInfile(fp,piped) ;
	    }
	 else
	    FrWarningVA("unable to open listing file %s",filename+1) ;
	 }
      else
	 {
	 // use the named file as-is
	 files = new FrList(new FrString(filename)) ;
	 }
      }
   return files ;
}

//----------------------------------------------------------------------

static bool process_files(const char *filespec, ProcessFn *fn, ...)
{
   FrList *filelist = get_file_list(filespec) ;
   bool success = false ;
   if (fn)
      {
      success = true ;
      for (FrList *files = filelist ; files && success ; files = files->rest())
	 {
	 const char *file = FrPrintableName(files->first()) ;
	 if (!file || !*file)
	    continue ;
	 cout << "   processing file " << file << endl ;
	 bool piped = false ;
	 FILE *fp = FrOpenMaybeCompressedInfile(file,piped) ;
	 FrVarArgs(fn) ;
	 if (fp && !fn(fp,args))
	    success = false ;
	 FrVarArgEnd() ;
	 FrCloseMaybeCompressedInfile(fp,piped) ;
	 }
      }
   free_object(filelist) ;
   return success ;
}

//----------------------------------------------------------------------

static bool add_to_vocab(FILE *fp, va_list args)
{
   FrVarArg(FrVocabulary*,vocab) ;
   bool success = true ;
   size_t ID = vocab->numWords() ;
   vocab->startBatchUpdate() ;
   while (!feof(fp))
      {
      char line[FrMAX_LINE] ;
      if (!fgets(line,sizeof(line),fp))
	 break ;
      // parse out the word at the beginning of the line
      char *end = line + strcspn(line," \t") ;
      *end = '\0' ;
      // remap the word to match how it will appear at runtime
      bool is_poss = false ;
      const char *remapped = LmNGramModel::remapWord(line,wordstem_ht,is_poss,
						     !ignore_case,
						     build_affix_sizes) ;
      // if the remapped word is already in the vocabulary, use the existing
      //   ID for the surface form
      LmWordID_t oldID = vocab->findID(remapped) ;
      if (oldID == LmVOCAB_WORD_NOT_FOUND)
	 (void)vocab->addWord(line,ID++) ;
      else
	 (void)vocab->addWord(line,oldID) ;
      }
   vocab->finishBatchUpdate() ;
   return success ;
}

//----------------------------------------------------------------------

static size_t split_line(char *line, size_t rank, uint32_t *IDs,
			 FrVocabulary *vocab, size_t scaling_factor)
{
   // parse line into the specified number of words and a frequency count
   char *word = line ;
   for (size_t i = 0 ; i < rank ; i++)
      {
      char *end = word + strcspn(word," \t") ;
      if (!*end)
	 return 0 ;		// invalid line
      *end = '\0' ;
      IDs[i] = vocab->findID(word) ;
      word = end + 1 ;
      FrSkipWhitespace(word) ;
      }
   FrSkipWhitespace(word) ;
   if (!*word)
      return 0 ;
   size_t freq = strtoul(word,0,0) ;
   if (freq > 0 && freq <= scaling_factor)
      freq = 1 ;
   else if (freq > scaling_factor)
      freq = (freq + scaling_factor / 2) / scaling_factor ;
   return freq ;
}

//----------------------------------------------------------------------

static bool convert_unigrams(FILE *fp, va_list args)
{
   FrVarArg(FrVocabulary*,vocab) ;
   FrVarArg(LmUnigramRecord*,uni) ;
   FrVarArg(size_t,last_id) ;
   FrVarArg(LmCountOfCounts*,counts) ;
   FrVarArg(size_t,scaling_factor) ;
   while (!feof(fp))
      {
      char line[FrMAX_LINE] ;
      if (!fgets(line,sizeof(line),fp))
	 break ;
      uint32_t ID ;
      size_t freq = split_line(line,1,&ID,vocab,scaling_factor) ;
      counts->incrFrequency(freq) ;
      if (ID <= last_id)
	 uni[ID].setFrequency(freq) ;
      }
   return true ;
}

//----------------------------------------------------------------------

static void update_lower_rank(FILE *tmpfp, uint32_t *offset,
			      uint32_t *hist_count, size_t total_count,
			      uint32_t *next_pointers, 
			      const LmNgramDiscounts *discounts,
			      LmCountOfCounts *curr_counts,
			      LmNGramsFile *ngmodel = 0, LmWordID_t *IDs = 0,
			      size_t rank = 0)
{
   // we have a new history, so we need to remember the "next" pointer
   //   for the previous rank and update its count-of-counts values
   if (!IDs || IDs[rank] != LmVOCAB_WORD_NOT_FOUND)
      {
      FrStoreLong(*offset,&next_pointers[++(*hist_count)]) ;
      if (tmpfp)
	 {
	 // also need to write out the smoothing factor for the previous
	 //   history
	 double disc = LmNGramsFile::smoothingFactor(discounts,curr_counts,
						     total_count) ;
	 uint32_t smoothing ;
	 FrStoreLong((uint32_t)(disc * LmDISCOUNT_SCALE_FACTOR + 0.5),
		     &smoothing) ;
	 (void)Fr_fwrite(&smoothing,sizeof(smoothing),tmpfp) ;
	 }
      }
   curr_counts->clearContinuations() ;
   if (ngmodel)
      {
      // check whether we've skipped any ngrams and thus need to duplicate
      //   the "next" pointer
      size_t rec_offset = ngmodel->recordOffset(IDs,rank) ;
      if (rec_offset != FrVOCAB_WORD_NOT_FOUND)
	 {
	 uint32_t smoothing ;
	 // since the (N)-gram may be missing because it was pruned due to
	 //   low frequency, we'll set the smoothing such that the full weight
	 //   of the (N-1)-gram is used if we ever do look up the probability
	 //   of the (N)-gram
	 FrStoreLong((uint32_t)((1.0 * LmDISCOUNT_SCALE_FACTOR) + 0.5),
		     &smoothing) ;
	 while (*hist_count < rec_offset)
	    {
	    FrStoreLong(*offset,&next_pointers[++(*hist_count)]) ;
	    if (tmpfp)
	       (void)Fr_fwrite(&smoothing,sizeof(smoothing),tmpfp) ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static void copy_history(uint32_t *IDs, uint32_t *history, size_t histsize)
{
   for (size_t i = 0 ; i < histsize ; i++)
      history[i] = IDs[i] ;
   return ;
}

//----------------------------------------------------------------------

static bool same_history(uint32_t *IDs, uint32_t *history,
			   size_t histsize, bool initialize = false)
{
   if (initialize)
      {
      copy_history(IDs,history,histsize) ;
      return false ;
      }
   else
      {
      for (size_t i = histsize ; i > 0 ; i--)
	 {
	 if (IDs[i-1] != history[i-1])
	    return false ;
	 }
      return true ;
      }
}

//----------------------------------------------------------------------

static bool convert_counts(FILE *fp, va_list args)
{
   FrVarArg(FrVocabulary*,vocab) ;
   FrVarArg(size_t,rank) ;
   FrVarArg(FILE*,outfp) ;
   FrVarArg(FILE*,tmpfp) ;
   FrVarArg(uint32_t*,history) ;
   FrVarArg(uint32_t*,offset) ;
   FrVarArg(uint32_t*,hist_count) ;
   FrVarArg(size_t*,total_count) ;
   FrVarArg(uint32_t*,next_pointers) ;
   FrVarArg(LmCountOfCounts*,curr_counts) ;
   FrVarArg(LmCountOfCounts*,prevrank_counts) ;
   FrVarArg(const LmNgramDiscounts*,discounts) ;
   FrVarArg(LmCountMap*,countmap) ;
   FrVarArg(size_t,scaling_factor) ;
   FrVarArg(LmNGramsFile*,ngmodel) ;
   FrLocalAlloc(uint32_t,IDs,128,rank+1) ;
   bool success = true ;
   while (!feof(fp))
      {
      char line[FrMAX_LINE] ;
      if (!fgets(line,sizeof(line),fp))
	 break ;
      size_t freq = split_line(line,rank,IDs,vocab,scaling_factor) ;
      if (IDs[rank-1] != (LmWordID_t)FrBWT_ENDOFDATA)
	 {
	 curr_counts->incrFrequency(freq) ;
	 prevrank_counts->incrContinuations(freq) ;
	 }
      if (!same_history(IDs,history,rank-1,*offset==0))
	 {
	 bool initial = (history[0] == LmVOCAB_WORD_NOT_FOUND) ;
	 if (!initial)
	    {
	    update_lower_rank(tmpfp,offset,hist_count,*total_count,
			      next_pointers,discounts,curr_counts,ngmodel,
			      IDs,rank-1) ;
	    *total_count = 0 ;
	    }
	 copy_history(IDs,history,rank-1) ;
	 }
      if (IDs[rank-1] != (LmWordID_t)FrBWT_ENDOFDATA)
	 {
	 curr_counts->incrContinuations(freq) ;
	 *total_count += freq ;
	 uint32_t countID = countmap->countID(freq) ;
	 LmNgramRecord ngram(IDs[rank-1],countID) ;
	 (*offset)++ ;
	 if (!ngram.write(outfp))
	    {
	    success = false ;
	    break ;
	    }
	 }
      }
   FrLocalFree(IDs) ;
   return success ;
}

//----------------------------------------------------------------------

static void save_vocabularies(LmNgramFileHeader &header, FILE *fp,
			      FrVocabulary *vocab, FrVocabulary *surfvocab,
			      FrVocabulary *stopwords)
{
   header.setVocabOffset(ftell(fp)) ;
   vocab->save(fp,ftell(fp)) ;
   if (surfvocab || stopwords)
      {
      header.setSurfVocabOffset(ftell(fp)) ;
      if (surfvocab)
	 surfvocab->save(fp,ftell(fp)) ;
      else
	 {
	 surfvocab = new FrVocabulary() ;
	 surfvocab->useNameAsID(true) ;
	 surfvocab->setScaleFactor(0) ;
	 surfvocab->save(fp,ftell(fp)) ;
	 delete surfvocab ;
	 }
      header.setStopWordOffset(ftell(fp)) ;
      if (stopwords)
	 stopwords->save(fp,ftell(fp)) ;
      else
	 {
	 stopwords = new FrVocabulary() ;
	 stopwords->useNameAsID(true) ;
	 stopwords->setScaleFactor(0) ;
	 stopwords->save(fp,ftell(fp)) ;
	 delete stopwords ;
	 }
      }
   return ;
}

/************************************************************************/
/*	class LmNGramModel						*/
/************************************************************************/

bool LmNGramModel::convertBWTtoNGM(const char *destfile, size_t rank,
				     size_t precomp_rank) const
{
   if (ngramModel() && vocabulary())
      return LmNGramsFile::convert(destfile,ngramModel(),vocabulary(),rank,
				   precomp_rank,char_based_model,false,
				   m_surfvocab,m_stopwords) ;
   return false ;
}

/************************************************************************/
/*	class LmNGramsFile						*/
/************************************************************************/

static bool convert_unigrams(uint32_t *IDs, size_t /*N*/, size_t freq,
			       const class FrBWTIndex */*index*/,
			       va_list args)
{
   FrVarArg(LmUnigramRecord*,uni) ;
   FrVarArg(LmWordID_t,max_ID) ;
   FrVarArg(LmCountOfCounts*,counts) ;
   if (IDs[0] <= max_ID)
      uni[IDs[0]].setFrequency(freq) ;
   counts->incrFrequency(freq) ;
   return true ;
}

//----------------------------------------------------------------------

static bool convert_ngrams(uint32_t *IDs, size_t N, size_t freq,
			     const class FrBWTIndex */*index*/,
			     va_list args)
{
   FrVarArg(FILE *,fp) ;
   FrVarArg(FILE*,tmpfp) ;
   FrVarArg(LmWordID_t*,history) ;
   FrVarArg(uint32_t*,offset) ;
   FrVarArg(uint32_t*,hist_count) ;
   FrVarArg(size_t*,total_count) ;
   FrVarArg(uint32_t*,next_pointers) ;
   FrVarArg(LmCountOfCounts*,curr_counts) ;
   FrVarArg(LmCountOfCounts*,prevrank_counts) ;
   FrVarArg(const LmNgramDiscounts*,discounts) ;
   FrVarArg(LmCountMap*,countmap) ;
   if (IDs[N-1] != (LmWordID_t)FrBWT_ENDOFDATA)
      {
      curr_counts->incrFrequency(freq) ;
      prevrank_counts->incrContinuations(freq) ;
      }
   if (*offset == 0 || !same_history(IDs,history,N-1,*offset==0))
      {
      if (*offset)
	 {
	 update_lower_rank(tmpfp,offset,hist_count,*total_count,
			   next_pointers,discounts,curr_counts) ;
	 *total_count = 0 ;
	 }
      copy_history(IDs,history,N-1) ;
      }
   curr_counts->incrContinuations(freq) ;
   if (IDs[N-1] != (LmWordID_t)FrBWT_ENDOFDATA)
      {
      *total_count += freq ;
      uint32_t countID = countmap->countID(freq) ;
      LmNgramRecord ngram(IDs[N-1],countID) ;
      (*offset)++ ;
      return ngram.write(fp) ;
      }
   else
      return true ;
}

//----------------------------------------------------------------------

static void compute_discounts(const LmCountOfCounts *counts,
			      LmNgramDiscounts *discounts)
{
   double n1 = counts->frequency(1) ;
   double Y = n1 / (n1 + 2.0 * counts->frequency(2)) ;
   for (size_t i = 1 ; i <= LmCOUNTOFCOUNTS_MAX ; i++)
      {
      size_t j = (i <= NUM_DISCOUNT_LEVELS) ? i : NUM_DISCOUNT_LEVELS ;
      double disc = j - ((j+1) * Y * counts->frequency(j+1) /
			 counts->frequency(j)) ;
      discounts->discount(i,disc) ;
      }
   return ;
}

//----------------------------------------------------------------------

static bool write_discounts(size_t rank, size_t precomp_rank,
			      FILE *fp, FILE *tmpfp,
			      size_t num_discounts,
			      LmRecordPointerRecord *records)
{
   uint32_t num_disc = 0 ;
   off_t disc_offset = ftell(fp) ;
   if (rank-1 <= precomp_rank)
      {
      fflush(tmpfp) ;
      fseek(tmpfp,0,SEEK_SET) ;	// rewind the temporary file
      // copy the smoothing values into the language model
      while (!feof(tmpfp))
	 {
	 uint32_t smoothing ;
	 if (fread(&smoothing,sizeof(smoothing),1,tmpfp) < 1)
	    break ;
	 if (Fr_fwrite(&smoothing,sizeof(smoothing),fp))
	    num_disc++ ;
	 }	
      }
   fseek(tmpfp,0,SEEK_SET) ;	// rewind the temporary file again
   ftruncate(fileno(tmpfp),0) ;	// don't need temp data anymore
   if (num_disc == num_discounts)	// disc conversion successful?
      records[rank-1].setDiscounts(disc_offset) ;
   else if (rank-1 <= precomp_rank)
      {
      fseek(fp,disc_offset,SEEK_SET) ;	// remove the discount values
      ftruncate(fileno(fp),disc_offset) ;
      cout << "!! error: mismatch in smoothing values (expected "
	   << num_discounts << ", got " << num_disc << ")" << endl ;
      }
   return true ;
}

//----------------------------------------------------------------------

static void finalize_headers(FILE *fp, size_t ngram_rank,
			     LmNgramFileHeader &header,
			     LmRecordPointerRecord *records,
			     LmCountMap *countmap,
			     LmNgramDiscounts *global_discounts,
			     LmCountOfCounts *counts,
			     bool free_data = true)
{
   off_t pos = ftell(fp) ;
   fseek(fp,0,SEEK_SET) ;
   header.write(fp) ;
   fflush(fp) ;
   for (size_t i = 1 ; i <= ngram_rank ; i++)
      records[i].write(fp) ;
   fflush(fp) ;
   if (free_data)
      delete [] records ;
   fseek(fp,header.countIDoffset(),SEEK_SET) ;
   countmap->write(fp) ;
   fflush(fp) ;
   if (free_data)
      delete countmap ;
   fseek(fp,header.globalDiscounts(),SEEK_SET) ;
   for (size_t i = 1 ; i <= ngram_rank ; i++)
      global_discounts[i].write(fp) ;
   fflush(fp) ;
   if (free_data)
      delete [] global_discounts ;
   fseek(fp,header.countOfCounts(),SEEK_SET) ;
   for (size_t i = 1 ; i <= ngram_rank ; i++)
      counts[i].write(fp) ;
   fflush(fp) ;
   if (free_data)
      delete [] counts ;
   fseek(fp,pos,SEEK_SET) ;
   return ;
}

//----------------------------------------------------------------------

bool LmNGramsFile::convert(const char *filename, const char * const *files,
			     size_t ngram_rank, size_t precomp_rank,
			     size_t scaling_factor, bool char_based,
			     bool include_spaces)
{
   FILE *fp = fopen(filename,FrFOPEN_WRITE_MODE) ;
   char *tmpname = FrTempFile("tmpbwt") ;
   FILE *tmpfp = tmpname ? fopen(tmpname,FrFOPEN_UPDATE_MODE) : 0 ;
   bool success = false ;
   if (fp && tmpfp && ngram_rank > 0)
      {
      //----------------
      // step 1: write dummy headers
      //----------------
      LmNgramFileHeader header(ngram_rank) ;
      header.setCaseSensitive(!ignore_case) ;
      header.setCharBased(char_based);
      header.setIncludeSpaces(include_spaces);
      fseek(fp,0,SEEK_SET) ;
      header.write(fp) ;
      LmRecordPointerRecord *records = new LmRecordPointerRecord[ngram_rank+1];
      for (size_t i = 1 ; i <= ngram_rank ; i++)
	 records[i].write(fp) ;
      LmCountOfCounts *counts = new LmCountOfCounts[ngram_rank+1] ;
      fflush(fp) ;
      header.setCountOfCounts(ftell(fp)) ;
      for (size_t i = 1 ; i <= ngram_rank ; i++)
	 counts[i].write(fp) ;
      fflush(fp) ;
      header.setGlobalDiscounts(ftell(fp)) ;
      LmNgramDiscounts *global_discounts = new LmNgramDiscounts[ngram_rank+1] ;
      for (size_t i = 1 ; i <= ngram_rank ; i++)
	 global_discounts[i].write(fp) ;
      fflush(fp) ;
      size_t numcounts = 1<<LmCOUNTID_BITS ;
      LmCountMap *countmap = new LmCountMap(numcounts) ;
      header.setCountIDmax(numcounts) ;
      header.setCountIDoffset(ftell(fp)) ;
      countmap->write(fp) ;
      //----------------
      // step 2: gather the vocabulary from the unigram file(s)
      //----------------
      records[1].setRecords(ftell(fp)) ;
      FrVocabulary *vocab = new FrVocabulary ;
      cout << " gathering vocabulary" << endl ;
      process_files(files[0],add_to_vocab,vocab) ;
      LmWordID_t last_id = vocab->numWords() ;
      cout << "   collected " << last_id << " words" << endl ;
      if (last_id > 0)
	 last_id-- ;
      //----------------
      // step 3: convert the ngram counts
      //----------------
      FrLocalAllocC(LmUnigramRecord,uni,150000,last_id+1) ;
      for (size_t i = 0 ; i < vocab->numWords() ; i++)
	 {
	 const char *ent = vocab->indexEntry(i) ;
	 if (ent)
	    {
	    size_t id = vocab->getID(ent) ;
	    uni[id].incrClassSize() ;
	    }
	 }
      cout << " processing N-grams" << endl ;
      process_files(files[0],convert_unigrams,vocab,uni,last_id,&counts[1],
		    scaling_factor) ;
      for (size_t i = 0 ; i <= last_id ; i++)
	 {
	 if (!uni[i].write(fp))
	    {
	    FrFree(uni) ;
	    return false ;
	    }
	 }
      FrLocalFree(uni) ;
      compute_discounts(&counts[1],&global_discounts[1]) ;
      size_t num_pointers = last_id + 2 ;
      records[1].setCount(last_id+1) ;
      uint32_t *next_pointers = FrNewC(uint32_t,num_pointers) ;
      success = true ;
      FrLocalAlloc(uint32_t,history,128,ngram_rank+1) ;
      if (!history)
	 {
	 FrNoMemory("while allocating history array") ;
	 return false ;
	 }
      for (size_t i = 2 ; i <= ngram_rank ; i++)
	 {
	 // write out an interim copy of the headers, so that we may
	 //   correctly load the partial model
	 finalize_headers(fp,ngram_rank,header,records,countmap,
			  global_discounts,counts,false) ;
	 LmNGramsFile *ngmodel = new LmNGramsFile(filename,i-1,true,false) ;
	 history[0] = LmVOCAB_WORD_NOT_FOUND ;
	 uint32_t offset = 0 ;
	 uint32_t hist_count = 0 ;
	 size_t total_count = 0 ;
	 uint32_t num_discounts = num_pointers - 1 ;
	 records[i].setRecords(ftell(fp)) ;
	 // iterate through the ngrams of the current rank and store the counts
	 FrStoreLong(0,next_pointers) ;
	 process_files(files[i-1],convert_counts,vocab,i,fp,
		       i-1<=precomp_rank?tmpfp:0,history,&offset,&hist_count,
		       &total_count,next_pointers,&counts[i],&counts[i-1],
		       &global_discounts[i-1],countmap,scaling_factor,
		       ngmodel) ;
	 update_lower_rank(tmpfp,&offset,&hist_count,total_count,
			   next_pointers,&global_discounts[i-1],&counts[i],
			   ngmodel,0,i-1) ;
	 fflush(fp) ;
	 cout << "## processed " << offset << " distinct " << i <<"-grams"
	      << endl ;
	 records[i].setCount(offset) ;
	 records[i-1].setPointers(ftell(fp)) ;
	 delete ngmodel ;
	 // write out the "next" pointers for the prior rank
	 if (!Fr_fwrite(next_pointers,sizeof(next_pointers[0]),num_pointers,fp))
	    {
	    success = false ;
	    break ;
	    }
	 FrFree(next_pointers) ;
	 if (i < ngram_rank)
	    {
	    // allocate space for the "next" pointers, which will be filled
	    //   on the next iteration
	    num_pointers = offset + 1 ;
	    next_pointers = FrNewC(uint32_t,num_pointers) ;
	    }
	 // compute smoothing discounts for the prior rank
	 compute_discounts(&counts[i],&global_discounts[i]) ;
	 write_discounts(i,precomp_rank,fp,tmpfp,num_discounts,records) ;
	 }
      FrLocalFree(history) ;
      //----------------
      // step 4: copy over the vocabulary into the language model file
      //----------------
      fflush(fp) ;
      save_vocabularies(header,fp,vocab,0,0) ;
      delete vocab ;
      //----------------
      // step 5: finalize the headers and other global data, then clean up
      //----------------
      finalize_headers(fp,ngram_rank,header,records,countmap,
		       global_discounts,counts) ;
      }
   if (!fp)
      FrWarningVA("unable to open '%s' for writing",filename) ;
   else
      fclose(fp) ;
   if (!tmpfp)
      FrWarningVA("unable to open temporary file '%s'",tmpname) ;
   else
      {
      fclose(tmpfp) ;
      Fr_unlink(tmpname) ;
      }
   FrFree(tmpname) ;
   return success ;
}

//----------------------------------------------------------------------

bool LmNGramsFile::convert(const char *filename, const FrBWTIndex *index,
			     FrVocabulary *vocab, size_t ngram_rank,
			     size_t precomp_rank, bool char_based,
			     bool include_spaces,
			     FrVocabulary *surfvocab,
			     FrVocabulary *stopwords)
{
   FILE *fp = fopen(filename,FrFOPEN_WRITE_MODE) ;
   char *tmpname = FrTempFile("tmpbwt") ;
   FILE *tmpfp = tmpname ? fopen(tmpname,FrFOPEN_UPDATE_MODE) : 0 ;
   bool success = false ;
   if (fp && tmpfp)
      {
      if (index->wordsAreReversed())
	 cout << "Warning: input model was trained with reversed word order,\n"
	      << "  output model will not properly predict probabilities"
	      << endl ;
      //----------------
      // step 1: write dummy headers
      //----------------
      LmNgramFileHeader header(ngram_rank) ;
      header.setTrainingSize(index->numItems()) ;
      header.setCaseSensitive(index->wordsAreCaseSensitive()) ;
      header.setCharBased(char_based);
      header.setAffixSizes(index->getAffixSizes()) ;
      header.setIncludeSpaces(include_spaces);
      fseek(fp,0,SEEK_SET) ;
      header.write(fp) ;
      LmRecordPointerRecord *records = new LmRecordPointerRecord[ngram_rank+1];
      for (size_t i = 1 ; i <= ngram_rank ; i++)
	 records[i].write(fp) ;
      LmCountOfCounts *counts = new LmCountOfCounts[ngram_rank+1] ;
      fflush(fp) ;
      header.setCountOfCounts(ftell(fp)) ;
      for (size_t i = 1 ; i <= ngram_rank ; i++)
	 counts[i].write(fp) ;
      fflush(fp) ;
      header.setGlobalDiscounts(ftell(fp)) ;
      LmNgramDiscounts *global_discounts = new LmNgramDiscounts[ngram_rank+1] ;
      for (size_t i = 1 ; i <= ngram_rank ; i++)
	 global_discounts[i].write(fp) ;
      fflush(fp) ;
      size_t numcounts = 1<<LmCOUNTID_BITS ;
      LmCountMap *countmap = new LmCountMap(numcounts) ;
      header.setCountIDmax(numcounts) ;
      header.setCountIDoffset(ftell(fp)) ;
      countmap->write(fp) ;
      //----------------
      // step 2: conversion
      //----------------
      records[1].setRecords(ftell(fp)) ;
#if 0
      LmWordID_t last_id = 0 ;
      for (size_t i = 0 ; i < vocab->numWords() ; i++)
	 {
	 const char *ent = vocab->indexEntry(i) ;
	 if (ent)
	    {
	    size_t id = vocab->getID(ent) ;
	    // is this ID higher than any we've seen so far and actually
	    //   present in the model?
	    if (id > last_id && index->unigram(id).nonEmpty())
	       last_id = id ;
	    }
	 }
#else
      LmWordID_t last_id = index->numIDs() ;
      if (last_id > 0)
	 last_id-- ;
#endif
      FrLocalAllocC(LmUnigramRecord,uni,150000,(last_id+1)) ;
      for (size_t i = 0 ; i < vocab->numWords() ; i++)
	 {
	 const char *ent = vocab->indexEntry(i) ;
	 if (ent)
	    {
	    size_t id = vocab->getID(ent) ;
	    if (id <= last_id)
	       uni[id].incrClassSize() ;
	    }
	 }
      index->enumerateNGrams(1,0,true,convert_unigrams,uni,last_id,
			     &counts[1]) ;
      for (size_t i = 0 ; i <= last_id ; i++)
	 {
	 if (!uni[i].write(fp))
	    {
	    FrFree(uni) ;
	    return false ;
	    }
	 }
      FrLocalFree(uni) ;
      compute_discounts(&counts[1],&global_discounts[1]) ;
      size_t num_pointers = last_id + 2 ;
      records[1].setCount(last_id+1) ;
      uint32_t *next_pointers = FrNewC(uint32_t,num_pointers) ;
      success = true ;
      FrLocalAlloc(uint32_t,history,128,ngram_rank+1) ;
      if (!history)
	 {
	 FrNoMemory("while allocating history array") ;
	 return false ;
	 }
      for (size_t i = 2 ; i <= ngram_rank ; i++)
	 {
	 uint32_t hist_count = 0 ;
	 size_t total_count = 0 ;
	 uint32_t offset = 0 ;
	 uint32_t num_discounts = num_pointers - 1 ;
	 records[i].setRecords(ftell(fp)) ;
	 //----------------
	 // step 2a: enumerate the ngrams of current rank and store the counts
	 //----------------
	 FrStoreLong(0,next_pointers) ;
	 index->enumerateNGrams(i,0,true,convert_ngrams,fp,
				(i-1<=precomp_rank)?tmpfp:0,
				history,&offset,&hist_count,&total_count,
				next_pointers,&counts[i],&counts[i-1],
				&global_discounts[i-1],countmap) ;
	 while (hist_count < num_discounts)
	    {
	    update_lower_rank(tmpfp,&offset,&hist_count,total_count,
			      next_pointers,&global_discounts[i-1],
			      &counts[i]) ;
	    }
	 cout << "## processed " << offset << " distinct " << i <<"-grams" 
	      << endl ;
	 fflush(fp) ;
	 records[i].setCount(offset) ;
	 records[i-1].setPointers(ftell(fp)) ;
	 //----------------
	 // step 2b: write out the "next" pointers for the prior rank
	 //----------------
	 if (!Fr_fwrite(next_pointers,sizeof(next_pointers[0]),num_pointers,fp))
	    {
	    success = false ;
	    break ;
	    }
	 fflush(fp) ;
	 FrFree(next_pointers) ;
	 if (i < ngram_rank)
	    {
	    // allocate space for the "next" pointers, which will be filled
	    //   on the next iteration
	    num_pointers = offset + 1 ;
	    next_pointers = FrNewC(uint32_t,num_pointers) ;
	    }
	 //----------------
	 // step 2c: compute smoothing discounts for prior rank
	 //----------------
	 compute_discounts(&counts[i],&global_discounts[i]) ;
	 write_discounts(i,precomp_rank,fp,tmpfp,num_discounts,records) ;
	 }
      FrLocalFree(history) ;
      //----------------
      // step 3: copy over the vocabulary into the language model file
      //----------------
      save_vocabularies(header,fp,vocab,surfvocab,stopwords) ;
      //----------------
      // step 4: finalize the headers and other global data, then clean up
      //----------------
      finalize_headers(fp,ngram_rank,header,records,countmap,
		       global_discounts,counts) ;
      }
   if (!fp)
      FrWarningVA("unable to open '%s' for writing",filename) ;
   else
      fclose(fp) ;
   if (!tmpfp)
      FrWarningVA("unable to open temporary file '%s'",tmpname) ;
   else
      {
      fclose(tmpfp) ;
      Fr_unlink(tmpname) ;
      }
   FrFree(tmpname) ;
   return success ; 
}

// end of file lmxgram2.cpp //
