/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmpchart.h		class ParseChart and associated funcs	*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMPCHART_H_INCLUDED
#define __LMPCHART_H_INCLUDED

#include "FramepaC.h"

#ifndef __LMBASE_H_INCLUDED
#include "lmbase.h"
#endif

#ifndef __LMNGRAM_H_INCLUDED
//#include "lmngram.h"
#endif

#ifndef __LMARCS_H_INCLUDED
#include "lmarcs.h"
#endif

/************************************************************************/
/************************************************************************/

class ChartArc ;
class TargetWord ;

//----------------------------------------------------------------------

class ParseChart : public LMBaseObject
   {
   private:  // data
      LmNGramModel **m_models ;
      FrTextSpans *m_lattice ;
      FrSymbolTable *wordtable, *origtable ;
      ChartArc **m_arcs ;		// linked lists of arcs for each positn
      ChartArc *m_initarc ;		// a dummy arc used to start the search
      ChartArc **m_pending_arcs ;	// arcs to be added after current pass
      ChartArc *m_obsolete_arcs ;	// arcs which have been removed
      const ChartArc ***m_covering_arcs; // array of arrays for arcs cover src
      const ChartArc **m_covering_ptrs ;
      double **m_future_score_matrix;
      unsigned int *m_covering_counts ;
      size_t *word_boundaries ;
      size_t *word_indices ;
      FrStruct *metadata ;
      TargetWord *endsent_word ;
      TargetWord *quesmark_word ;
      size_t m_numarcs ;
      size_t input_length ;
      size_t num_boundaries ;
      size_t max_overlap ;
      size_t max_reorder_gap ;
   private:  // methods
      void init(LmNGramModel **models) ;
      void finishBuilding(FrTimer &timer) ;
      void weightMergedArcs() ;
      void clearSuccessorArcs() ;
      bool setSuccessorArcs(size_t iteration) ;
      bool createMergedArc(const ChartArc *arc, const ChartArc *succ_arc,
			   size_t srcoverlap, size_t trgoverlap,
			   bool fills_gap) ;
      void removeObsoletedArcs() ;
      void insertCompositeArcs() ;
      void pruneArcs() ;
      int longestArc(size_t where) const ;
      bool inboundArcs(size_t where) const ;
      bool addDummyArc(size_t where, int len, const char *translation) ;
      bool addDummyArcs(size_t where, int len) ;
      void addDummyArcs() ;
      void optimizeArcs() ;
      void setWordBoundaries() ;
      void addAlignments() ;
      void removeOverriddenEngines() ;
      double optimizeArc(int arcnum, int totalcover, int coverage,
			 class TargetWord *translation,int translen,
			 double &score) const ;
      bool initCoveringArcs() ;
      void freeCoveringArcs() ;
      bool initFutureScoreMatrix() ;
      void freeFutureScoreMatrix() ;
      ChartArc *arcs(size_t which) const { return m_arcs[which] ; }
   public:  // methods
      ParseChart(FrTextSpans *chart, LmNGramModel **models) ;
      ~ParseChart() ;
      size_t chartLength() const { return input_length ; }
      void setArcs(int which, ChartArc *arclst) { m_arcs[which] = arclst ; }
      void addedArc() { m_numarcs++ ; }
      void removedArc() { if (m_numarcs > 0) m_numarcs-- ; }
      ChartArc *getArc(size_t which) const
	 { return which < input_length ? m_arcs[which] : 0 ; }
      ChartArc *getArcByWord(size_t which) const
	 { return which<=num_boundaries ? getArc(word_boundaries[which]) : 0; }
      FrList *bestSentences(size_t n, bool logspace) ;
      ostream &dump(ostream &output) const ;
      ostream &dump() const ;

      // accessors
      LmNGramModel **models() const { return m_models ; }
      TargetWord *endSentence() const { return endsent_word ; }
      TargetWord *questionMark() const { return quesmark_word ; }
      const size_t *wordBoundaries() const { return word_boundaries ; }
      const FrTextSpans *sourceLattice() const { return m_lattice ; }
      size_t numWordBoundaries() const { return num_boundaries ; }
      size_t wordBoundary(size_t N) const
	 { return (word_boundaries && N <= numWordBoundaries())
	           ? word_boundaries[N] : 0 ; }
      size_t numArcs() const { return m_numarcs ; }
      ChartArc *initialArc() const { return m_initarc ; }
      size_t wordIndex(size_t N) const
	 { return N <= chartLength() ? word_indices[N] : 0 ; }
      size_t boundaryCount(size_t start, size_t end) const ;
      size_t maxOverlap() const { return max_overlap ; }
      size_t maxReorderGap() const { return max_reorder_gap ; }
      const FrObject *getMetaData(FrSymbol *datatype) const ;
      const FrObject *getMetaData(const char *datatype) const ;
      FrSymbolTable *symtab() const { return wordtable ; }
      double chunkingBonus(size_t arc_start, size_t arc_end) const ;
      double bestUtility(size_t srcword, const LmConflicts *) const ;
      double bestUtility(size_t start, size_t length) const ;

      char *sourceText(size_t start, size_t end) const ;
      char *sourceText(const ChartArc *) const ;
   //friends
      friend ostream &operator << (ostream &output, ParseChart *pc)
	    { return pc->dump(output) ; }
      friend ostream &operator << (ostream &output, const ParseChart *pc)
	    { return pc->dump(output) ; }
   } ;

/************************************************************************/
/************************************************************************/

void set_arcignore(const char *ignoretype) ;
FrList *LmCollectChartWalk(const TargetWordList *wordlist,
			   const ParseChart *pchart,
			   LmNGramModel **models, bool minimal) ;
void output_augmented_chart(ostream &out, const ParseChart *pchart,
			    FrTextSpans *lattice, LmNGramModel **models,
			    const FrList *best, bool minimal);

#endif /* !__LMPCHART_H_INCLUDED */

// end of lmpchart.h //
