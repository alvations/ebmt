/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmsrilm.cpp	SRILM n-gram language model			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2008,2009 Ralf Brown and Jae Dong Kim			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#define XtSpecificationRelease		// avoid clashing typedef in SRILM
#define __FRMOTIF_H_INCLUDED		//  by not loading anything that
#define __FRHELP_H_INCLUDED		//  uses X-Windows or Motif

#include "lmngram.h"

#ifdef LmUSE_SRILM
#include "Ngram.h"
#endif

/************************************************************************/
/*    Manifest Constants for this module				*/
/************************************************************************/

/************************************************************************/
/*	Helper functions						*/
/************************************************************************/

/************************************************************************/
/*	Methods for class LmNGramModel					*/
/************************************************************************/

void LmNGramModelSRILM::initSRI(const char *filename)
{
#ifdef LmUSE_SRILM
   m_max_ngram = 3;
   m_srivcb = new Vocab();
   m_srilm = new Ngram( *m_srivcb, 3 );
   m_srilm->skipOOVs() = false;

   File file( filename, "r" );
   m_srilm->read( file );
#else
   cerr << "SRILM format support was not compiled in to this executable."
	<< endl ;
#endif /* LmUSE_SRILM */
   return ;
}

//----------------------------------------------------------------------

LmWordID_t LmNGramModel::findWordID_SRI(const char *word) const
{
#ifdef LmUSE_SRILM
   return sriVocab()->getIndex(word) ;
#else
   return LmVOCAB_WORD_NOT_FOUND ;
#endif /* LmUSE_SRILM */
}

/************************************************************************/
/*	Methods for class LmNGramModelSRILM				*/
/************************************************************************/

LmNGramModelSRILM::LmNGramModelSRILM(const char *filename,
				     const char *sourcemodelfile,
				     size_t max_ngram, double weight,
				     double context_weight,
				     double discount,
				     FrSymbol *smooth_name,
				     const char *ident)
{
   init(filename,sourcemodelfile,weight,context_weight,discount,
	smooth_name,ident) ;
   initSRI(filename) ;
   setSentMarkers() ;
   setSentMarkersSRI() ;
   return ;
}

//----------------------------------------------------------------------

LmNGramModelSRILM::~LmNGramModelSRILM()
{
#ifdef LmUSE_SRILM
   delete m_srilm ;	m_srilm = 0 ;
   delete m_srivcb ;	m_srivcb = 0 ;
#endif /* LmUSE_SRILM */
   return ;
}

//----------------------------------------------------------------------

bool LmNGramModelSRILM::isCaseSensitive() const
{
   return false ;
}

//----------------------------------------------------------------------

bool LmNGramModelSRILM::isCharBased() const
{
   return false ;			// SRI models are always word-based
}

//----------------------------------------------------------------------

bool LmNGramModelSRILM::includesSpaces() const
{
   return false ;
}

//----------------------------------------------------------------------

double LmNGramModelSRILM::perplexity(size_t rank) const
{
   cerr << "perplexity computation not supported for SRI models yet"
	<< endl ;
   return -1 ;
}

//----------------------------------------------------------------------

size_t LmNGramModelSRILM::frequency(const LmWordID_t *IDs,
				    size_t numwords) const
{
#ifdef LmUSE_SRILM
   if (numwords > m_max_ngram)
      {
      // ignore any "excess" history
      IDs += (numwords - m_max_ngram) ;
      numwords = m_max_ngram ;
      }
   VocabIndex context[3];
   size_t i = 0 ;
   for (i = 0 ; i < lengthof(context) && i < numwords-1 ; i++)
      {
      context[i] = IDs[i];
      }
   for ( ; i < lengthof(context) ; i++)
      {
      context[i] = Vocab_None;
      }
   size_t ID = ((IDs[numwords-1]==LmVOCAB_WORD_NOT_FOUND)
		? Vocab_None : IDs[numwords-1]) ;
   double val = sriModel()->wordProb( ID, context );
   return ::exp(val) * sriModel()->numNgrams(3);
#else
   return 0 ;
#endif /* LmUSE_SRILM */
}

//----------------------------------------------------------------------

size_t LmNGramModelSRILM::longestMatch(const LmWordID_t *IDs,
				       size_t numwords) const
{
   if (!IDs || numwords == 0)
      return 0 ;
   return 0 ; //FIXME
}

//----------------------------------------------------------------------

double LmNGramModelSRILM::rawProbability(size_t numwords,
					 const LmWordID_t *IDs,
					 size_t * /*max_exist*/) const
{
#ifdef LmUSE_SRILM
   VocabIndex context[3];
   size_t i = 0 ;
   for (i=0; i<3; i++)
      {
      context[i] = Vocab_None;
      }
   for (i=0 ; i<2 && i<numwords-1 && IDs[i] != 0; i++)
      {
      context[i] = IDs[i];
      }
   size_t ID = (IDs[numwords-1]==(LmWordID_t)~0) ? 0 : IDs[numwords-1] ;
   double val = sriModel()->wordProb( ID, context );
   return ::exp(val);
#else
   return 0.0 ;
#endif /* LmUSE_SRILM */
}

//----------------------------------------------------------------------

double LmNGramModelSRILM::rawProbability(size_t numwords, FrNGramHistory *hist,
					 LmWordID_t ID,
					 size_t * /*max_exist*/) const
{
#ifdef LmUSE_SRILM
   VocabIndex context[3];
   size_t i=0;
   for (i=0; i<3; i++)
      context[i] = Vocab_None;
   for (i = 0; i<2 && i<numwords && hist[i].wordID() != 0; i++)
      {
      context[i] = hist[i].wordID();
      }
   double val = sriModel()->wordProb( ID, context );
   return ::exp(val);
#else
   return 0.0 ;
#endif /* LmUSE_SRILM */
}

//----------------------------------------------------------------------

uint64_t LmNGramModelSRILM::trainingSize() const
{
#ifdef LmUSE_SRILM
   return sriModel()->numNgrams(3); //FIXME: is this the right function?
#else
   return 0 ;
#endif /* LmUSE_SRILM */
}

//----------------------------------------------------------------------

bool LmNGramModelSRILM::dump(FILE *outfp, const char *modelname,
			     bool run_verbosely) const
{
   return false ;
}

//----------------------------------------------------------------------

void LmNGramModelSRILM::setSentMarkersSRI()
{
#ifdef LmUSE_SRILM
   m_begsent_id = sriVocab()->getIndex(Vocab_SentStart);
   m_unknown_id = sriVocab()->getIndex(Vocab_Unknown);
#endif /* LmUSE_SRILM */
   return ;
}

// end of file lmsrilm.cpp //
