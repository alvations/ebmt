/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmbfs.h	best-first search				*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMBFS_H_INCLUDED
#define __LMBFS_H_INCLUDED

#include "FramepaC.h"
#include "lmbitset.h"
#include "lmngram.h"
#include "lmsetup.h"
#include "lmodel.h"

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

#define WORD_ALLOC_BINS 	16
#define WORD_ALLOC_STEP		4

#define MAX_USER_SCORES	 	9

/************************************************************************/
/************************************************************************/

class ChartArc ;
class ComponentArcInfo ;
class ParseChart ;
class PriorityQueue ;
class TargetWord ;
class TargetWordRef ;
class LmNGramModel ;

/************************************************************************/
/************************************************************************/

class BFSScoreInfo
   {
   private:
      static FrAllocator allocator ;
      double m_userscores[MAX_USER_SCORES] ;
      double m_arcscore ;		// total of arc scores
      double m_arcquality ;		// total of arc qualities
      double m_arcweight ;		// total of arc weights
      double m_untranspenalty ;	        // total of untranslated-word penalties
      double m_lenbonus ;		// total length bonus
      double m_chunkbonus ;		// total of chunking bonuses
      double m_doccontext ;		// total of doc-level context scores
      double m_sntcontext ;		// total of sent-level context scores
      double m_phrcontext ;		// total of phrase-level context scores

   public:
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      BFSScoreInfo(const BFSScoreInfo *orig = 0) ;
      ~BFSScoreInfo() {}

      // accessors
      double userScore(size_t N) const
	 { return (N < MAX_USER_SCORES) ? m_userscores[N] : 0.0 ; }
      double arcScores() const { return m_arcscore ; }
      double arcQualities() const { return m_arcquality ; }
      double arcWeights() const { return m_arcweight ; }
      double untransPenalty() const { return m_untranspenalty ; }
      double chunkingBonus() const { return m_chunkbonus ; }
      double docContext() const { return m_doccontext ; }
      double sentContext() const { return m_sntcontext ; }
      double phraseContext() const { return m_phrcontext ; }
      double lenBonus() const { return m_lenbonus ; }

      // modifiers
      void userScore(size_t N, double val) 
	 { if (N < MAX_USER_SCORES) m_userscores[N] = val ; }
      void incrUserScore(size_t N, double val) 
	 { if (N < MAX_USER_SCORES) m_userscores[N] += val ; }
      void arcScores(double sc) { m_arcscore = sc ; }
      void incrArcScores(double incr) { m_arcscore += incr ; }
      void arcQualities(double q) { m_arcquality = q ; }
      void incrArcQualities(double incr) { m_arcquality += incr ; }
      void arcWeights(double wt) { m_arcweight = wt ; }
      void incrArcWeights(double incr) { m_arcweight += incr ; }
      void untransPenalty(double pen) { m_untranspenalty = pen ; }
      void incrUntransPenalty(double incr) { m_untranspenalty += incr ; }
      void chunkingBonus(double bon) { m_chunkbonus = bon ; }
      void incrChunkingBonus(double incr) { m_chunkbonus += incr ; }
      void docContext(double d) { m_doccontext = d ; }
      void incrDocContext(double incr) { m_doccontext += incr ; }
      void sentContext(double d) { m_sntcontext = d ; }
      void incrSentContext(double incr) { m_sntcontext += incr ; }
      void phraseContext(double d) { m_phrcontext = d ; }
      void incrPhraseContext(double incr) { m_phrcontext += incr ; }
      void lenBonus(double bon) { m_lenbonus = bon ; }
      void incrLenBonus(double incr) { m_lenbonus += incr ; }
   } ;

/************************************************************************/
/************************************************************************/

class BestFirstSearch
   {
   private:
      static FrAllocator allocator ;
      PriorityQueue **m_queue ;
      long int m_totalnodes, nodes_expanded ;
      size_t m_substacks ;
      size_t m_jigsawstacks ;
      size_t m_numpruned ;
      size_t m_inputlength ;
      size_t m_activestack ;
   private: // methods
      FrList *finalize(BFSNode *node) ;
   public: // methods
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      BestFirstSearch(BFSNode *node, size_t nbest_list_size = 1) ;
      ~BestFirstSearch() ;
      bool addNode(BFSNode *node) ;
      void insertNodes(BFSNode *nodes) ;
      BFSNode *peek() ;
      BFSNode *pop() ;
      bool refillQueues(bool unlimit_beam = false,
			size_t num_remaining = 0) ;
      FrList *find() ;

      // accessors
      size_t inputLength() const { return m_inputlength ; }
      size_t activeStack() const { return m_activestack ; }
      size_t nextActiveStack() const ;
      size_t totalStacks() const ;
      size_t queueInputCover(size_t stacknum) const ;
      size_t activeQueueLength() ;
      BFSNode *extractActiveStack(size_t &queuelen) ;
      int maxNodes() const ;
      int currNodes() const ;
      size_t nodesPruned() const { return m_numpruned ; }
      long int totalNodes() const { return m_totalnodes ; }
      long int expandedNodes() const { return nodes_expanded ; }
      size_t queueNumber(const BFSNode *node) const ;
      PriorityQueue *queue(const BFSNode *node) const
	 { return m_queue[queueNumber(node)] ; }
      PriorityQueue *queue(size_t qnum) const
	 { return m_queue[qnum] ; }

      // threading statistics
      size_t totalUncontested() const ;
      size_t totalCollisions() const ;
      ostream &collisionStatistics(ostream &out) const ;
      ostream &cs() const ; // collisionStatistics(cerr)
   } ;

/************************************************************************/
/************************************************************************/

extern class BestFirstSearch *lm_active_search ;

class BFSNode
   {
   private:
      static FrAllocator allocator ;
      static FrAllocator *cover_allocator ;
      static FrAllocator **word_allocators ;
      BFSNode *right_node ;
      BFSNode *left_node ;
      BFSScoreInfo *m_scoreinfo ;
      ParseChart *chart ;
      TargetWordRef *words ;
      ComponentArcInfo *arcs ;		// which arcs have been combined?
      LmBitFlags *m_covered ;		// which words of input are covered?
      LmNGramStates m_modelstates ;
      double m_prob ;			// arc-weighted total ngram probability
      double m_featweight ;		// total of non-prob/non-overlap feats
      double m_ovrbonus ;		// total overlap bonus
      double m_ngramfrac ;		// total fraction of max ngrams matched
      double _score;			// actual score for determining best
      LmUSHORT m_twordalloc ;		// alloc size for 'words'
      LmUSHORT m_numwords ;		// number of words in target so far
      LmUSHORT m_coverage ;		// number of input words covered so far
      LmUSHORT numarcs ;		// number of arcs combined
      LmUSHORT m_activearc ;		// which arc is to be extended next?
      LmUSHORT m_bytecover ;		// number of input bytes covered so far
      LmUSHORT m_bytelength ;		// number of output bytes so far
      LmUSHORT OOV_count ;		// number of OOV words
      LmUSHORT m_nulltrans ;		// number of arcs w/ empty translations
      LmUSHORT num_gap_markers ;	// number of gap words to be replaced
      LmUSHORT num_gaps_filled ;	// number of gap words already replaced
      LmUSHORT num_gaps_discarded ;	// number of unfilled gaps we skipped
      LmUSHORT arc_reorderings ;
   private: // methods
      static void copyNodeInfo(BFSNode *dest, const BFSNode *oldnode) ;
      void initHistories(LmNGramModel **,size_t maxhist) ;
      bool allocCovered(const LmBitFlags *init = 0) ;// get space for 'covered'
      void freeCovered() ;
      void allocTargetWords() ;		// allocate storage for 'words'
      void freeTargetWords() ;
      bool removeGapMarkers(bool force = false) ; // false if embedded gaps
      void setDiscountedScore() ;
      double futureUtility() ;
      double futureUtilityMoses() ;
      void updateNodeInfo(size_t prevwords, const ChartArc *arc,
			  size_t chartlength, size_t reordering,
			  size_t src_overlap, size_t trg_overlap) ;
      void updateUserScores(const ChartArc *arc) ;
      BFSNode *makeExpandedNode(const ChartArc *arc, const ParseChart *chart,
				size_t reordering, size_t src_cover,
				size_t src_overlap, size_t trg_overlap,
				BFSNode *nodelist = 0) const ;
   public: // methods
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      BFSNode(ParseChart *parsechart) ;
      BFSNode(const BFSNode *oldnode) ;
      BFSNode(const BFSNode *oldnode,size_t cover,size_t wordcount,
	      const ChartArc *new_arc, const ParseChart *chart,
	      size_t overlap = 0) ;
      ~BFSNode() ;
      BFSNode *nconc(BFSNode *more) ;
      BFSNode *expand(bool must_fill_gap = false) ;
      void initScoreInfo(bool force = false) ;
      void usedArcs(const BFSNode *prev_node, const ChartArc *new_arc,
		    size_t overlap, size_t trgposition) ;

      int compareNode(const BFSNode *node) const ;
      bool sameCoverage(const BFSNode *node) const ;
      bool canCoverRemainder() const ;
      bool complete() const ;
      bool good() const { return coveredInput() != 0 && words != 0 ; }
      void *value() const ;
      void *optionalInfo() const ;
      FrList *scoreInfo() const ;

      size_t targetOverlap(const ChartArc *arc, size_t src_overlap = 0) const ;
      bool arcAlreadyUsed(const ChartArc *arc) const ;

      // manipulation functions
      void setLeft(BFSNode *leftnode) { left_node = leftnode ; }
      void setRight(BFSNode *rightnode) { right_node = rightnode ; }
      void setNext(BFSNode *nextnode) { right_node = nextnode ; }
      BFSNode *makeSortedList() ; // destroys the Treap rooted at 'this'!
      BFSNode *sortListByScore() ;
      void setActiveArc(size_t N) { m_activearc = (LmUSHORT)N ; }
      void updateActiveArc(size_t last_target) ;
      bool nextActiveArc() ; // -> true if a longer arc at same pos exists
      void adjustTargetPositions(size_t *map) ;

      void incrGapMarkers(size_t count = 1)
	 { num_gap_markers += (LmUSHORT)count ; }
      void decrGapMarkers(size_t count = 1)
	 { num_gap_markers -= (LmUSHORT)count ; }
      void gapFilled(size_t count = 1) { num_gaps_filled += (LmUSHORT)count ; }
      void gapDiscarded(size_t count = 1)
	 { num_gaps_discarded += (LmUSHORT)count ; }
      void setUserScore(size_t N, double val)
	 { if (m_scoreinfo) m_scoreinfo->userScore(N,val) ; }
      void incrUserScore(size_t N, double incr)
	 { if (m_scoreinfo) m_scoreinfo->incrUserScore(N,incr) ; }
      void adjustByteLength(size_t adj) { m_bytelength += adj ; }

      // access to internal state
      BFSNode *left() const { return left_node ; }
      BFSNode **leftPtr() { return &left_node ; }
      BFSNode *right() const { return right_node ; }
      BFSNode **rightPtr() { return &right_node ; }
      BFSNode *next() const { return right_node ; }
      const LmNGramStates *modelStates() const { return &m_modelstates ; }
      LmNGramStates *modelStates() { return &m_modelstates ; }
      double score() const { return _score ; }
      double overlapBonus() const { return m_ovrbonus ; }
      double lengthBonus() const
	 { return m_scoreinfo ? m_scoreinfo->lenBonus() : 0.0 ; }
      double arcScores() const
	 { return m_scoreinfo ? m_scoreinfo->arcScores() : 0.0 ; }
      double arcQualities() const
	 { return m_scoreinfo ? m_scoreinfo->arcQualities() : 0.0 ; }
      double chunkingBonus() const
	 { return m_scoreinfo ? m_scoreinfo->chunkingBonus() : 0.0 ; }
      double docContext() const
	 { return m_scoreinfo ? m_scoreinfo->docContext() : 0.0 ; }
      double sentContext() const
	 { return m_scoreinfo ? m_scoreinfo->sentContext() : 0.0 ; }
      double phraseContext() const
	 { return m_scoreinfo ? m_scoreinfo->phraseContext() : 0.0 ; }
      double untranslatedPenalty() const
	 { return m_scoreinfo ? m_scoreinfo->untransPenalty() : 0.0 ; }
      double probability() const { return m_prob ; }
      double extraFeatureScore() const { return m_featweight ; }
      double rawScore() const { return probability() + extraFeatureScore() ; }
      double userScore(size_t N) const
	 { return m_scoreinfo ? m_scoreinfo->userScore(N) : 0.0 ; }
      size_t inputLength() const ;
      size_t outputLength() const { return m_numwords ; }
      double ngramFraction() const { return m_ngramfrac ; }
      size_t inputCoverage() const { return m_coverage ; }
      size_t numArcs() const { return numarcs ; }
      size_t activeArc() const { return m_activearc ; }
      size_t byteCover() const { return m_bytecover ; }
      size_t byteLength() const { return m_bytelength ; }
      size_t gapsFilled() const { return num_gaps_filled ; }
      size_t gapsDiscarded() const { return num_gaps_discarded ; }
      size_t gapMarkers() const { return num_gap_markers ; }
      size_t gapInCoverage() const ; // do we need to fill anything we skipped?
      size_t futureReordering() const ;
      size_t numOOVs() const { return OOV_count ; }
      const ComponentArcInfo *usedArcs() const { return arcs ; }
      const ChartArc *lastArcUsed() const ;
      size_t lastArcPosition() const ;
      size_t lastArcEnd() const ;
      bool lastArcSubsumed() const ;
      bool isQuestion() const ;
      ParseChart *getParseChart() const { return chart ; }
      const TargetWordRef *wordList() const { return words ; }
      FrSymbol *outputWord(size_t N) const ;
      bool inputCovered(size_t N) const
	 { if (N < inputLength())
	    { const LmBitFlags *cov = coveredInput() ;
	      return (cov ? LmGetBit(cov,N) : true) ; }
	   else return false ; }
      const LmBitFlags *coveredInput() const
	 { if (inputLength() > CHAR_BIT * sizeof(LmBitFlags*))
	   return m_covered ; 
	   else return (LmBitFlags*)&m_covered ; }
      LmBitFlags *coveredInputMod()
	 { if (inputLength() > CHAR_BIT * sizeof(LmBitFlags*))
	   return m_covered ; 
	   else return (LmBitFlags*)&m_covered ; }
      size_t coverageEntries() const
	 { return (inputLength()+LM_BITS_PER_ENTRY-1) / LM_BITS_PER_ENTRY ; }
      size_t arcReorderings() const { return arc_reorderings ; }
      size_t numOverlaps() const { return numarcs ; }
      static int compare(const BFSNode &n1, const BFSNode &n2)
	 {
	 size_t q1 = lm_active_search->queueNumber(&n1) ;
	 size_t q2 = lm_active_search->queueNumber(&n2) ;
	 if (q1 < q2) return -1 ;
	 else if (q1 > q2) return +1 ;
	 double dif = n1.score() - n2.score() ;
	 return (dif>0.0 ? -1 : (dif<0.0 ? +1 : 0)) ; 
	 }

      // debugging support
      bool inTree(const BFSNode *node) const ;
      void dumpArcs(ostream &) const ;
      void dumpArcs() const ; // use cout
      void dumpActiveArc(ostream &) const ;
      void dumpActiveArc() const ; // use cout
      void showCoverage(ostream &) const ;
      void showCoverage() const ; // use cout
      void showUsedArcs(ostream &) const ;
      void showUsedArcs() const ; // use cout
      static size_t numNodesAlloc()
	 { return (allocator.objects_allocated()
		   - allocator.freelist_length()) ; }
      static size_t numNodeAllocs()
	 { return allocator.requests_made() ; }

      // memory management
      static bool newCoverAllocator(size_t input_length) ;
      static void deleteCoverAllocator() ;
      static bool newWordAllocators() ;
      static void deleteWordAllocators() ;
   } ;

/************************************************************************/
/************************************************************************/

#endif /* !__LMBFS_H_INCLUDED */

// end of lmbfs.h //
