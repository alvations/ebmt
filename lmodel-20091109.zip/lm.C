/************************************************************************/
/*                                                                      */
/*  Pangloss Language Model                                             */
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*                                                                      */
/*  File lm.cpp         Language Model main program                     */
/*  LastEdit: 04nov09							*/
/*                                                                      */
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,	*/
/*		2004,2005,2006,2007,2008,2009 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*                                                                      */
/************************************************************************/

#if defined(unix) || defined(__WINDOWS__)
#define USING_SOCKETS
#endif /* unix || __WINDOWS__ */

#include "lmodel.h"
#include "lmbuild.h"
#include "lmengine.h"
#include "lmpchart.h"
#include "lmprique.h"
#include "lmmain.h"
#include "lmglobal.h"

#ifdef FrSTRICT_CPLUSPLUS
# include <fstream>
#else
# include <fstream.h>
#endif /* FrSTRICT_CPLUSPLUS */

#include <errno.h>
#include <signal.h>
#include <fcntl.h>

#ifdef __SUNOS__
#  include <sys/unistd.h>
#elif defined(unix)
#  include <unistd.h>
#elif defined(__MSDOS__) || defined(__WATCOMC__) || defined(_MSC_VER)
#  include <io.h>
#  include <dos.h>
#endif /* __SUNOS__ || unix || __MSDOS__ || _MSC_VER */

/************************************************************************/
/*      Manifest Constants                                              */
/************************************************************************/

#define WINDOWS_TITLEBAR "Pangloss Language Modeler"

/************************************************************************/
/*      Global data                                                     */
/************************************************************************/

#if defined(__WINDOWS__) || defined(__NT__)
extern "C" char __WinTitleBar[] = WINDOWS_TITLEBAR ;
#endif /* __WINDOWS__ || __NT__ */

/************************************************************************/
/*      Global variables for this module                                */
/************************************************************************/

extern bool auto_insert_EOS ;
extern bool bilingual_data ;
extern bool bilingual_use_source ;
static bool gen_BWT = false ;
static bool compress_BWT = false ;
static bool reverse_BWT_words = true ;
static bool compute_perplexity = false ;
static double discountmass = 5e-3 ;  // half a percent
static bool gen_fastNgram = false ;
static bool compress_Ngram = false ; // want to compress existing BWT?
static bool cvt_counts_to_fastNgram = false ;
static size_t count_scaling_factor = 1 ;
static size_t fastNgram_rank = 4 ;
static size_t precompute_rank = 4 ;
static char *word_stems_filename = 0 ;
static char *stopwords_filename = 0 ;
static char *abbrevs_filename = 0 ;
char *vocab_filename = 0 ;

static int files_processed = 0 ;
static int sentences_processed = 0 ;

static bool initiate_connection = false ;
static char *host_name = 0 ;

bool generate_minimal_chart = false ;   // output ONLY best path to chart?
static char *chart_file ;               // name of file into which to generate
static ostream *chart_stream ;          // stream opened on chart file

static char *output_file ;
static ostream *xlat ;

static FramepaC_error_handler oom_handler ;

static FrTimer *runtimer ;

//----------------------------------------------------------------------
// signal handlers

static FrSignalHandler *sigint = 0 ;
static FrSignalHandler *sigill = 0 ;
static FrSignalHandler *sig_fpe = 0 ;
static FrSignalHandler *sigpipe = 0 ;
static FrSignalHandler *sighup = 0 ;
static FrSignalHandler *sigbus = 0 ;
static FrSignalHandler *sigsegv = 0 ;

/************************************************************************/
/*	Forward declarations						*/
/************************************************************************/

static void untrap_signals() ;

/************************************************************************/
/*      Helper functions                                                */
/************************************************************************/

static void usage(const char *progname, ostream &err)
{
   err << "Pangloss Language Modeler\n"
	   "Usage: " << progname << " [options] <3gram-model> [<chartfile>...]\n"
	   "  or   " << progname << " [build-opts] <destination> [<source> ...]\n"
	   "Options:\n"
	   "\t-AX\tignore arcs of type X (use -A- for help)\n"
	   "\t-bN\tfind N best translations (default " << best_count << ")\n"
	   "\t-cb\tlanguage model is character-based\n"
	   "\t-cs\tlanguage model is case-sensitive\n"
	   "\t-fX\tstore best translation for each sentence in file X\n"
	   "\t-gX\tgenerate new chart with best path into file X\n"
	   "\t-g=X\tgenerate best path info into file X ('-' for stdout)\n"
	   "\t-h\tshow this help\n"
	   "\t-k\tdon't keep accents on characters on output\n"
	   "\t-K\tshow per-engine coverage statistics and overlap statistics\n"
	   "\t-M\tignore source-language morphology\n"
	   "\t-oN\tspecify OOV penalty as N*(proportion of OOVs)\n"
	   "\t-O\tshow origin of translations used in final result\n"
	   "\t-pN\trun as network server on port N\n"
           "\t-p:H:N\tcontact network master on host H at port N\n"
	   "\t-P\tdon't prune search queue\n"
	   "\t-Pn\tset beam with in search to 'n'\n"
           "\t-q\ttoggle question-particle to question-mark conversion\n"
	   "\t-Q\trun quietly (no messages/info to standard output)\n"
           "\t-r\tshow raw scores (for use in MER training)\n"
	   "\t-sX\tuse setup file X instead of default setup\n"
	   "\t-Tlevel\tspecify verbosity of trace messages\n"
	   "\t-Uenc\tuse character encoding 'enc' for I/O\n"
	   "\t-Ub\tbyte-swap 16-bit Unicode characters on input\n"
	   "\t-v\tturn on verbose messages from language model\n"
	   "Build-Options:\n"
	   "\t-2[s]\t(with -B) input is sentence pairs; use source half if -2s\n"
	   "\t-2b\t(with -B) input is line-based; add <s> </s> to each line\n"
           "\t-B\tcreate BWT-style N-gram model from text file\n"
           "\t-Bc\tcreate compressed BWT-style N-gram model from text file\n"
           "\t-Br\tcreate BWT-style N-gram model from text file (don't reverse words)\n"
	   "\t-Cc\tcompress existing BWT-style N-gram model\n"
	   "\t-Cp\tcompute perplexity of existing language model\n"
	   "\t-C#\tconvert BWT model to fast #-gram model file with KN smoothing\n"
	   "\t-C#,S\tconvert to fast #-gram model, precompute smoothing up to rank S\n"
	   "\t-N\tconvert sequence of n-gram lists to fast ngram model\n"
	   "\t-N#\tconvert n-gram lists, precompute smoothing up to rank #\n"
	   "\t-N/#\tconvert n-gram lists, divide counts by #\n"
	   "\t-aFILE\tread list of abbreviations attaching period from FILE\n"
	   "\t-cb\tbuild character-based language model\n"
	   "\t-cr#\tmap words occurring no more than # times to class <rare>\n"
           "\t-cs\tbuild case-sensitive model (don't map everything to lowercase)\n"
	   "\t-iFILE\tread list of ignorable stopwords from FILE\n"
           "\t-RFILE\tread word roots/stems (equivalence classes) from FILE\n"
	   "\t-S\tread source filenames from stdin\n"
	   "\t-wFILE\tstore word frequencies into FILE\n"
	   "\t-%P,S\tlimit modeling to prefix of P chars and suffix of S chars\n"
           "\t-@\tinput is already canonicalized\n"
	   "Flag options are toggles, reversing the state set by the default\n"
	   "configuration file or a previous occurrence on the command line;\n"
	   "append a + or - to force a particular state."
	<< endl ;
   exit(127) ;
}

//----------------------------------------------------------------------

static void memory_exhausted(const char *message)
{
   cerr << "MEMORY EXHAUSTED " << message << endl ;
   cerr << "(after processing " << total_sentences << " sentences in "
	<< files_processed << " files, and " << endl
	<< sentences_processed << " sentences in the current file)" << endl ;
   exit(127) ;
}

/************************************************************************/
/************************************************************************/

static void output_raw_scores(ostream &out, const FrObject *data,
			      const FrObject *score)
{
   if (data && data->consp())
      {
      const FrList *score_info = (FrList*)data ;
      if (raw_scores_in_CMERT_format)
	 {
	 out << " |||" ;
	 for (const FrList *info = score_info ; info ; info = info->rest())
	    {
	    FrList *inf = (FrList*)info->first() ;
	    if (inf)
	       {
	       FrObject *val = inf->second() ;
	       if (val)
		  out << ' ' << setprecision(16) << val->floatValue() ;
	       }
	    }
	 out << " ||| " << setprecision(8) << score << endl;
	 }
      else
	 {
	 out << "{" ;
	 for (const FrList *info = score_info ; info ; info = info->rest())
	    {
	    FrList *inf = (FrList*)info->first() ;
	    if (inf)
	       {
	       FrObject *val = inf->second() ;
	       if (val)
		  out << ' ' << setprecision(16) << val->floatValue() ;
	       }
	    }
	 out << "}" << endl ;
	 }
      // every tenth time, output a reminder of what the scores represent
      static size_t count = 0 ;
      if (count++ % 10 == 0)
	 {
	 out << ";" ;
	 for ( ; score_info ; score_info = score_info->rest())
	    {
	    FrList *inf = (FrList*)score_info->first() ;
	    if (inf)
	       {
	       const char *name = FrPrintableName(inf->first()) ;
	       out << ' ' << name ;
	       }
	    }
	 out << endl ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static void output_best_sentences(ostream &out, const FrList *best)
{
   int num_translations = best->listlength() ;
   if (!run_LM_quietly)
      {
      if (num_translations == 0)
	 out << "No translations found!" << endl ;
      else if (num_translations == 1)
	 out << "The best translation is:" << endl ;
      else
	 out << "The " << best->listlength() << " best translations are:"
	     << endl ;
      }
   for (const FrList *sentences = best ;
	sentences ;
	sentences = sentences->rest())
      {
      FrList *translation = (FrList*)(sentences->first()) ;
      if (translation && translation->consp())
	 {
	 FrObject *tr = translation->second() ;
	 if (tr && tr->stringp())
	    {
	    FrString *tr_str = (FrString*)tr ;
	    char *str = postprocess_string((char*)tr_str->stringValue());
	    tr = new FrString(str,strlen(str),1,false) ;
	    }
	 else if (tr)
	    tr = tr->deepcopy() ;
	 if (!run_LM_quietly)
	    {
	    out << setprecision(8) << translation->first() << setprecision(0) 
		<< '\t' ;
	    }
	 if (!show_raw_scores)
	    out << tr << endl ;
	 else
	    {
	    if (raw_scores_in_CMERT_format)
	       {
	       const char *str = ((FrString*)tr)->stringValue() ;
	       out << "||| " <<  postprocess_string(str) ;
	       }
	    else
	       out << tr << endl ;
	    }
	 if (show_raw_scores)
	    output_raw_scores(out,(*translation)[3],translation->first()) ;
	 if (!run_LM_quietly && show_origins)
	    dump_arc_list(out,(TargetWordList*)translation->third()) ;
	 if (output_file && sentences == best)
	    {
	    if (tr && tr->stringp())
	       *xlat << ((FrString*)tr)->stringValue() << endl ;
	    else
	       *xlat << tr << endl ;
	    }
	 free_object(tr) ;
	 }
      else if (!show_raw_scores)
	 {
	 // make sure we output exactly N lines for an N-best list
	 if (!run_LM_quietly)
	    out << setprecision(8) << -9999.9 << setprecision(0) << '\t' ;
	 out << "\"\"" << endl ;
	 }
      }
   if (show_raw_scores)
      out << "{}" << endl ;
   if (run_LM_quietly)
      {
      for (size_t i = num_translations ; i < best_count ; i++)
	 out << endl ;
      }
   out << flush ;
   return ;
}

//----------------------------------------------------------------------

static bool show_engine_options(MTEngine *engine, va_list args)
{
   FrVarArg(ostream*,out) ;
   (*out) << "Engine " << engine->engineName() << " (tag "
	  << engine->engineTag() << ")" ;
   if (engine->beingIgnored())
      (*out) << " DISABLED" ;
   (*out) << "\n  weight " << engine->engineWeight()
	  << ",  untranslated penalty "
	  << engine->untranslatedPenalty() << endl ;
   int count ;
   const double *bonuses = engine->lengthBonuses(count) ;
   (*out) << "  length bonuses " ;
   for (int i = 1 ; i <= count ; i++)
      (*out) << bonuses[i] << ' ' ;
   (*out) << endl ;
   return true ;
}

//----------------------------------------------------------------------

static void output_options_list(ostream &out, bool list_all = false)
{
   if (list_all)
      {
      out << endl ;
      MTEngineList::iterateAll(show_engine_options,&out) ;
      if (generate_chart)
	 out << "Will generate chart with best path" << endl ;
      }
   out << " Log-Linear Feature Weights:" << endl ;
   out << "     ArcWeight = " << weightof_arcweight << endl ;
   out << "     InterleavePen = " << interleave_penalty << endl ;
   out << "     LangModel = " << LM_scale_factor << endl ;
   out << "     LengthBonus = " << weightof_lengthbonus << endl ;
   out << "     NGram-Length = " << ngram_length_bonus << endl ;
   out << "     OOV penalty = " << OOV_penalty << endl ;
   out << "     OverlapBonus = " << overlap_bonus << endl ;
   out << "     ReorderPen = " << reordering_penalty << endl ;
   out << "     Score = " << weightof_score << endl ;
   out << "     Untranslated = " << weightof_untrans << endl ;
   out << "     Verbosity = " << length_mismatch_penalty_base << endl ;
   out << "     User1 = " << weightof_user[0] << endl ;
   out << "     User2 = " << weightof_user[1] << endl ;
   out << "     User3 = " << weightof_user[2] << endl ;
   out << "     User4 = " << weightof_user[3] << endl ;
   out << "     User5 = " << weightof_user[4] << endl ;
   out << "     User6 = " << weightof_user[5] << endl ;
   out << "     User7 = " << weightof_user[6] << endl ;
   out << "     User8 = " << weightof_user[7] << endl ;
   out << "     User9 = " << weightof_user[8] << endl ;
   if (LM_scale_factor == 0.0 || ignore_source_morphology)
      {
      out << "Ignoring" ;
      if (LM_scale_factor == 0.0) out << " language model " ;
      if (ignore_source_morphology) out << " source morphology " ;
      }
   out << endl ;
   out << "Assuming " ;
   if (ignore_case)
      out << "case-insensitive language model." ;
   else
      out << "mixed-case language model." ;
   out << endl ;
}

//----------------------------------------------------------------------

static void process_sentence(const ParseChart *pc, FrTextSpans *lattice,
			     const FrList *best, LmNGramModel **ngrams,
			     ostream &out)
{
   const char *input = lattice->originalString() ;
   if (verbose || LM_trace > 0)
      {
      out << "Translation for \"" << input << "\"" << endl ;
      out << pc << flush << endl << endl ;
      }
   if (!ngrams || !ngrams[0])
      {
      out << "Unable to translate: no valid language model" << endl ;
      return ;
      }
   if (!run_LM_quietly)
      out << endl << "Translating \"" << input << "\"" << endl ;
   output_best_sentences(out,best) ;
   if (generate_chart)
      output_augmented_chart(*chart_stream,pc,lattice,ngrams,best,
			     generate_minimal_chart) ;
   return ;
}

//----------------------------------------------------------------------

static void process_sentence(FrTextSpans *lattice, LmNGramModel **ngrams,
			     ostream &out, ostream & /*err*/)
{
   ParseChart *pc ;
   FrList *best = process_sentence_LM(lattice,ngrams,&pc,false,best_count==1) ;
   process_sentence(pc,lattice,best,ngrams,out) ;
   if (best)
      best->freeObject() ;
   delete pc ;
   if (best_count > 1)
      FramepaC_gc() ;
   return ;
}

//----------------------------------------------------------------------

static void process_file(LmNGramModel **ngrams, istream &in, ostream &out,
			 ostream &err)
{
   FrTimer *timer = 0 ;
   if (verbose || LM_trace)
      timer = new FrTimer ;
   FrObject *item ;
   sentences_processed = 0 ;
   if (verbose)
      output_options_list(out,true) ;
   LmActiveNGrams(ngrams) ;
   do {
      // read in one object, which should be either a translation lattice
      //   or a symbol giving a command
      in >> item ;
      if (!item || item == makeSymbol("*EOF*"))
	 break ;
      if (is_LM_command(item))
	 {
	 if (process_LM_command(item,in,out,err))
	    out << "Ok" << endl ;
	 else
	    out << "Failed" << endl ;
	 continue ;
	 }
      else if (item && item->consp())
	 {
	 if (preparing_for_document)
	    {
	    LmAccumulateSourceCoverage(ngrams,(FrList*)item) ;
	    }
	 else
	    {
	    // use the new-style compressed chart
	    FrTextSpans *lattice = new FrTextSpans((FrList*)item) ;
	    process_sentence(lattice,ngrams,out,err) ;
	    delete lattice ;
	    sentences_processed++ ;
	    total_sentences++ ;
	    }
	 }
      else if (preparing_for_document && item && item->stringp())
	 {
	 FrString *str = (FrString*)item ;
	 FrList *words = FrCvtString2Wordlist(str->stringValue()) ;
	 LmAccumulateSourceCoverage(ngrams,words) ;
	 free_object(words) ;
	 }
      else
	 {
	 err << ";; input was neither a chart nor a command!" << endl ;
	 if (generate_minimal_chart)
	    (*chart_stream) << "()" << endl << flush ;
	 }
      free_object(item) ;
      if (verbose)
	 {
#ifdef FrMEMWRITE_CHECKS
	 if (!check_FrMalloc(&FramepaC_default_mempool) ||
	     !FramepaC_memory_chain_OK())
	    err << "memory chain corrupt! (found in process_file)" << endl;
#endif
	 if (LM_trace > 1)
	    {
	    FrMemoryStats(err) ;
	    err << endl ;
	    }
	 }
      } while (item != makeSymbol("*EOF*")) ;
   LmActiveNGrams(0) ;
   if ((verbose || LM_trace) && timer)
      {
      err << "Total time to process file: " << timer->readsec()
	  << " seconds (for " << sentences_processed << " sentences)."
	  << endl << endl ;
      }
   delete timer ;
   return ;
}

//----------------------------------------------------------------------

static void get_setup_file(int argc, char **argv)
{
   char *argv0 = argv[0] ;
   while (argc >= 2 && argv[1][0] == '-')
      {
      if (argv[1][1] == 's')
	 {
	 if (load_LM_setup(argv0, argv[1]+2))
	    return ;
	 break ;
	 }
      argc-- ;
      argv++ ;
      }
   // if we get here, either no setup file was specified, or unable to open it
   // so try to load default setup file
   if (!load_LM_setup(argv0,0))
      {
      // no default file either, so ensure that global variables are
      //   initialized by using an empty file
      load_LM_setup(argv0,FrNULL_DEVICE) ;
      }
   return ;
}

//----------------------------------------------------------------------

static void set_flag_var(bool &flag, char option)
{
   if (option == '+')
      flag = true ;
   else if (option == '-')
      flag = false ;
   else if (flag)
      flag = false ;
   else
      flag = true ;
   return ;
}

//----------------------------------------------------------------------

static void set_flag_var_inverted(bool &flag, char option)
{
   if (option == '-')
      flag = true ;
   else if (option == '+')
      flag = false ;
   else if (flag)
      flag = false ;
   else
      flag = true ;
   return ;
}

//----------------------------------------------------------------------

static void extract_affix_lengths(const char *parm)
{
   char *end = 0 ;
   unsigned long prefix = strtoul(parm,&end,0) ;
   if (end && end != parm && *end == ',')
      {
      parm = end + 1 ;
      unsigned long suffix = strtoul(parm,&end,0) ;
      if (end && end != parm)
	 {
	 build_affix_sizes = PACK_AFFIX_LENGTHS(prefix,suffix) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static void extract_hostname_and_port(const char *parm, char *&host_name,
				      int &port_number)
{
   FrFree(host_name) ;
   host_name = FrDupString(parm) ;
   if (!host_name)
      return ;
   char *colon = strchr(host_name,':') ;
   if (colon)
      {
      *colon = '\0' ;			// strip off port number
      port_number = atoi(colon+1) ;	// get port number into variable
      initiate_connection = true ;	// yes, we want to initiate the conn.
      }
   else
      {
      port_number = -1 ;
      FrFree(host_name) ;
      host_name = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

static void process_normal_option(char *argvN, const char *progname,
				  ostream &out, ostream &err)
{
   char flag_option = argvN[2] ;
   switch (argvN[1])
      {
      case '2':
	 if (flag_option == 'b')
	    {
	    bilingual_data = false ;
	    set_flag_var(auto_insert_EOS,argvN[3]) ;
	    }
	 else if (flag_option == 's')
	    {
	    set_flag_var(bilingual_data,argvN[3]) ;
	    bilingual_use_source = bilingual_data ;
	    auto_insert_EOS = bilingual_data ;
	    }
	 else
	    {
	    set_flag_var(bilingual_data,flag_option) ;
	    bilingual_use_source = false ;
	    auto_insert_EOS = bilingual_data ;
	    }
	 break ;
      case 'a':
	 abbrevs_filename = argvN+2 ;
	 break ;
      case 'A':
	 set_arcignore(argvN+2) ;
	 break ;
      case 'b':
	 best_count = atoi(argvN+2) ;
	 break ;
      case 'B':
	 if (flag_option == 'c')
	    {
	    compress_BWT = true ;
	    }
	 else if (flag_option == 'd')
	    discountmass = atof(argvN+3) ;
	 else if (flag_option == 'r')
	    {
	    reverse_BWT_words = false ;
	    }
	 else
	    {
	    compress_BWT = false ;
	    }
	 gen_BWT = true ;
	 break ;
      case 'c':
	 // case-sensitive or character-based language model
	 if (flag_option == 'b')
	    set_flag_var(char_based_model,flag_option) ;
	 else if (flag_option == 'r')
	    rare_words_threshold = atoi(argvN+3) ;
	 else if (flag_option == 's')
	    set_flag_var_inverted(ignore_case,argvN[3]) ;
	 else if (!isalpha(flag_option))
	    set_flag_var_inverted(ignore_case,flag_option) ;
	 break ;
      case 'C':
         {
	 if (flag_option == 'c')
	    {
	    compress_Ngram = true ;
	    }
	 else if (flag_option == 'p')
	    {
	    compute_perplexity = true ;
	    }
	 else
	    {
	    char *end ;
	    fastNgram_rank = (size_t)strtoul(argvN+2,&end,0) ;
	    if (fastNgram_rank < 2)
	       fastNgram_rank = 2 ;
	    if (end && end != argvN+2 && *end == ',' && Fr_isdigit(end[1]))
	       {
	       precompute_rank = (size_t)strtoul(end+1,0,0) ;
	       if (precompute_rank < 1)
		  precompute_rank = 1 ;
	       }
	    gen_fastNgram = true ;
	    }
	 break ;
	 }
      case 'f':
	 output_file = argvN+2 ;
	 break ;
      case 'g':
	 if (flag_option)
	    {
	    chart_file = argvN+2 ;
	    if (chart_file[0] == '=')
	       {
	       chart_file++ ;
	       generate_minimal_chart = true ;
	       }
	    if (strcmp(chart_file,"-") == 0)
	       chart_stream = &out ;
	    else
	       chart_stream = new ofstream(chart_file,ios::app) ;
	    if (!chart_stream || !chart_stream->good())
	       {
	       err << "Unable to open chart file, will not generate"
		     << endl ;
	       }
	    else
	       generate_chart = true ;
	    }
	 else
	    err << "Must specify a file to receive the new chart" << endl ;
	 break ;
      case 'i':
	 stopwords_filename = argvN+2 ;
	 break ;
      case 'k':
	 set_flag_var(remove_accents,flag_option) ;
	 break ;
      case 'K':
	 set_flag_var(show_coverage,flag_option) ;
	 set_flag_var(show_overlap_stats,flag_option) ;
	 break ;
      case 'M':
	 // merge arcs such as {Tienen->have} and {tener->have}
	 set_flag_var(ignore_source_morphology,flag_option) ;
	 break ;
      case 'N':
	 // convert ngram counts into fast-ngrams file
	 cvt_counts_to_fastNgram = true ;
	 if (argvN[2] == '/')
	    count_scaling_factor = strtoul(argvN+3,0,0) ;
	 else if (argvN[2] && Fr_isdigit(argvN[2]))
	    precompute_rank = (argvN[2] - '0') ;
	 if (precompute_rank < 1)
	    precompute_rank = 1 ;
	 if (count_scaling_factor < 1)
	    count_scaling_factor = 1 ;
	 break ;
      case 'o':
	 if (flag_option)
	    OOV_penalty = atof(argvN+2) ;
	 else
	    err << "Must specify an OOV penalty for -o" << endl ;
	 break ;
      case 'O':
	 set_flag_var(show_origins,flag_option) ;
	 break ;
      case 'p':
	 if (argvN[2] == ':')
	    extract_hostname_and_port(argvN+3,host_name,LM_port_number) ;
	 else if (argvN[2])
	    LM_port_number = atoi(argvN+2) ;
	 else
	    LM_port_number = -1 ;
	 break ;
      case 'P':
	 if (flag_option)
	    {
	    beam_width = atoi(argvN+2) ;
	    if (beam_width == 0)
	       beam_width = INT_MAX ;
	    }
	 else
	    beam_width = INT_MAX ;
	 break ;
      case 'q':
	 set_flag_var(question_particle_hack,flag_option) ;
	 break ;
      case 'Q':
	 set_flag_var(run_LM_quietly,flag_option) ;
	 if (run_LM_quietly)
	    verbose = false ;
	 break ;
      case 'r':
	 set_flag_var(show_raw_scores,flag_option) ;
	 break ;
      case 's':
	 // this option has already been processed, so nothing more to do
	 break ;
      case 'R':
	 word_stems_filename = argvN+2 ;
	 break ;
      case 'S':
	 set_flag_var(read_filenames_from_stdin,flag_option) ;
	 break ;
      case 't':
      case 'T':
	 LM_trace = atoi(argvN+2) ;
	 trace = LM_trace ;
	 break ;
      case 'U':
         {
	 const char *char_enc ;
	 if (argvN[2] == 'b')
	    {
	    Unicode_bswap = true ;
	    char_enc = argvN+3 ;
	    }
	 else
	    {
	    Unicode_bswap = false ;
	    char_enc = argvN+2 ;
	    }
	 LmSetCharEncoding(char_enc) ;
	 }
	 break ;
      case 'v': // output trace messages?
	 set_flag_var(verbose,flag_option) ;
	 if (verbose)
	    run_LM_quietly = false ;
	 break ;
      case 'w':
	 if (flag_option)
	    vocab_filename = argvN+2 ;
	 break ;
      case '%':
	 extract_affix_lengths(argvN+2) ;
	 break ;
      case '@':
	 LmInputAlreadyCanonical(true) ;
	 break ;
      case 'h':
      default:
	 usage(progname,err) ;
      }
}

//----------------------------------------------------------------------

static int process_cmdline_options(int argc, char **&argv,
				   const char *progname,
				   ostream &out, ostream &err)
{
   while (argc >= 2)
      {
      if (argv[1][0] == '-')
	 process_normal_option(argv[1],progname,out,err) ;
      else
	 break ;
      argv++ ;
      argc-- ;
      }
   return argc ;
}

//----------------------------------------------------------------------

static ostream *out = &cout ;
static istream *in = &cin ;
static ostream *err = &cerr ;

void terminate_program(int exitcode)
{
   (*err) << "Total time used by LM: " << runtimer->readsec()
	<< " seconds (for " << total_sentences << " sentence"
	<< (total_sentences==1?"":"s") << " in "
	<< files_processed << " file" << (files_processed==1?"":"s")
	<< ")." << endl ;
   delete runtimer ;
   if (xlat && xlat != out)
      {
      ((ofstream*)xlat)->close() ;
      delete xlat ;
      }
   set_out_of_memory_handler(oom_handler) ;
   shutdown_LM() ;
   untrap_signals() ;
   FrShutdown() ;
#ifdef USING_SOCKETS
   FrCloseConnection(in,out,err) ;
#endif /* USING_SOCKETS */
   FrDestroyWindow() ;
   if (verbose)
      {
      FrMemoryStats(cerr) ;
      if (LM_trace > 1)
	 {
	 FramepaC_gc() ;
	 cerr << "===== after memory compaction =====" << endl ;
	 FrMemoryStats(cerr) ;
	 }
      }
   if (verbose && LM_trace > 5)
      {
      cout << "Unfreed FrInteger:" ;
      FrInteger::dumpUnfreed(cout) ;
      cout << "Unfreed FrFloat:" ;
      FrFloat::dumpUnfreed(cout) ;
      cout << "Unfreed FrString:" << endl ;
      FrString::dumpUnfreed(cout) ;
      }
   exit(exitcode) ;
}

//----------------------------------------------------------------------

#ifdef SIGPIPE
static void sigpipe_handler(int)
{
   FrWarning("Lost connection to another process.  Shutting down") ;
   terminate_program(1) ;
   return ;
}
#endif /* SIGPIPE */

//----------------------------------------------------------------------

static void sigint_handler(int)
{
   static bool first_interrupt = true ;
   if (!first_interrupt)
      {
      // attempt a graceful shutdown of the child processes
      cout << "Shutting down (signal)...." << endl ;
      terminate_program(1) ;
      }
   else
      // ignore the first interrupt (i.e. require two Ctrl-C's to kill)
      first_interrupt = false ;
   return ;
}

//----------------------------------------------------------------------

static void sigill_handler(int)
{
   static bool first = true ;
   // first time, attempt a graceful shutdown
   if (first)
      {
      first = false ;
      FrWarning("illegal instruction or bus error; attempting to shut down") ;
      terminate_program(1) ;
      }
   else
      FrProgError("repeated illegal instruction or bus error!") ;
   return ;
}

//----------------------------------------------------------------------

static void sigfpe_handler(int)
{
   static bool first = true ;
   // first time, attempt a graceful shutdown
   if (first)
      {
      first = false ;
      FrWarning("unhandled floating-point error; attempting to shut down") ;
      terminate_program(1) ;
      }
   else
      FrProgError("repeated floating-point error!  Goodbye...") ;
   return ;
}

//----------------------------------------------------------------------

#ifdef SIGSEGV
static void sigsegv_handler(int)
{
   static bool first = true ;
   // first time, attempt a graceful shutdown of the child processes
   if (first)
      {
      first = false ;
      FrWarning("segmentation violation; attempting to shut down") ;
      terminate_program(1) ;
      }
   else
      FrProgError("repeated segmentation violation!") ;
   return ;
}
#endif /* SIGSEGV */

//----------------------------------------------------------------------
 
static void trap_signals()
{
   sigint = new FrSignalHandler(SIGINT,sigint_handler) ;
   sigill = new FrSignalHandler(SIGILL,sigill_handler) ;
   sig_fpe = new FrSignalHandler(SIGFPE,sigfpe_handler) ;
#ifdef SIGPIPE
   sigpipe = new FrSignalHandler(SIGPIPE,sigpipe_handler) ;
#endif /* SIGPIPE */
#ifdef SIGHUP
   sighup = new FrSignalHandler(SIGHUP,sigint_handler) ;
#endif /* SIGHUP */
#ifdef SIGBUS
   sigbus = new FrSignalHandler(SIGBUS,sigill_handler) ;
#endif /* SIGBUS */
#ifdef SIGSEGV
   sigsegv = new FrSignalHandler(SIGSEGV,sigsegv_handler) ;
#endif /* SIGSEGV */
   return ;
}

//----------------------------------------------------------------------

static void untrap_signals()
{
   delete sigint ;
   delete sigill ;
   delete sig_fpe ;
   delete sigpipe ;
   delete sighup ;
   delete sigbus ;
   delete sigsegv ;
   return ;
}

//----------------------------------------------------------------------

static FrList *read_input_filenames(int argc, char **argv)
{
   FrList *files = 0 ;
   if (read_filenames_from_stdin)
      {
      while (!feof(stdin))
	 {
	 char line[FrMAX_LINE] ;
	 fgets(line,sizeof(line),stdin) ;
	 line[sizeof(line)-1] = '\0' ;  // ensure proper termination
	 if (!feof(stdin) && !ferror(stdin))
	    pushlist(new FrString(line),files) ;
	 }

      }
   for (int i = 0 ; i < argc ; i++)
      {
      if (argv[i] && *argv[i])
	 pushlist(new FrString(argv[i]),files) ;
      }
   return listreverse(files) ;
}

//----------------------------------------------------------------------

static void convert_counts_to_NGM(int argc, char **argv)
{
   // skip first argument, which is not one we'll use
   --argc ;
   ++argv ;
   const char *destfile = argv[0] ;
   --argc ;
   ++argv ;
   FrLocalAllocC(char *,srcfiles,1024,argc) ;
   if (!srcfiles)
      {
      FrNoMemory("preparing to convert ngram counts") ;
      return ;
      }
   size_t rank = 0 ;
   for (int i = 0 ; i < argc ; i++)
      {
      srcfiles[i] = FrDupString(argv[i]) ;
      if (!srcfiles[i])
	 break ;
      rank = i+1 ;
      }
   if (destfile && *destfile && rank > 0)
      {
      if (verbose)
	 cout << "Generating " << rank << "-gram model" << endl ;
      if (!LmNGramsFile::convert(destfile,srcfiles,rank,precompute_rank,
				 count_scaling_factor,char_based_model))
	 cerr << "N-gram model creation failed!" << endl ;
      else
	 {
	 if (verbose)
	    {
	    LmNGramsFile *ngrams = new LmNGramsFile(destfile,1) ;
	    ngrams->dump(stdout,destfile,trace>=5) ;
	    delete ngrams ;
	    }
	 }
      }
   for (int i = 0 ; i < argc ; i++)
      FrFree(srcfiles[i]) ;
   FrLocalFree(srcfiles) ;
   return ;
}

//----------------------------------------------------------------------

static void compress_BWT_file(int argc, char **argv)
{
   // skip first argument, which is not one we'll use
   --argc ;
   ++argv ;
   const char *destfile = argv[0] ;
   --argc ;
   ++argv ;
   const char *srcfile = argv[0] ;
   if (srcfile && destfile && *srcfile && *destfile)
      {
      if (compress_ngram_model(srcfile,destfile))
	 cout << "; compression was successful" << endl ;
      }
   return ;
}

//----------------------------------------------------------------------

static void compute_BWT_perplexity(int argc, char **argv)
{
   // skip first argument, which is not one we'll use
   --argc ;
   ++argv ;
   const char *destfile = argv[0] ;
//   --argc ;
//   ++argv ;
//   const char *srcfile = argv[0] ;
//   if (srcfile && destfile && *srcfile && *destfile)
   if (destfile && *destfile)
      {
      LmNGramModel *model = LmNGramModel::newModel(destfile,fastNgram_rank) ;
      if (model && model->OK())
	 {
	 for (size_t i = 2 ; i <= model->maxNgramLength() ; i++)
	    {
	    double perp = model->perplexity(i) ;
	    if (perp >= 0)
	       cout << "perplexity at rank " << i << " = " << perp << endl ;
	    }
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static void convert_BWT_to_NGM(int argc, char **argv)
{
   // skip first argument, which is not one we'll use
   --argc ;
   ++argv ;
   const char *destfile = argv[0] ;
   --argc ;
   ++argv ;
   const char *srcfile = argv[0] ;
   if (srcfile && destfile && *srcfile && *destfile)
      {
      LmNGramModel *model = LmNGramModel::newModel(srcfile,fastNgram_rank) ;
      if (model && model->OK())
	 {
	 if (!model->convertBWTtoNGM(destfile,fastNgram_rank,precompute_rank))
	    cerr << "N-gram model conversion failed!" << endl ;
	 if (verbose)
	    {
	    LmNGramsFile *ngrams = new LmNGramsFile(destfile,1) ;
	    ngrams->dump(stdout,destfile,trace>=5) ;
	    delete ngrams ;
	    }
	 }
      delete model ;
      }
   return ;
}

//----------------------------------------------------------------------

static void generate_ngram_model(int argc, char **argv)
{
   // skip first argument, which is not one we'll use
   --argc ;
   ++argv ;
   const char *destfile = argv[0] ;
   --argc ;
   ++argv ;

   FrList *input_files = read_input_filenames(argc,argv) ;
   if (input_files)
      {
      if (!generate_ngram_model(destfile,vocab_filename,input_files,
				compress_BWT,discountmass,reverse_BWT_words,
				abbrevs_filename,word_stems_filename,
				stopwords_filename))
	 cerr << "N-gram model generation failed!" << endl ;
      free_object(input_files) ;
      }
   return ;
}

//----------------------------------------------------------------------

static void perform_LM_processing(int argc, char **argv)
{
   if (strcmp(argv[1],".") != 0)
      {
      free_object(language_model_files) ;
      language_model_files = new FrList(new FrString(argv[1])) ;
      }
   else if (!language_model_files && !lm_config->models)
      {
      (*err) << "Can not use a default language model because no\n"
	 "default was defined in the configuration file." << endl ;
      exit(1) ;
      }
   LmNGramModel **ngrams = 0 ;
   if (lm_config->models)
      ngrams = load_LM_ngrams(lm_config->models,language_model_count) ;
   if (!ngrams)
      ngrams = load_LM_ngrams(language_model_files,language_model_count) ;
   if (!ngrams)
      {
      (*err) << "; Unable to load any language models!" << endl ;
      LmSetScaleFactor(0.0) ;		// disable use of language models
      }
   TargetWord::setModelCount(language_model_count) ;
   if (LM_trace)
      {
      FrMemoryStats(*err) ;
      (*err) << endl ;
      }
   if (output_file)
      {
      if (strcmp(output_file,"-") == 0)
	 {
	 xlat = out ;
	 }
      else
	 {
	 int fh = open(output_file,O_WRONLY | O_CREAT, 0644) ;
	 if (fh >= 0)
	    {
	    lseek(fh,0L,SEEK_END) ;
	    xlat = Fr_ofstream(fh) ;
	    }
	 else
	    output_file = 0 ;
	 }
      }
   // let calling program (if any) know that we are ready to roll....
   (*out) << "Ready!" << endl ;
   if (argc > 2)
      {
      while (argc > 2)
	 {
	 const char *file = argv[2] ;
	 bool piped  ;
	 FILE *fp = FrOpenMaybeCompressedInfile(file,piped) ;
	 istream *in = fp ? Fr_ifstream(fileno(fp)) : 0 ;
	 if (in && in->good())
	    {
	    if (!run_LM_quietly)
	       (*err) << "Processing file " << file << endl ;
	    if (output_file)
	       *xlat << ">>> Translations from file " << file << " <<<"
			<< endl ;
	    files_processed++ ;
	    process_file(ngrams,*in,*out,*err) ;
	    delete in ;
	    FrCloseMaybeCompressedInfile(fp,piped) ;
	    fp = 0 ;
	    if (output_file)
	       *xlat << "-----------------------------------------\n" << endl;
	    }
	 else
	    (*err) << "Unable to open " << argv[2] << ", skipping." << endl ;
	 FrCloseMaybeCompressedInfile(fp,piped) ;
	 argv++ ;
	 argc-- ;
	 }
      }
   else
      process_file(ngrams,*in,*out,*err) ;
   if (generate_chart)
      {
      if (chart_stream != out)
	 {
	 ((ofstream*)chart_stream)->close() ;
	 delete chart_stream ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

int
#ifndef __WATCOMC__
   __FrCDECL
#endif
   main(int argc, char **argv)
{
   char *argv0 = argv[0] ;

   initialize_FramepaC() ;
   WordInfo::initVariables() ;
   get_setup_file(argc,argv) ;
   apply_LM_configuration(lm_config) ;
   configure_translation_engines(lm_config ? lm_config->engines : 0) ;
   oom_handler = set_out_of_memory_handler(memory_exhausted) ;
   argc = process_cmdline_options(argc,argv,argv0,*out,*err) ;
   thread_pool = FrCreateGlobalThreadPool(lm_config->maxthreads,
					  LmPOOL_QUEUESIZE) ;
   if (word_stems_filename && !gen_BWT)
      {
      // we'll load the stems later if generating a new language model
      LmLoadWordStems(word_stems_filename) ;
      }
#ifdef USING_SOCKETS
   if (argc >= 2 && LM_port_number > 0)
      {
      FrHideWindow() ;
      if (initiate_connection)
	 {
	 if (FrInitiateConnection(host_name,LM_port_number,in,out,err))
	    {
	    identify_LM(*out) ;
	    }
	 else
	    {
	    (*err) << "Error: Unable to initiate network connection!" << endl ;
	    FrShutdown() ;
	    return 2 ;
	    }
	 }
      else
	 FrAwaitConnection(LM_port_number,in,out,err) ;
      }
#endif /* USING_SOCKETS */
   trap_signals() ;
   runtimer = new FrTimer ;
   if (chart_stream == &cout)
      chart_stream = out ;
   if (argc < 2)
      usage(argv0,*err) ;
   else if (compute_perplexity)
      compute_BWT_perplexity(argc,argv) ;
   else if (compress_Ngram)
      compress_BWT_file(argc,argv) ;
   else if (gen_fastNgram)
      convert_BWT_to_NGM(argc,argv) ;
   else if (cvt_counts_to_fastNgram)
      convert_counts_to_NGM(argc,argv) ;
   else if (gen_BWT)
      generate_ngram_model(argc,argv) ;
   else
      perform_LM_processing(argc,argv) ;
   terminate_program(0) ;
   return 0 ;
}

// end of file lm.cpp //
