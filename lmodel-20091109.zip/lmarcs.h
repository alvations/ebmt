/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmarcs.h	classes ChartArc, ChartArcElt, ChartContext 	*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,2000,2001,2002,2003,2004,	*/
/*		2005,2006,2007,2008,2009 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMARCS_H_INCLUDED
#define __LMARCS_H_INCLUDED

#include "FramepaC.h"

#ifndef __LMBITSET_H_INCLUDED
#include "lmbitset.h"
#endif

#ifndef __LMNGRAM_H_INCLUDED
#include "lmngram.h"
#endif

#ifndef __LMBFS_H_INCLUDED
#include "lmbfs.h"
#endif

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

#define SOURCE_ALIGN_EOD ((uint16_t)~0)

#define LmINVALID_PROB	(999.9)

/************************************************************************/
/*	Types								*/
/************************************************************************/

class TargetWord ;
class TargetWordStats ;
class ChartArc ;
class ChartContext ;
class ParseChart ;
class MTEngine ;

enum ChartEntryType
   {
   CE_none,
   CE_Merged,
   CE_LM,
   } ;

typedef uint32_t ChartEntryTypes ; // bitmap of entry types

/************************************************************************/
/************************************************************************/

class WordInfo
   {
   private:
      char  *m_surface ;
      FrSymbol *m_symbol ;
   public:
      void *operator new(size_t /*size*/, void *where) { return where ; }
      void *operator new(size_t size) { return FrMalloc(size) ; }
      void operator delete(void *blk) { FrFree(blk) ; }
      WordInfo() { m_surface = 0 ; m_symbol = 0 ; }
      WordInfo(const char *word, size_t wordlen)
	 { init(word,wordlen) ; }
      ~WordInfo() { FrFree(m_surface) ; }
      void init() ;
      void init(const char *word, size_t wordlen) ;

      WordInfo &operator = (const WordInfo &) ;

      // accessors
      const char *surface() const { return m_surface ; }
      FrSymbol *symbol() const { return m_symbol ; }

      static void initVariables() ;
   } ;

/************************************************************************/
/************************************************************************/

class ChartArcSuccessor
   {
   private:
      ChartArc *m_successor ;
      LmUSHORT  m_srcoverlap ;
      LmUSHORT	m_trgoverlap ;
      LmUSHORT	m_reordering ;
      bool      m_fillsgap ;
   public:
      void init(ChartArc *arc, size_t s_ovr = 0, size_t t_ovr = 0,
		size_t reord = 0, bool fills = false)
	 { m_successor = arc ; m_srcoverlap = (LmUSHORT)s_ovr ;
	   m_trgoverlap = (LmUSHORT)t_ovr ;
	   m_fillsgap = fills ; m_reordering = (LmUSHORT)reord ; }

      ChartArcSuccessor() { m_successor = 0 ; m_srcoverlap=m_trgoverlap=0 ; }
      ChartArcSuccessor(ChartArc *arc, size_t s_ovr = 0, size_t t_ovr = 0,
			size_t reord = 0, bool fills = false)
	 { init(arc,s_ovr,t_ovr,reord,fills) ; }
      ~ChartArcSuccessor() {}

      // accessors
      ChartArc *arc() const { return m_successor ; }
      size_t sourceOverlap() const { return m_srcoverlap ; }
      size_t targetOverlap() const { return m_trgoverlap ; }
      size_t reordering() const { return m_reordering ; }
      bool fillsGap() const { return m_fillsgap ; }
   } ;

/************************************************************************/
/************************************************************************/

class ComponentArcInfo
   {
   private:
      const ChartArc *m_arc ;
      int32_t         m_overlap ;
      int32_t	      m_trgposition ;
      bool	      m_subsumed ;
   public:
      void *operator new(size_t, void *where) { return where ; }
      void init(const ChartArc *arc, size_t overlap, size_t trgpos,
		bool sub = false)
	 { m_arc = arc ; m_overlap = (int32_t)overlap ;
	   m_trgposition = (int32_t)trgpos ; m_subsumed = sub ; }
      ComponentArcInfo() { init(0,0,0) ; }
      ComponentArcInfo(const ChartArc *arc, size_t overlap = 0,
		       size_t trgpos = 0, bool sub = false)
	 { init(arc,overlap,trgpos,sub) ; }
      ~ComponentArcInfo() {}

      // accessors
      const ChartArc *arc() const { return m_arc ; }
      size_t overlap() const { return m_overlap ; }
      size_t targetPosition() const { return m_trgposition ; }
      bool subsumed() const { return m_subsumed ; }

      // manipulators
      void setTargetPosition(size_t pos) { m_trgposition = (int32_t)pos ; }
      void incrTargetPosition(size_t ofs) { m_trgposition += (int32_t)ofs ; }
      void markSubsumed() { m_subsumed = true ; }
   } ;

/************************************************************************/
/************************************************************************/

class LmConflicts
   {
   private:
      LmBitFlags *m_conflictset ;
      FrUINT32 m_count ;
      FrUINT32 m_min ;
      FrUINT32 m_max ;
   public:
      LmConflicts() { m_count = m_min = m_max = 0 ; m_conflictset = 0 ; }
      ~LmConflicts()
	 { FrFree(m_conflictset) ; m_conflictset = 0 ; m_count = m_max = 0 ;}

      // manipulators
      void init(size_t min, size_t max) ;
      void addConflict(size_t N) ;

      // accessors
      LmBitFlags *conflictSet() const { return m_conflictset ; }
      FrUINT32 numConflicts() const { return m_count ; }
      FrUINT32 minStored() const { return m_min ; }
      FrUINT32 maxStored() const { return m_max ; }
      bool conflicts(size_t N) const
	 { if (N >= m_min && N < m_max)
	    return LmGetBit(m_conflictset,N - m_min) ;
	  else return false ; }
      bool conflicts(const LmConflicts &other) const ;

   } ;

/************************************************************************/
/************************************************************************/

class LmFeatures
   {
   private:
      double m_weight ;
      double m_score ;
      double m_quality ;
      double m_doccontext ;
      double m_sntcontext ;
      double m_phrcontext ;

   public:
      void init(const LmFeatures &) ;
      void init(const ChartArc *arc) ;
      void init(const FrTextSpan *) ;
      LmFeatures(const LmFeatures &orig) { init(orig) ; }
      LmFeatures(const ChartArc *arc = 0) { init(arc) ; }
      LmFeatures(const FrTextSpan *span) { init(span) ; }
      ~LmFeatures() {}

      // accessors
      double weight() const { return m_weight ; }
      double score() const { return m_score ; }
      double quality() const { return m_quality ; }
      double docContext() const { return m_doccontext ; }
      double sentContext() const { return m_sntcontext ; }
      double phraseContext() const { return m_phrcontext ; }

      // modifiers
      void setWeight(double wt) { m_weight = wt ; }
      void incrWeight(double incr) { m_weight += incr ; }
      void setScore(double sc) { m_score = sc ; }
      void incrScore(double incr) { m_score += incr ; }
      void setQuality(double q) { m_quality = q ; }
      void incrQuality(double incr) { m_quality += incr ; }
      void setDocContext(double d) { m_doccontext = d ; }
      void incrDocContext(double incr) { m_doccontext += incr ; }
      void setSentContext(double s) { m_sntcontext = s ; }
      void incrSentContext(double incr) { m_sntcontext += incr ; }
      void setPhraseContext(double p) { m_phrcontext = p ; }
      void incrPhraseContext(double incr) { m_phrcontext += incr ; }
   } ;

/************************************************************************/
/************************************************************************/

class ChartArc
   {
   private:
      static FrAllocator allocator ;
   protected:
      ChartArc *m_next ;
   private:
      ChartArcSuccessor *m_successors ;	// array of arcs that could add to path
      WordInfo *source_word_info ;
      TargetWordStats *target_word_stats ;
      ComponentArcInfo *m_subsumes ;	// arcs subsumed by this one
      ParseChart *m_chart ;		// the chart containing this arc
      char *source_text ;
      char *target_text ;
      LmBitFlags *m_source_cover ;	// which words are actually covered?
      char *target_prefix ;
      char *target_suffix ;
      LmNGramModel **m_models ;
      const FrStruct *m_metadata ;	// meta-data in input FrTextSpans
      LmConflicts m_conflicts ;
      double m_score ;			// translation-model score for arc
      double m_logscore ;		// log(m_socre)
      double m_quality ;		// quality score for arc
      double m_logquality ;		// log(m_quality)
      double m_weight ;			// weight assigned to arc by engine
      double m_logweight ;		// log(m_weight)
      double m_doccontext ;		// document-level context score
      double m_sntcontext ;		// sentence-level context score
      double m_phrcontext ;		// phrase-level context score
      double m_lengthbonus ;
      double m_chunkingbonus ;
      double m_untrans ;		// penalty for untranslated arc
      double m_userscores[MAX_USER_SCORES] ;
      double m_futureutility ;
      size_t m_arcID ;
      size_t m_numsuccessors ;
      size_t m_numsubsumed ;
      int    m_occurrences ;
      LmUSHORT m_startpos ;
      LmUSHORT m_coverage ;
      LmUSHORT m_match_wc ;
      LmUSHORT m_source_span ;
      LmUSHORT m_source_wc ;
      LmUSHORT m_arclen ;
      bool     question ;
      bool     has_gap_markers ;
      bool     has_alignments ;
      bool     has_user_scores ;
      bool     m_is_successor ;
      ChartEntryTypes arctype ;
   private: //methods
      void init() ;
      void makeTargetText() ;
      void allocSourceCover(size_t count) ;
      void freeSourceCover() ;
      ComponentArcInfo *mergeSubsumedArcs(const ChartArc *other,
					  size_t &num_subsumed,
					  size_t trg_offset) const ;
   public:
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      ChartArc() ;
      ChartArc(const ChartArc *base_arc, const ChartArc *add_arc,
	       TargetWordStats target_words[], size_t num_words,
	       size_t trg_offset) ;
      ChartArc(MTEngine *engine, char *source, char *translation,
	       const FrList *alignment, size_t startpos, int cover,
	       const LmFeatures &, LmNGramModel **models, const FrList *morph,
	       const FrList *trg_restrict, ParseChart *chart,
	       ChartArc *nextarc) ;
      ~ChartArc() ;
      static ChartArc *combineArcs(const ChartArc *arc1, const ChartArc *arc2,
				   size_t trg_overlap);

      // modifiers
      void setNext(ChartArc *nxt) { m_next = nxt ; }
      void setNextArc(ChartArc *nxt) { m_next = nxt ; }
      void setChart(ParseChart *chart) { m_chart = chart ; }
      void setID(size_t id) { m_arcID = id ; }
      void markAsSuccessor() { m_is_successor = true ; }
      void markNotSuccessor() { m_is_successor = false ; }
      void updateInputCover(LmBitFlags *overall_coverage, LmUSHORT &bytecover,
			    const size_t *word_boundaries) const ;
      void mergeArc(MTEngine *engine, const LmFeatures &, double weight) ;
      void mergeArc(ChartEntryType type, const LmFeatures &, double weight) ;
      bool merge(MTEngine *engine, const char *source,
		 const char *translation, size_t cover, const LmFeatures &,
		 ChartArc **prev_arc = 0) ;

      ChartArc *reverseList() ;

      // tests
      bool allowableArc(const LmBitFlags *previous_coverage,
			size_t src_overlap) const ;
      bool canFillGap(const ChartArc *, size_t srcoverlap,
		      size_t &trgoverlap) const ;

      // I/O
      ostream &dump(ostream &output) const ;
      friend ostream &operator << (ostream &output, const ChartArc *) ;

      // manipulation functions
      void initUserScores() ;
      void initSourceWC() ;
      void setStart(size_t start) { m_startpos = start ; }
      void setWeight(double weight) ;
      void setQuality(double qual) ;
      void setScore(double score) ;
      void setContextScores(double d, double s, double p)
	 { m_doccontext = d ; m_sntcontext = s ; m_phrcontext = p ; }
      void setDocContext(double c) { m_doccontext = c ; }
      void setSentContext(double c) { m_sntcontext = c ; }
      void setPhraseContext(double c) { m_phrcontext = c ; }
      void setFutureUtility(double util) { m_futureutility = util ; }
      void setFutureUtility(class LmNGramModel **models) ;
      void setDecoration(const char *prefix, const char *suffix) ;
      void setMetaData(const FrStruct *md)
	 { m_metadata = md ; } // note: 'md' must remain valid!
      void setLengthBonus(double lenbonus) { m_lengthbonus = lenbonus ; }
      void setChunkingBonus(double chbonus) ;
      void setChunkingBonus(const FrTextSpan *span) ;
      void setUntransPenalty(double pen) { m_untrans = pen ; }
      void setSuccessors(ChartArcSuccessor *successors, size_t count) ;
      void setSourceSpan(size_t span) { m_source_span = span ; }
      void setSourceAlignment(size_t wordnum, size_t srcstart, size_t srcend);
      void overrideTypes(ChartEntryTypes types)
	    { arctype &= ~types ; }
      void setFillerLocations() ;
      void addConflict(const ChartArc *, size_t total_arcs) ;

      // access to state
      ChartArc *next() const { return m_next ; }
      ChartArc *nextArc() const { return m_next ; }
      size_t arcID() const { return m_arcID ; }
      ParseChart *chart() const { return m_chart ; }
      const FrSymbol *nthWord(size_t n) const ;
      LmWordID_t nthWordID(size_t n, size_t modelnum) const ;
      int occurrences() const { return m_occurrences ; }
      LmNGramModel **models() const { return m_models ; }
      double score() const { return m_score ; }
      double logScore() const { return m_logscore ; }
      double quality() const { return m_quality ; }
      double logQuality() const { return m_logquality ; }
      double weight() const { return m_weight ; }
      double logWeight() const { return m_logweight ; }
      double chunkingBonus() const { return m_chunkingbonus ; }
      double lengthBonus() const { return m_lengthbonus ; }
      double untransPenalty() const { return m_untrans ; }
      double docContext() const { return m_doccontext ; }
      double sentContext() const { return m_sntcontext ; }
      double phraseContext() const { return m_phrcontext ; }
      double futureUtility() const { return m_futureutility ; }
      double userScore(size_t N) const
	 { return (N<MAX_USER_SCORES) ? m_userscores[N] : 0.0 ; }
      size_t startPosition() const { return m_startpos ; }
      size_t coverage() const { return m_coverage ; }
      size_t endPosition() const { return m_startpos + m_coverage - 1 ; }
      size_t pastEndPosition() const { return m_startpos + m_coverage ; }
      size_t arcLength() const { return m_arclen ; }
      size_t sourceWordSpan() const { return m_source_span ; }
      size_t sourceWordCount() const { return m_source_wc ; }
      size_t matchWordCount() const { return m_match_wc ; }
      ChartEntryTypes arcType() const { return arctype ; }
      const char *arc_type_name() const ;
      const WordInfo *sourceWordInfo() const { return source_word_info ; }
      const TargetWordStats *targetWordStats(size_t N) const ;
      const TargetWordStats *targetWordStats() const
	 { return target_word_stats ; }
      const TargetWord *targetWordInfo(size_t N) const ;
      const ComponentArcInfo *subsumedArcs() const
	 { return m_subsumes ; }
      const ChartArc *subsumedArc(size_t N) const
	 { return (subsumedArcs() && N < numSubsumedArcs())
	      ? m_subsumes[N].arc() : 0 ; }
      const ComponentArcInfo *subsumedArcInfo(size_t N) const
	 { return (subsumedArcs() && N < numSubsumedArcs())
	      ? &m_subsumes[N] : 0 ; }
      const char *sourceText() const { return source_text ; }
      const char *targetText() const { return target_text ; }
      const LmBitFlags *sourceCover() const
	 { return LmGetBit((LmBitFlags*)&m_source_cover,0) ? (LmBitFlags*)&m_source_cover : m_source_cover ; }
      LmBitFlags *sourceCover()
	 { return LmGetBit((LmBitFlags*)&m_source_cover,0) ? (LmBitFlags*)&m_source_cover : m_source_cover ; }
      bool sourceCovered(size_t N) const ;
      const char *targetPrefix() const { return target_prefix ; }
      const char *targetSuffix() const { return target_suffix ; }
      FrSymbol *sourceWord(size_t N) const ;
      FrSymbol *targetWord(size_t N) const ;
      const FrStruct *metaData() const { return m_metadata ; }
      const LmConflicts &conflicts() const { return m_conflicts ; }
      size_t numConflicts() const { return m_conflicts.numConflicts() ; }
      bool isQuestion() const { return question ; }
      bool hasGapMarkers() const { return has_gap_markers ; }
      bool hasAlignments() const { return has_alignments ; }
      bool hasUserScores() const { return has_user_scores ; }
      bool isSuccessor() const { return m_is_successor ; }
      bool isComposite() const { return m_numsubsumed > 0 ; }
      bool subsumes(const ChartArc *other) const ;
      FrList *sourceAlignments() const ;
      size_t numSuccessors() const { return m_numsuccessors ; }
      size_t numSubsumedArcs() const { return m_numsubsumed ; }
      ChartArcSuccessor *successor(size_t N) const
	 { return (N < numSuccessors()) ? &m_successors[N] : 0 ; }
      ChartArc *successorArc(size_t N) const
	 { return (N < numSuccessors()) ? m_successors[N].arc() : 0 ; }

      static ChartEntryType allocateArcType(FrSymbol *tag) ;
      static void freeArcTypes() ;
      static size_t maxEngines() ;
   } ;

/************************************************************************/
/************************************************************************/

class TargetWord
   {
   private:
      static FrAllocator allocator ;
      static FrAllocator *s_IDallocator ;
      static size_t s_num_models ;
   private:
      const FrSymbol *m_name ;
      ChartArc *source_arc ;
      uint16_t *source_words ;
      LmWordID_t **m_IDs ;
      const FrSymbol *m_match_class ;	// restriction on gap-filling
      size_t m_refcount ;		// how many pointers to this instance?
      size_t m_gapfiller ;		// source location of filler if gap
      bool   m_gapmarker ;		// is this word a gap marker?
   public: // methods
      void *operator new(size_t) { return allocator.allocate() ; }
      void operator delete(void *blk) { allocator.release(blk) ; }
      static void initIDAllocator(size_t num_models) ;
      static void freeIDAllocator() ;
      void init(LmWordID_t **ids,const FrSymbol *nm,ChartArc *arc,
		const FrSymbol *cl = 0) ;
      void init(LmNGramModel **models, FrSymbol *nm, ChartArc *arc,
		FrSymbol *cl = 0) ;
      void init(const TargetWord &oldtw)
	 { init(oldtw.m_IDs,oldtw.name(),oldtw.sourceArc(),
		oldtw.matchClass()) ; }
      TargetWord(LmNGramModel **models, FrSymbol *nm, ChartArc *arc,
		 FrSymbol *cl = 0)
	 { init(models,nm,arc,cl) ; }
      TargetWord(const TargetWord &oldtw) { init(oldtw) ; }
   protected:
      ~TargetWord() { freeSourceWords() ; freeWordID() ; }
   public:
      void free() { if (m_refcount < 1 ) delete this ; }
      TargetWord &operator = (const TargetWord &oldtw)
	 { init(oldtw.m_IDs,oldtw.name(),oldtw.sourceArc()) ; return *this ; }
      void freeWordID() ;
      static void zapAll() ;

      // modifiers
      void setWordID(LmNGramModel **models, FrSymbol *nm) ;
      void setSourceWords(size_t first, size_t last) ;
      void setSourceWords(const FrList *locations) ;
      void setMatchClass(FrSymbol *cl, bool override = false)
	 { if (override || !m_match_class) m_match_class = cl ; }
      void freeSourceWords() ;
      static void setModelCount(size_t num_models)
	 { initIDAllocator(num_models) ; }
      void setFillerLocation(size_t arc_start) ;
      void addReference() { m_refcount++ ; }
      void removeReference() { if (m_refcount > 0) m_refcount-- ; }

      // accessors
      bool haveIDs() const { return m_IDs != 0 ; }
      bool isGapMarker() const { return m_gapmarker ; }
      bool isEmbeddedGapMarker() const ;
      LmWordID_t ID(size_t N, size_t C) const { return m_IDs[N][C] ; }
      LmWordID_t ID(size_t N) const { return m_IDs[N][1] ; }
      size_t IDcount(size_t N) const { return m_IDs[N][0] ; }
      const LmWordID_t * const *IDs() const { return m_IDs ; }
      LmWordID_t *IDs(size_t N) const { return m_IDs[N] ; }
      const FrSymbol *name() const { return m_name ; }
      const FrSymbol *matchClass() const { return m_match_class ; }
      ChartArc *sourceArc() const { return source_arc ; }
      const WordInfo *sourceWord() const
	 { return source_arc->sourceWordInfo() ; }
      const FrSymbol *nthWord(int n) const { return source_arc->nthWord(n) ; }
      bool isOOV(size_t N = 0) const { return ID(N) <= 0 ; }
      const uint16_t *sourceWords() const { return source_words ; }
      FrList *sourceAlignment() const ;
      size_t gapFillerLocation() const { return m_gapfiller ; }
   } ;

/************************************************************************/
/************************************************************************/

class TargetWordRef
   {
   protected:
      TargetWord *m_targetword ;
      double m_probability ;
      double m_avgngram ;
      unsigned m_coverage ;
   public:
      void init(TargetWord *tword, ChartArc *, size_t cover = 1) ;
      void init(TargetWord *tword, size_t cover) ;
      void init(const TargetWordRef &orig) ;
      TargetWordRef(TargetWord *tword, size_t cover = 1)
	 { init(tword,cover) ; }
      ~TargetWordRef() { if (m_targetword) m_targetword->removeReference() ; }

      // accessors
      TargetWord *targetWord() const { return m_targetword ; }
      bool probabilityKnown() const
	 { return m_probability != LmINVALID_PROB ; }
      double probability() const { return m_probability ; }
      double avgNgram() const { return m_avgngram ; }
      size_t coverage() const { return m_coverage ; }

      const LmWordID_t * const *IDs() const
	 { return targetWord() ? targetWord()->IDs() : 0; }
      LmWordID_t *IDs(size_t N) const
	 { return targetWord() ? targetWord()->IDs(N) : 0; }
      LmWordID_t ID(size_t N) const
	 { return targetWord()? targetWord()->ID(N) : LmVOCAB_WORD_NOT_FOUND; }
      LmWordID_t ID(size_t N, size_t C) const
	 { return targetWord() ? targetWord()->ID(N,C) : LmVOCAB_WORD_NOT_FOUND ; }
      size_t IDcount(size_t N) const
	 { return targetWord()? targetWord()->IDcount(N) : 0 ; }
      const FrSymbol *name() const
	 { return targetWord() ? targetWord()->name() : 0 ; }
      const ChartArc *sourceArc() const
	 { return targetWord() ? targetWord()->sourceArc() : 0 ; }
      bool isGapMarker() const
	 { return targetWord() ? targetWord()->isGapMarker() : false ; }

      // modifiers
      void setWord(TargetWord *tword)
	 { if (m_targetword) m_targetword->removeReference() ;
	   m_targetword = tword ; if (tword) tword->addReference() ; }
      void setCoverage(size_t cover) { m_coverage = (unsigned)cover ; }
      void setProbability(double prob) { m_probability = prob ; }
      void setAvgNgram(double avg) { m_avgngram = avg ; }
      void invalidateProbability() { m_probability = LmINVALID_PROB ; }
      void addCover(const TargetWordRef *other) ;
   } ;

//----------------------------------------------------------------------

class TargetWordStats : public TargetWordRef, public LmFeatures
   {
   private:
      double m_lenbonus ;
      double m_chunkbonus ;
      double m_untrans ;

   public:
      void init(TargetWord *tword, const ChartArc *arc, size_t cover = 1) ;
      void init(const ChartArc *arc) ;
      void init(const TargetWordStats &orig) ;
      TargetWordStats(TargetWord *tword, const ChartArc *arc,
		      size_t cover = 1)
	 : TargetWordRef(tword,cover)
	 { init(arc) ; }
      ~TargetWordStats() {}

      // accessors
      double lengthBonus() const { return m_lenbonus ; }
      double chunkingBonus() const { return m_chunkbonus ; }
      double untransPenalty() const { return m_untrans ; }

      // modifiers
      void addCover(const TargetWordStats *other) ;
      void setLengthBonus(double lb) { m_lenbonus = lb ; }
      void setChunkingBonus(double cb) { m_chunkbonus = cb ; }
      void incrChunkingBonus(double cb) { m_chunkbonus += cb ; }
      void setUntransPenalty(double ut) { m_untrans = ut ; }
      void incrUntransPenalty(double ut) { m_untrans += ut ; }
   } ;

inline void TargetWordRef::addCover(const TargetWordRef *other)
{
   if (other)
      m_coverage += other->coverage() ; 
   return ;
}

/************************************************************************/
/************************************************************************/

class TargetWordList : public FrObject
   {
   private:
      int          numwords ;
      size_t	   m_numarcs ;
      TargetWord   **wordlist ;
      const ChartArc **m_arcs ;
      LmNGramModel **m_models ;
   public:
      TargetWordList(const TargetWord * const *words,int num,
		     LmNGramModel **models) ;
      TargetWordList(const TargetWordRef *words,int num,
		     LmNGramModel **models) ;
      virtual ~TargetWordList() ;
      virtual void freeObject() ;
      virtual size_t length() const ;

      // accessors
      size_t twlLength() const { return numwords ; }
      TargetWord *wordN(int N) const { return wordlist[N] ; }
      TargetWord **words() const { return wordlist ; }
      size_t numArcs() const { return m_numarcs ; }
      const ChartArc *arc(size_t N) const
	 { return (N < m_numarcs) ? m_arcs[N] : 0 ; }
      LmNGramModel * const *models() const { return m_models ; }
      const TargetWord *operator [] (int N) const
	{ return (N >= 0 && N < numwords) ? wordlist[N] : 0 ; }

      // modifiers
      void addArcs(const ComponentArcInfo *arcs, size_t numarcs) ;
      bool removeWord(size_t N) ;
      void updateLength(int newlen) { numwords = newlen ; }
   } ;

/************************************************************************/
/************************************************************************/

ostream &dump_arc_list(ostream &out, TargetWordList *) ;
void dump_arc_info(ostream &out, const ChartArc *arc) ;

template <class T> void LmMergeTargetWords(T newtw[], size_t wordcount,
					   const T oldtw[], size_t prev,
					   const TargetWordStats tw[],
					   size_t new_start,
					   size_t new_end,
					   BFSNode *node,
					   LmUSHORT &OOV_count) ;
#endif /* !__LMARCS_H_INCLUDED */

// end of file lmarcs.h //
