/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmbuild.h	  	functions for building a language model	*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1996,1997,2001,2003,2004,2006,2007,2008 Ralf Brown	*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMBUILD_H_INCLUDED
#define __LMBUILD_H_INCLUDED

// Magick to get files bigger than 2GB
#ifndef _LARGEFILE_SOURCE
#define _LARGEFILE_SOURCE 1		// allow use of 64-bit file functions
#endif
#ifndef _LARGEFILE64_SOURCE
#define _LARGEFILE64_SOURCE 1		// extended 64-bit file functions
#endif
#ifndef _FILE_OFFSET_BITS
#define _FILE_OFFSET_BITS 64
#endif

/************************************************************************/
/************************************************************************/

bool generate_ngram_model(const char *outfile, const char *vocabfile,
			    FrList *inputfiles, bool compress = false,
			    double discount = 0.0,
			    bool reverse_words = true,
			    const char *abbrevs_file = 0,
			    const char *wordstems_file = 0,
			    const char *stopwords_file = 0) ;

bool compress_ngram_model(const char *filename, const char *compfilename) ;

//----------------------------------------------------------------------

extern bool read_filenames_from_stdin ;

#endif /* !__LMBUILD_H_INCLUDED */

// end of file lmbuild.h //
