/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Language Modeler -- genre support					*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmgenre.h							*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2005,2006,2007,2008,2009 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMGENRE_H_INCLUDED
#define __LMGENRE_H_INCLUDED

class LmGenreSettings
   {
   protected:
      char *m_genre ;
   private:
      class LMGlobalVariables *m_vars ;
      LmGenreSettings *m_next ;
      LmGenreSettings *m_prev ;
   public: // data
      FrList *_language_model_weights ;
      char *_untrans_prefix ;
      char *_untrans_suffix ;
      double _interleave_penalty ;
      double _OOV_penalty ;
      double _nulltrans_value ;
      double _nulltrans_logvalue ;
      double _insertion_penalty ;
      double _max_overlap_diff ;
      double _overlap_bonus ;
      double _LM_scale_factor ;
      double _LM_scale_adjust ;
      double _source_cover_power ;
      double _reordering_limit ;
      double _reordering_penalty ;
      double _average_length_ratio ;
      double _length_mismatch_penalty_base ;
      double _weightof_chunking ;
      double _weightof_lengthbonus ;
      double _weightof_untrans ;
      double _weightof_arcweight ;
      double _weightof_quality ;
      double _weightof_score ;
      double _weightof_future ;
      double _weightof_doccontext ;
      double _weightof_sntcontext ;
      double _weightof_phrcontext ;
      double _weightof_user[9] ;
      double _ngram_length_bonus ;
      size_t _max_ngram_length ;
      size_t _beam_width ;
      double _beam_ratio ;
      size_t _max_source_overlap ;
      size_t _max_reorder_window ;
      size_t _reorder_punct ;
      size_t _reorder_punct_eos ;

   protected:
      void link(class LMGlobalVariables *vars) ;
   public: // methods
      LmGenreSettings(class LMGlobalVariables * = 0, const char *genre = 0) ;
      LmGenreSettings(const LmGenreSettings &,
		      class LMGlobalVariables *, const char *newgenre = 0) ;
      ~LmGenreSettings() ;
      LmGenreSettings &operator = (const LmGenreSettings&) ;

      // accessors
      LmGenreSettings *next() const { return m_next ; }
      const char *name() const { return m_genre ; }
      static LmGenreSettings *find(const char *genre) ;
      const LMGlobalVariables *belongsTo() const { return m_vars ; }
   } ;

#endif /* !__LMGENRE_H_INCLUDED */

// end of file lmgenre.h //
