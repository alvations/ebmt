/************************************************************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmmain.h		Language Modeler main functions		*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,2003,2004,2006,2008,2009	*/
/*			 Ralf Brown					*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMMAIN_H_INCLUDED
#define __LMMAIN_H_INCLUDED

/************************************************************************/
/*	Manifest constants						*/
/************************************************************************/

// number of dispatch requests to permit thread_pool to queue up
#define LmPOOL_QUEUESIZE 500

/************************************************************************/
/************************************************************************/

void LmSetAgreementBonuses(FrList *bonuses) ;

bool load_LM_setup(const char *argv0, const char *filename) ;
bool initialize_LM(const char *argv0, const char *configfile,
		     bool load_model, bool unicode_bswap = false) ;
void identify_LM(ostream &out, bool as_comment = false) ;
void apply_LM_configuration(const class LMConfig *lm_configuration) ;
LmNGramModel **load_LM_ngrams(const FrList *filenames, size_t &num_models) ;
LmNGramModel **load_LM_ngrams(const class LModelConfig *configs,
			      size_t &num_models) ;
FrList *process_sentence_LM(FrTextSpans *lattice, LmNGramModel **ngrams,
			    ParseChart **pc, bool generate_walk = false,
			    bool want_gc = true) ;

bool is_LM_command(const FrObject *obj) ;
int LM_command_args(const FrObject *obj) ;
bool process_LM_command(const FrObject *command, const FrList *args,
			  ostream &out) ;
bool process_LM_command(const FrObject *command, istream &in, ostream &out,
			  ostream &err) ;

char *postprocess_string(const char *) ;

#endif /* !__LMMAIN_H_INCLUDED */

// end of file lmmain.h //
