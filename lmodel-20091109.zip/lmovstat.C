/************************************************************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmovstat.cpp	overlap statistics				*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2003,2005,2006,2007,2008 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmarcs.h"
#include "lmbfs.h"

/************************************************************************/
/*	Global Variables						*/
/************************************************************************/

#define MAX_OVERLAP 255

static size_t total_arcs[MAX_OVERLAP+1] = { 0 } ;
static size_t total_overlaps[MAX_OVERLAP+1] = { 0 } ;
static size_t overlap_counts[MAX_OVERLAP+1] = { 0 } ;
static size_t total_words = 0 ;

/************************************************************************/
/************************************************************************/

static size_t count_all(size_t *counts, bool weight_by_len = false)
{
   size_t total = 0 ;
   if (weight_by_len)
      {
      for (size_t i = 1 ; i <= MAX_OVERLAP ; i++)
	 total += counts[i] * i ;
      }
   else
      {
      for (size_t i = 0 ; i <= MAX_OVERLAP ; i++)
	 total += counts[i] ;
      }
   return total ;
}

//----------------------------------------------------------------------

static size_t highest_nonzero(size_t *counts)
{
   for (size_t i = MAX_OVERLAP ; i > 0 ; i--)
      {
      if (counts[i] != 0)
	 return i ;
      }
   return 0 ;
}

//----------------------------------------------------------------------

static void print_histogram_line(ostream &out, size_t index, size_t count,
				 size_t total)
{
   out << setw(6) << index << '\t' << setw(6) << count << '\t' ;
   size_t bar = (size_t)(60.0 * count / total + 0.5) ;
   bool extra = false ;
   if (bar > 60)
      {
      extra = true ;
      bar = 60 ;
      }
   if (bar == 0 && count > 0)
      out << '.' ;
   else
      {
      for (size_t i = 0 ; i < bar ; i++)
	 out << '*' ;
      }
   if (extra)
      out << '>' ;
   out << endl ;
   return ;
}

/************************************************************************/
/************************************************************************/

void LmUpdateOverlapStatistics(const BFSNode *finalnode)
{
   if (finalnode)
      {
      total_words += finalnode->outputLength() ;
      size_t numovr = finalnode->numArcs() ;
      const ComponentArcInfo *arcs = finalnode->usedArcs() ;
      if (!arcs)
	 numovr = 0 ;
      else if (numovr > MAX_OVERLAP)
	 numovr = MAX_OVERLAP ;
      total_arcs[numovr]++ ;
      size_t ovrcount = 0 ;
      for (size_t i = 1 ; i < numovr ; i++)
	 {
	 int ovr = arcs[i].overlap() ;
	 if (ovr > MAX_OVERLAP)
	    ovr = MAX_OVERLAP ;
	 overlap_counts[ovr]++ ;
	 if (ovr > 0)
	    ovrcount++ ;
	 }
      if (ovrcount > MAX_OVERLAP)
	 ovrcount = MAX_OVERLAP ;
      total_overlaps[ovrcount]++ ;
      }
   return ;
}

//----------------------------------------------------------------------

#undef LmPrintOverlapStatistics
void LmPrintOverlapStatistics(ostream &out)
{
   size_t i ;
   size_t total_sentences = count_all(total_overlaps) ;
   if (total_words > 0 && total_sentences > 0)
      {
      out << "==== Overlap Statistics ====" << endl ;
      out << "By Sentence:\t" << total_sentences - total_overlaps[0] 
	  << " of " << total_sentences << " (" << setprecision(4)
	  << (100.0*(total_sentences-total_overlaps[0]))/total_sentences
	  << "%)" << endl ;
      size_t total_ovrlap = count_all(overlap_counts,true) ;
      out << "By Word:\t" << total_ovrlap << " of " << total_words << " ("
	  << setprecision(4)
	  << (100.0*total_ovrlap)/total_words << "%)" << endl ;
      out << "----------------------------" << endl ;
      out << "Fragments Per Sentence:" << endl ;
      size_t max = highest_nonzero(total_arcs) ;
      for (i = 1 ; i <= max ; i++)
	 print_histogram_line(out,i,total_arcs[i],total_sentences) ;
      out << "----------------------------" << endl ;
      out << "Overlaps Per Sentence:" << endl ;
      max = highest_nonzero(total_overlaps) ;
      for (i = 0 ; i <= max ; i++)
	 print_histogram_line(out,i,total_overlaps[i],total_sentences) ;
      out << "----------------------------" << endl ;
      out << "Words Per Overlap Region:" << endl ;
      max = highest_nonzero(overlap_counts) ;
      for (i = 0 ; i <= max ; i++)
	 print_histogram_line(out,i,overlap_counts[i],
			      total_ovrlap+overlap_counts[0]) ;
      out << "============================" << endl ;
      }
   return ;
}

// end of file lmovstat.cpp //
