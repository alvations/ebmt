/************************************************************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmmain.cpp	    Language Model main program			*/
/*  LastEdit: 04nov09    						*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,	*/
/*		2004,2005,2006,2007,2008,2009 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmodel.h"
#include "frsstrm.h"			// for class strstream
#include "lmngram.h"
#include "lmengine.h"
#include "lmpchart.h"
#include "lmprique.h"
#include "lmmain.h"
#include "lmglobal.h"

#ifdef FrSTRICT_CPLUSPLUS
# include <fstream>
# include <string>
#else
# include <fstream.h>
# include <string.h>
#endif /* FrSTRICT_CPLUSPLUS */

#if defined(__MSDOS__) || defined(__WATCOMC__) || defined(_MSC_VER)
#  include <io.h>
#endif
#if unix
#  include <unistd.h>
#endif /* unix */

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

#define DEFAULT_CFG_FILENAME "lm.cfg"

#ifndef R_OK
#  define R_OK 4
#endif

/************************************************************************/
/*	Forward declarations						*/
/************************************************************************/

static bool process_commands_command(const FrList *, ostream &out) ;

/************************************************************************/
/*	Global variables						*/
/************************************************************************/

static LmNGramModel **active_ngrams = 0 ;
static LmNGramModel **prepdoc_ngrams = 0 ;

/************************************************************************/
/************************************************************************/

static bool load_setup_file(const char *filename)
{
   ifstream in(filename) ;
   if (in.good())
      {
      char *base_directory = FrFileDirectory(filename) ;
      lm_config = make_LMConfig(in,base_directory) ;
      FrFree(base_directory) ;
//	dump_LMConfig(lm_config,cout) ;
      return true ;
      }
   else
      {
      lm_config = 0 ;
      return false ;
      }
}

//------------------------------------------------------------------------

bool load_LM_setup(const char *argv0, const char *filename)
{
   FrMessageLoop() ;
   if (filename && *filename)
      {
      if (load_setup_file(filename))
	 return true ;
      else
	 cerr << "unable to open specified setup file, will use default file" 
	      << endl ;
      }
   // if we get here, either no setup file was specified, or unable to open it
   // so, try to load lm.cfg ffrom the current directory, and finally .lm.cfg
   // from user's home directory, then lm.cfg from the directory containing the
   // executable
   char *filname = FrAddDefaultPath(DEFAULT_CFG_FILENAME,".") ;
   bool success = load_setup_file(filname) ;
   FrFree(filname) ;
   if (success)
      return true ;
   char *homedir = getenv("HOME") ;
   if (homedir && *homedir)
      {
      filname = FrAddDefaultPath("."DEFAULT_CFG_FILENAME,homedir) ;
      if (!filname)
	 FrNoMemory("in get_setup_file") ;
      success = load_setup_file(filname) ;
      FrFree(filname) ;
      if (success)
	 return true ;
      }
   FrMessageLoop() ;
   char *argv0dir = FrFileDirectory(argv0) ;
   filname = FrAddDefaultPath(DEFAULT_CFG_FILENAME,argv0dir) ;
   FrFree(argv0dir) ;
   if (!filname)
      FrNoMemory("in get_setup_file") ;
   load_setup_file(filname) ;
   FrFree(filname) ;
   return false ;
}

//------------------------------------------------------------------------

void find_longest_model(LmNGramModel **models)
{
   size_t longest_model = 0 ;
   for (size_t i = 0 ; models[i] ; i++)
      {
      if (models[i]->maxNgramLength() > longest_model)
	 longest_model = models[i]->maxNgramLength() ;
      }
   if (longest_model < max_ngram_length)
      {
      max_ngram_length = longest_model ;
      LM_reach = max_ngram_length - 1 ;
      if (max_source_overlap > LM_reach)
	 LM_reach = max_source_overlap ;
      }
   return ;
}

//------------------------------------------------------------------------

LmNGramModel **load_LM_ngrams(const FrList *filenames, size_t &num_models)
{
   LM_ngrams = 0 ;
   num_models = filenames->simplelistlength() ;
   if (num_models == 0)
      return 0 ;
   LmNGramModel **models = FrNewC(LmNGramModel*,num_models+1) ;
   if (!models)
      {
      FrNoMemory("while loading language models") ;
      num_models = 0 ;
      return 0 ;
      }
   size_t model_num = 0 ;
   for ( ; filenames ; filenames = filenames->rest())
      {
      const char *filename = FrPrintableName(filenames->first()) ;
      if (filename && *filename)
	 {
	 FrMessageLoop() ;
	 LmNGramModel *ngram = LmNGramModel::newModel(filename,max_ngram_length) ;
	 if (ngram && ngram->OK())
	    {
	    ngram->useJointProb(use_joint_probabilities) ;
	    ngram->modelNumber(model_num) ;
	    models[model_num++] = ngram ;
	    if (verbose)
	       ngram->dump(stdout,filename,trace>=50) ;
	    }
	 else
	    {
	    if (!run_LM_quietly)
	       cerr << "Unable to open model file " << filename << endl ;
	    delete ngram ;
	    }
	 }
      }
   find_longest_model(models) ;
   LmNgramModelWeights(models,num_models,language_model_weights) ;
   num_models = model_num ;
   LM_ngrams = models ;
   return models ;
}

//------------------------------------------------------------------------

LmNGramModel **load_LM_ngrams(const LModelConfig *configs, size_t &num_models)
{
   LM_ngrams = 0 ;
   num_models = 0 ;
   for (const LModelConfig *c = configs ; c ; c = c->next)
      num_models++ ;
   if (num_models == 0)
      return 0 ;
   LmNGramModel **models = FrNewC(LmNGramModel*,num_models+1) ;
   if (!models)
      {
      FrNoMemory("while loading language models") ;
      num_models = 0 ;
      return 0 ;
      }
   size_t model_num = 0 ;
   for ( ; configs ; configs = configs->next)
      {
      if (configs->modelfile && *configs->modelfile)
	 {
	 FrMessageLoop() ;
	 LmNGramModel *ngram = LmNGramModel::newModel(configs) ;
	 if (ngram && ngram->OK())
	    {
	    ngram->useJointProb(use_joint_probabilities) ;
	    ngram->modelNumber(model_num) ;
	    models[model_num++] = ngram ;
	    if (verbose)
	       ngram->dump(stdout,configs->modelfile,trace>=50) ;
	    }
	 else
	    {
	    if (!run_LM_quietly)
	       cerr << "Unable to open model file " << configs->modelfile
		    << endl ;
	    delete ngram ;
	    }
	 }
      }
   find_longest_model(models) ;
   LmNgramModelWeights(models,num_models,language_model_weights) ;
   num_models = model_num ;
   LM_ngrams = models ;
   return models ;
}

//------------------------------------------------------------------------

void apply_LM_configuration(const LMConfig *config)
{
   lm_vars.applyConfiguration(config) ;
   if (config)
      {
      if (char_encoding == FrChEnc_Unicode)
	 cout << "Sorry, 16-bit Unicode not supported at this time" << endl ;
      LmSetAgreementBonuses(config->agreement_bonus) ;
      }
   return ;
}

//----------------------------------------------------------------------

void identify_LM(ostream &out, bool as_comment)
{
   if (as_comment)
      out << "; " ;
   out << "LM v" LM_VERSION_STRING << endl ;
   return ;
}

//----------------------------------------------------------------------

bool initialize_LM(const char *argv0, const char *configfile,
		   bool load_model, bool unicode_bswap)
{
   WordInfo::initVariables() ;
   Unicode_bswap = unicode_bswap ;
   load_LM_setup(argv0, configfile) ;
   apply_LM_configuration(lm_config) ;
   configure_translation_engines(lm_config ? lm_config->engines : 0) ;
   thread_pool = FrCreateGlobalThreadPool(lm_config->maxthreads,
					  LmPOOL_QUEUESIZE) ;
   bool success = true ;
   if (load_model)
      {
      if (lm_config->models &&
	  load_LM_ngrams(lm_config->models,language_model_count) == 0)
	 success = false ;
      else if (!lm_config->models &&
	       load_LM_ngrams(language_model_files,language_model_count) == 0)
	 success = false ;
      }
   if (success)
      TargetWord::setModelCount(language_model_count) ;
   else
      LmSetScaleFactor(0.0) ;		// disable use of language models
   FrMessageLoop() ;
   return success ;
}

//----------------------------------------------------------------------

static bool select_arc(MTEngine *eng, va_list args)
{
   FrVarArg(ChartEntryTypes,type) ;
   FrVarArg(ChartArc*,arc) ;
   if (((1L << eng->engineID()) & type) != 0)
      {
      eng->selectArc(arc->coverage(),arc->arcLength()) ;
      }
   return true ;
}

//----------------------------------------------------------------------

static void update_coverages(const TargetWordList *wordlist)
{
   size_t numwords = wordlist->twlLength() ;
   FrLocalAlloc(ChartArc*,arcs,1024,numwords) ;
   size_t i ;
   for (i = 2 ; i < numwords ; i++)
      arcs[i] = (*wordlist)[i]->sourceArc() ;
   for (i = 2 ; i < numwords ; i++)
      {
      ChartArc *arc = arcs[i] ;
      if (!arc)
	 continue ;
      ChartEntryTypes type = (arc->arcType() & ~(1 << CE_Merged)) ;
      MTEngineList::iterateAll(select_arc,type,arc) ;
      MTEngine::updateGlobalCounts(arc->coverage(),arc->arcLength()) ;
      // remove all other references to the same arc
      for (size_t j = i+1 ; j < numwords ; j++)
	 {
	 if (arcs[j] == arc)
	    arcs[j] = 0 ;
	 }
      }
   FrLocalFree(arcs) ;
   return ;
}

//----------------------------------------------------------------------

static bool is_lm_arc(const FrTextSpan *span, va_list)
{
   FrSymbol *arctype = (FrSymbol*)span->getMetaDataSingle("ENGINE") ;
   if (arctype && arctype->symbolp() &&
       strcmp(arctype->symbolName(),":LM") == 0)
      return true ;
   return false ;
}

//----------------------------------------------------------------------

static int compare_span_text(const FrTextSpan *span1, const FrTextSpan *span2)
{
   const char *text1 = span1->text() ;
   const char *text2 = span2->text() ;
   int cmp ;
   if (text1 && text2)
      cmp = strcmp(text1,text2) ;
   else
      {
      char *text1 = span1->getText() ;
      char *text2 = span2->getText() ;
      if (!text1)
	 cmp = text2 ? +1 : 0 ;
      else if (!text2)
	 cmp = -1 ;
      else // if (text1 && text2)
	 {
	 cmp = strcmp(text1,text2) ;
	 }
      FrFree(text1) ;
      FrFree(text2) ;
      }
   return cmp ;
}

//----------------------------------------------------------------------

static int compare_spans(const FrTextSpan *span1, const FrTextSpan *span2)
{
   int cmp = FrTextSpan::compare(span1,span2) ;
   if (cmp == 0)
      {
      double sc1 = LmSpanQuality(span1) ;
      double sc2 = LmSpanQuality(span2) ;
      if (sc1 == sc2)
	 {
         sc1 = LmSpanAlignmentScore(span1) ;
	 sc2 = LmSpanAlignmentScore(span2) ;
	 if (sc1 == sc2)
	    {
	    sc1 = LmSpanFrequency(span1) ;
	    sc2 = LmSpanFrequency(span2) ;
	    }
	 }
      if (sc1 > sc2)
	 cmp = -1 ;
      else if (sc1 < sc2)
	 cmp = +1 ;
      else
	 // final tie-breaker: the actual text of the span
	 cmp = compare_span_text(span1,span2) ;
      }
   return cmp ;
}

//----------------------------------------------------------------------

static int compare_spans_alt(const FrTextSpan *span1, const FrTextSpan *span2)
{
//FIXME
   int cmp = FrTextSpan::compare(span1,span2) ;
   if (cmp == 0)
      {
      double sc1 = LmSpanQuality(span1) ;
      double sc2 = LmSpanQuality(span2) ;
      if (sc1 == sc2)
	 {
         sc1 = LmSpanAlignmentScore(span1) ;
	 sc2 = LmSpanAlignmentScore(span2) ;
	 if (sc1 == sc2)
	    {
	    sc1 = LmSpanFrequency(span1) ;
	    sc2 = LmSpanFrequency(span2) ;
	    }
	 }
      if (sc1 > sc2)
	 cmp = -1 ;
      else if (sc1 < sc2)
	 cmp = +1 ;
      else
	 // final tie-breaker: the actual text of the span
	 cmp = compare_span_text(span1,span2) ;
      }
   return cmp ;
}

//----------------------------------------------------------------------

FrList *process_sentence_LM(FrTextSpans *lattice, LmNGramModel **ngrams,
			    ParseChart **pc, bool generate_walk,
			    bool want_gc)
{
   if (!ngrams)
      ngrams = LM_ngrams ;
   if (!ngrams || !ngrams[0])		// if we have no valid language models,
      LmSetScaleFactor(0.0) ;		//   disable the use of language models
   LmCaseSensitiveModel(ngrams) ;
   // remove any LM arcs that were given to us
//FramepaC_gc() ;
   if (lattice)
      {
      lattice->removeMatchingSpans(is_lm_arc) ;
//cerr<<"after removeMatching:";FrMemoryStats(cerr);
      if (use_alternate_ranking)
	 lattice->sort(compare_spans_alt) ;
      else
	 lattice->sort(compare_spans) ;
      }
   ParseChart *pchart = new ParseChart(lattice,ngrams) ;
   FrMessageLoop() ;
   if (pchart)
      {
      FrList *best = pchart->bestSentences(best_count,true) ;
      if (verbose)
	 cout << "found chart walk: " << best << endl ;
      if (best && (generate_walk || show_coverage))
	 {
	 FrList *translation = (FrList*)best->first() ;
	 FrObject *score = translation->first() ;
	 TargetWordList *wordlist = (TargetWordList*)translation->third() ;
	 if (wordlist)
	    {
	    if (show_coverage)
	       update_coverages(wordlist) ;
	    if (generate_walk)
	       {
	       FrList *walk = LmCollectChartWalk(wordlist,pchart,ngrams,true) ;
	       FrStruct *meta = new FrStruct(makeSymbol("METADATA")) ;
	       if (meta)
		  {
		  meta->put(makeSymbol("SCORE"),score) ;
		  pushlist(meta,walk) ;
		  }
	       best->freeObject() ;
	       best = listreverse(walk) ;
	       }
	    }
	 else if (generate_walk)
	    {
	    best->freeObject() ;
	    best = 0 ;
	    }
	 }
      if (pc)
	 *pc = pchart ;
      else
	 delete pchart ;
      if (want_gc)
	 FramepaC_gc() ;
      return best ;
      }
   else
      return 0 ;
}
				   
//----------------------------------------------------------------------

char *postprocess_string(const char *str)
{
   if (!prettyprint_output)
      return FrDupString(str) ;
   int len = strlen(str) ;
   char *result = FrNewC(char,len+10) ;
   if (!result)
      return 0 ;
   memcpy(result,str,len+1) ;
   if (len == 0)
      return result ;
   char *t ;
// pass 1: append period if needed
#ifdef ADD_PERIODS
   t = strchr(result,'\0')-1 ;
   while (t > result && strchr(" \t\"'",*t))
      t-- ;
   if (!strchr(".!?",*t))
      strcat(t,".") ;
#endif /* ADD_PERIODS */
// pass 2: capitalize first word
   t = result + strspn(result," \"`\t") ;
   if (*t > 0 && Fr_isalpha(*t))
      {
      const unsigned char *map = FrUppercaseTable(char_encoding) ;
      *t = (char)map[(unsigned char)*t] ;
      }
// pass 3: remove extra whitespace:
//	a) inside quotes and parentheses
//	b) to the left of commas, periods, and quesmarks
//	c) by collapsing sequences of multiple whitespace chars
   t = result ;
   char *dest = result ;
   bool inside = false ;
   while (*t)
      {
      if (Fr_isspace(*t))
	 {
	 // collapse sequences of blanks by only copying the first, and
	 //   remove extra whitespace following an open paren or opening double
	 //   quote by not copying it
	 if (dest != result && (Fr_isspace(dest[-1]) || dest[-1] == '(' ||
				(inside && dest[-1] == '"')))
	    t++ ;
	 else
	    *dest++ = *t++ ;
	 }
      else if (*t == '"')
	 {
	 if (inside && dest != result && Fr_isspace(dest[-1]))
	    dest[-1] = *t++ ;
	 else
	    *dest++ = *t++ ;
	 inside = !inside ;
	 }
      else if (strchr(".,?!)",*t) != 0 && dest != result && 
	       Fr_isspace(dest[-1]))
	 {
	 dest[-1] = *t++ ;
	 }
      else
	 *dest++ = *t++ ;
      }
   *dest = '\0' ;			// properly terminate the string
// pass 4: change single_quote into '
#if 0
   inside = false ;
   t = result ;
   while ((t = strstr(t,TOKEN_SQUOTE)) != 0)
      {
      if ((t == result || Fr_isspace(t[-1])) &&
	  Fr_isspace(t[sizeof(TOKEN_SQUOTE)-1]))
         {
	 if (inside)
            {
	    t[-1] = '\'' ;
            strcpy(t,t+sizeof(TOKEN_SQUOTE)-1) ;
	    }
	 else
	    {
            *t = '`' ;
            strcpy(t+1,t+sizeof(TOKEN_SQUOTE)) ;
	    }
	 inside = !inside ;
         }
      else
	 t++ ;
      }
#endif
// pass 6: remove accented characters
   if (remove_accents)
      for (t = result ; *t ; t++)
	 *t = Fr_unaccent(*t) ;
// pass 7: ???

   return result ;
}

/************************************************************************/
/************************************************************************/

static bool process_ngram_command(const FrList *args, ostream &out)
{
   const FrObject *arg = args->first() ;
   if (!arg || !LM_ngrams)
      return false ;
   const char *string = arg->printableName() ;
   FrList *words = char_based_model ? LmWord2Chars(string)
      				    : FrCvtString2Wordlist(string,0,0,
							   char_encoding) ;
   if (words)
      {
      size_t numwords = words->simplelistlength() ;
      FrLocalAlloc(LmWordID_t,IDs,1024,numwords+1) ;
      if (!IDs)
	 return false ;
      double total_weight = 0.0 ;
      double total_prob = 0.0 ;
      for (size_t m = 0 ; LM_ngrams && LM_ngrams[m] ; m++)
	 {
	 LmNGramModel *model = LM_ngrams[m] ;
	 double weight = model->weight() ;
	 total_weight += weight ;
	 bool logspace = model->usingLogSpace() ;
	 size_t max_ngram = model->maxNgramLength() ;
	 double scalefac = LmSetScaleFactor(1.0) ;
	 model->useLogSpace(false) ;
	 model->maxNgramLength(999) ;
	 FrList *wds = words ;
	 const char *last_word = 0 ;
	 for (size_t i = 0 ; i < numwords ; i++, wds = wds->rest())
	    {
	    FrString *word = (FrString*)wds->first() ;
	    last_word = word->stringValue() ;
	    IDs[i] = model->findWordID(word ? word->stringValue() : " ") ;
	    if (!run_LM_quietly)
	       {
	       out << "unigram prob for " << word << " (ID "
		   << IDs[i] << ") = " << model->probability(IDs+i,1) << endl;
	       }
	    }
	 double prob = model->probability(IDs,numwords,0,last_word) ;
	 if (language_model_count > 1 && !run_LM_quietly)
	    {
	    out << "individual ngram prob for model " << model->name()
		<< " = " << prob << endl ;
	    }
	 total_prob += weight * prob ;
	 model->useLogSpace(logspace) ;
	 model->maxNgramLength(max_ngram) ;
	 (void)LmSetScaleFactor(scalefac) ;
	 }
      free_object(words) ;
      if (total_weight > 0.0)
	 total_prob /= total_weight ;
      out << numwords << "-gram prob = " << total_prob << endl ;
      FrLocalFree(IDs) ;
      }
   return true ;
}

//----------------------------------------------------------------------

static bool process_prepdoc_command(const FrList *, ostream &out)
{
   bool status = LmPrepareDocument(true) ;
   if (!status)
      out << "\"Error: Already preparing document\"" << endl ;
   return status ;
}

//----------------------------------------------------------------------

static bool process_endprep_command(const FrList *, ostream &out)
{
   bool status = LmPrepareDocument(false) ;
   if (!status)
      out << "\"Error: Not preparing document\"" << endl ;
   return status ;
}

//----------------------------------------------------------------------

static bool process_showmodels_command(const FrList *, ostream &out)
{
   cout << endl ;
   for (size_t i = 0 ; active_ngrams[i] ; i++)
      {
      active_ngrams[i]->dumpConfig(cout) ;
      cout << endl ;
      }
   return true ;
}

//----------------------------------------------------------------------

static bool process_freq_command(const FrList *args, ostream &out)
{
   const FrObject *arg = args->first() ;
   if (!arg || !LM_ngrams)
      return false ;
   const char *string = arg->printableName() ;
   FrList *words = FrCvtString2Wordlist(string,0,0,char_encoding) ;
   if (words)
      {
      size_t numwords = words->simplelistlength() ;
      FrLocalAlloc(LmWordID_t,IDs,1024,numwords+1) ;
      if (!IDs)
	 return false ;
      for (size_t m = 0 ; LM_ngrams && LM_ngrams[m] ; m++)
	 {
	 LmNGramModel *model = LM_ngrams[m] ;
	 out << "frequencies from model " << model->name() << ":" << endl ;
	 size_t max_ngram = model->maxNgramLength() ;
	 model->maxNgramLength(999) ;
	 FrList *wds = words ;
	 for (size_t i = 0 ; i < numwords ; i++, wds = wds->rest())
	    {
	    FrString *word = (FrString*)wds->first() ;
	    IDs[i] = model->findWordID(word ? word->stringValue() : " ") ;
	    if (!run_LM_quietly || i >= max_ngram)
	       {
	       out << "frequency of  " ;
	       size_t first = 0 ;
	       if (i >= max_ngram)
		  first = i - max_ngram + 1 ;
	       for (size_t j = first ; j <= i ; j++)
		  out << words->getNth(j) << ' ' ;
	       out << " ==> " << model->frequency(IDs+first,i-first+1) << endl;
	       }
	    }
	 model->maxNgramLength(max_ngram) ;
	 }
      free_object(words) ;
      FrLocalFree(IDs) ;
      }
   return true ;
}

//----------------------------------------------------------------------

static bool process_help_command(const FrList *, ostream &out)
{
   out << "Type COMMANDS to list the available commands or PARAMS to list\n"
       << "the available program settings.  Most commands accept a question\n"
       << "mark as an option to list their usage summary.\n"
       << endl ;
   return true ;
}

//----------------------------------------------------------------------

static bool select_genre(const char *genre_name)
{
   bool success = false ;
   if (genre_name && *genre_name)
      {
      LmGenreSettings *genre = LmGenreSettings::find(genre_name);
      if (genre)
	 {
	 lm_vars.previous_genre = lm_vars.genre ;
	 lm_vars.genre = genre ;
	 // update genre-specific settings in LM that aren't directly accessed
	 //   from the global-variables 'genre' structure
	 // (!!!none at this time)
	 success = true ;
	 }
      }
   return success ;
}

//----------------------------------------------------------------------

static bool process_genre_command(const FrList *args, ostream &out)
{
   FrObject *genreID = args->first() ;
   const char *genre_name = ((genreID && genreID->printableName())
			     ? genreID->printableName() : 0) ;
   bool success = select_genre(genre_name) ;
   if (success)
      out << "\"Genre selected\"" << endl ;
   else
      {
      // we need to make sure that the echoed ID is all on one line, so
      //   convert it to a string first
      char *genre = genreID->print() ;
      out << "Unable to select genre " << genre << endl ;
      FrFree(genre) ;
      }
   return success ;
}

//----------------------------------------------------------------------

static bool process_listparms_command(const FrList *, ostream &out)
{
   if (!lm_config)
      out << "Unable to list parameters -- no configuration loaded" << endl ;
   else
      {
      FrList *params = lm_config->listParameters() ;
      out << params << endl << endl ;;
      free_object(params) ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

static bool process_describe_command(const FrList *args, ostream &out)
{
   if (!lm_config)
      {
      out << "Unable to describe parameters -- no configuration loaded"
	  << endl ;
      return false ;
      }
   FrObject *obj = args->first();
   if (obj && obj != makeSymbol("?") && obj->printableName())
      {
      const char *param = obj->printableName() ;
      FrList *description =  lm_config->describeParameter(param) ;
      out << description << endl << endl ;
      free_object(description) ;
      return true ;
      }
   out << "Usage: DESCRIBE \"parameter\"\n" << endl ;
   return false ;
}

//----------------------------------------------------------------------

static bool process_show_command(const FrList *args, ostream &out)
{
   if (!lm_config)
      {
      out << "Unable to show parameters -- no configuration loaded\n"
	  << endl ;
      return false ;
      }
   FrObject *obj = args->first() ;
   if (obj && obj != makeSymbol("?") && obj->printableName())
      {
      char *value = lm_config->currentValue(obj->printableName()) ;
      bool success = false ;
      if (value)
	 {
	 out << "( " << obj->printableName() << " = " << value << " )\n"
	     << endl;
	 success = true ;
	 }
      else
	 out << "( unknown parameter )\n" << endl ;
      FrFree(value) ;
      return success ;
      }
   else
      out << "Usage: SHOW \"parameter\"\n" << endl ;
   return false ;
}

//----------------------------------------------------------------------

static bool process_set_command(const FrList *args, ostream &out)
{
   if (!lm_config)
      {
      out << "Unable to show parameters -- no configuration loaded"
	  << endl ;
      return false ;
      }
   FrObject *obj = args->first() ;
   if (obj && obj != makeSymbol("?") && obj->printableName())
      {
      const char *param_name = obj->printableName() ;
      FrObject *obj2 = args->second() ;
      if (obj2 && obj2->printableName())
	 {
	 if (lm_config->setParameter(param_name,obj2->printableName(),&out))
	    {
	    char *value = lm_config->currentValue(param_name) ;
	    out << "( " << param_name << " <= " << value << " )" << endl  ;
	    FrFree(value) ;
	    return true ;
	    }
	 else
	    out << "( error )" << endl ;
	 return false ;
	 }
      }
   out << "Usage: SET \"parameter\" \"new-value\"\n" << endl ;
   return false ;
}

/************************************************************************/
/************************************************************************/

typedef bool LmCommandFunc(const FrList *args, ostream &out) ;

struct LM_command
   {
   const char *name ;
   size_t num_args ;
   LmCommandFunc *fn ;
   } ;

static LM_command LM_commands[] =
   {
      { "COMMANDS",	0,	process_commands_command },
      { "DESCRIBE",	1,	process_describe_command },
      { "ENDPREP",	0,	process_endprep_command },
      { "FREQ",		1,	process_freq_command },
      { "GENRE",	1,	process_genre_command },
      { "HELP",		0,	process_help_command },
      { "LISTPARAMS",	0,	process_listparms_command },
      { "LISTPARMS", 	0,	process_listparms_command },
      { "NGRAM",	1,	process_ngram_command },
      { "PARAMS", 	0,	process_listparms_command },
      { "PREPDOC",	0,	process_prepdoc_command },
      { "SET",		2,	process_set_command },
      { "SHOW",		1,	process_show_command },
      { "SHOWMODELS",	0,	process_showmodels_command },
      { "?",		0,	process_help_command },
      { 0, 		0,	0 },
   } ;

//----------------------------------------------------------------------

static bool process_commands_command(const FrList *, ostream &out)
{
   out << "The valid commands mode are:\n" ;
   size_t i ;
   for (i = 0 ; LM_commands[i].name ; i++)
      out << ' ' << LM_commands[i].name ;
   out << endl << endl ;
   return true ;
}

//----------------------------------------------------------------------

bool is_LM_command(const FrObject *obj)
{
   if (!obj || !obj->printableName())
      return false ;
   const char *command = obj->printableName() ;
   // check whether the symbol is one of the commands we know about
   for (size_t i = 0 ; i < lengthof(LM_commands) ; i++)
      {
      if (LM_commands[i].name && Fr_stricmp(command,LM_commands[i].name) == 0)
	 return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

int LM_command_args(const FrObject *obj)
{
   if (!obj || !obj->printableName())
      return -1 ;
   const char *command = obj->printableName() ;
   // check whether the symbol is one of the commands we know about
   for (size_t i = 0 ; i < lengthof(LM_commands) ; i++)
      {
      if (Fr_stricmp(command,LM_commands[i].name) == 0)
	 return LM_commands[i].num_args ;
      }
   return -1 ;
}

//----------------------------------------------------------------------

bool process_LM_command(const FrObject *command, const FrList *args,
			ostream &out)
{
   if (!command)
      return true ;			// trivially successful
   LMConfig::startupComplete() ;	// switch from STARTUP to RUNTIME vars
   const char *cmd = command->printableName() ;
   // check whether the symbol is one of the commands we know about
   for (size_t i = 0 ; i < lengthof(LM_commands) ; i++)
      {
      if (Fr_stricmp(cmd,LM_commands[i].name) == 0)
	 {
	 if (LM_commands[i].fn)
	    return LM_commands[i].fn(args,out) ;
	 else
	    return false ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

bool process_LM_command(const FrObject *command, istream &in, ostream &out,
			ostream &err) 
{
   if (command && command->printableName())
      {
      int num_args = LM_command_args(command) ;
      if (num_args < 0)
	 {
	 err << "Unknown command " << command << endl ;
	 return false ;
	 }
      FrList *args = 0 ;
      for (int i = 1 ; i <= num_args ; i++)
	 {
	 FrObject *arg ;
	 in >> arg ;
	 pushlist(arg,args) ;
	 }
      args = listreverse(args) ;
      bool status = process_LM_command(command,args,out) ;
      free_object(args) ;
      return status ;
      }
   return false ;
}

//----------------------------------------------------------------------

void LmActiveNGrams(LmNGramModel **ngrams)
{
   active_ngrams = ngrams ;
   return ;
}

//----------------------------------------------------------------------

bool LmPrepareDocument(bool starting)
{
   if (starting == preparing_for_document)
      return false ;
   if (starting)
      {
      prepdoc_ngrams = active_ngrams ;
      if (prepdoc_ngrams)
	 {
	 for (size_t i = 0 ; prepdoc_ngrams[i] ; i++)
	    {
	    prepdoc_ngrams[i]->accumulateCoverBegin() ;
	    }
	 preparing_for_document = true ;
	 return true ;
	 }
      }
   else if (prepdoc_ngrams)
      {
      double total_cover = 0.0 ;
      size_t total_models = 0 ;
      for (size_t i = 0 ; prepdoc_ngrams[i] ; i++)
	 {
	 double cover = prepdoc_ngrams[i]->accumulatedCoverage() ;
	 if (cover != 0.0)
	    {
	    total_cover += cover ;
	    total_models++ ;
	    }
	 }
      for (size_t i = 0 ; prepdoc_ngrams[i] ; i++)
	 {
	 (void)prepdoc_ngrams[i]->accumulateCoverDone(total_cover,
						      total_models) ;
	 }
      prepdoc_ngrams = 0 ;
      preparing_for_document = false ;
      return true ;
      }
   prepdoc_ngrams = 0 ;
   preparing_for_document = false ;
   return false ;
}

//----------------------------------------------------------------------

void LmAccumulateSourceCoverage(LmNGramModel **ngrams, const FrList *words)
{
   if (!ngrams)
      ngrams = prepdoc_ngrams ;
   if (ngrams && words)
      {
      for (size_t i = 0 ; ngrams[i] ; i++)
	 {
	 (void)ngrams[i]->accumulateCover(words) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

static bool show_stats(MTEngine *eng, va_list args)
{
   eng->showStats(stdout) ;
   return true ;
}

//----------------------------------------------------------------------

void LMShowCoverage()
{
   if (show_coverage)
      {
      printf("\n\t\tPer-Engine Statistics\n") ;
      MTEngine::showStatsHeader(stdout) ;
      MTEngineList::iterateAll(show_stats) ;
      MTEngine::showStatsFooter(stdout) ;
      show_coverage = false ;		// prevent multiple print-outs
      }
   return ;
}

//----------------------------------------------------------------------

void LmPrintSearchStatistics(ostream &out)
{
   if (stats__total_nodes_expanded > 0 || stats__total_ngram_probs > 0)
      {
      out << endl ;
      out << "Search Statistics" << endl ;
      out << "=================" << endl ;
      out << "Nodes expanded:\t\t"
	  << setw(10) << stats__total_nodes_expanded << endl ;
      out << "Attempted expansions:\t"
	  << setw(10) << stats__attempted_node_expansions << endl;
      out << "Expansion collisions:\t"
	  << setw(10) << stats__expansion_collisions << endl ;
      out << "Unable to complete:\t"
	  << setw(10) << stats__unable_to_cover << endl ;
      out << "Unfillable gaps:\t"
	  << setw(10) << stats__unfillable_gaps << endl ;
      out << "Successful expansions:\t"
	  << setw(10) << stats__successful_expansions << endl ;
      out << "  with overlap:\t\t"
	  << setw(10) << stats__overlap_expansions << endl ;
      out << "  with interleaving:\t"
	  << setw(10) << stats__interleaved_expansions
	  << " (" << stats__interleaves_used << " used in output)" << endl ;
      out << "  with reordering:\t"
	  << setw(10) << stats__reordered_expansions
	  << " (" << stats__reorderings_used << " used in output)" << endl ;
      out << "Duplicates removed:\t"
	  << setw(10) << stats__dups_removed << endl ;
      out << "Beam-Exceeded removals:\t"
	  << setw(10) << stats__beam_exceeded << endl ;
      out << "Nodes never inserted:\t"
	  << setw(10) << stats__never_inserted << endl ;
      out << "N-grams looked up:\t"
	  << setw(10) << stats__total_ngram_probs << endl ;
      out << "  Avg N-gram in training: "
	  << setw(8) << stats__total_avg_ngram / (double)stats__total_ngram_probs << endl ;
      }
   return ;
}

//----------------------------------------------------------------------

void shutdown_LM()
{
   if (thread_pool && LM_trace >= 5) thread_pool->collisionStatistics() ;
   for (size_t i = 0 ; LM_ngrams && LM_ngrams[i] ; i++)
      delete LM_ngrams[i] ;
   FrFree(LM_ngrams) ;
   FrFreeNamedEntitySpec(named_entity_spec) ;
   LM_ngrams = 0 ;
   free_object(LM_genre_names) ;	LM_genre_names = 0 ;
   LmUnloadWordStems() ;
   LMShowCoverage() ;
   if (show_overlap_stats)
      LmPrintOverlapStatistics(cout) ;
   if (show_search_stats)
      LmPrintSearchStatistics(cout) ;
   TargetWord::freeIDAllocator() ;
   ChartArc::freeArcTypes() ;
   free_translation_engines() ;
   delete lm_config ;
   lm_config = 0 ;
   lm_vars.freeVariables() ;
   return ;
}

//----------------------------------------------------------------------

bool LmInputAlreadyCanonical(bool canon)
{
   bool old_canon = canonicalized_input_data ;
   canonicalized_input_data = canon ;
   return old_canon ;
}


/************************************************************************/
/*	Methods for class LanguageModeler				*/
/************************************************************************/

LanguageModeler::LanguageModeler(const char *argv0, const char *configfile,
				 bool load_model, bool unicode_bswap)
{
   vars = new LMGlobalVariables() ;
   if (vars)
      {
      LMGlobalVariables *origvars = vars->select() ;
      lm_vars.applyConfiguration(0) ;
      if (initialize_LM(argv0,configfile,load_model,unicode_bswap))
	 {
	 m_models = LM_ngrams ;
	 }
      else
	 m_models = 0 ;
      origvars->select() ;
      }
   return ;
}

//----------------------------------------------------------------------

LanguageModeler::~LanguageModeler()
{
   for (size_t i = 0 ; m_models && m_models[i] ; i++)
      delete m_models[i] ;
   FrFree(m_models) ;
   m_models = 0 ;
   delete lm_config ;
   lm_config = 0 ;
   delete vars ;
   vars = 0 ;
   return ;
}

//----------------------------------------------------------------------

FrList *LanguageModeler::process(FrTextSpans *lattice, bool generate_walk,
				 ParseChart **pc, bool want_gc)
{
   LMGlobalVariables *origvars = vars->select() ;
   LmActiveNGrams(m_models) ;
   FrList *result = process_sentence_LM(lattice,m_models,pc,generate_walk,
					want_gc) ;
   LmActiveNGrams(0) ;
   origvars->select() ;
   return result ;
}

//----------------------------------------------------------------------

bool LanguageModeler::prepareForDocument(bool starting)
{
   LmActiveNGrams(m_models) ;
   bool success = LmPrepareDocument(starting) ;
   LmActiveNGrams(0) ;
   return success ;
}

//----------------------------------------------------------------------

void LanguageModeler::prepareDoc(const FrTextSpans *lattice)
{
   LMGlobalVariables *origvars = vars->select() ;
   if (preparing_for_document && prepdoc_ngrams)
      {
      FrList *words = lattice->wordList() ;
      LmAccumulateSourceCoverage(prepdoc_ngrams,words) ;
      free_object(words) ;
      }
   origvars->select() ;
   return ;
}

//----------------------------------------------------------------------

void LanguageModeler::identify(ostream &out, bool as_comment)
{
   LMGlobalVariables *origvars = vars->select() ;
   identify_LM(out,as_comment) ;
   origvars->select() ;
   return ;
}

//----------------------------------------------------------------------

char *LanguageModeler::postprocess(const char *string)
{
   LMGlobalVariables *origvars = vars->select() ;
   char *processed = postprocess_string(string) ;
   origvars->select() ;
   return processed ;
}

//----------------------------------------------------------------------

bool LanguageModeler::selectGenre(const char *genre_name)
{
   return select_genre(genre_name) ;
}

//----------------------------------------------------------------------

char *LanguageModeler::privateCommand(const char *command)
{
   if (command && *command)
      {
      strstream input ;
      input << command << '\0' ;
      strstream output ;
      FrObject *cmd ;
      input >> cmd ;
      (void)process_LM_command(cmd,input,output,output) ;
      free_object(cmd) ;
      output << '\0' ;			// ensure proper string termination
      char *res = output.str() ;
      char *result = FrDupString(res) ;
      free(res) ;
      return result ;
      }
   return 0 ;
}

//----------------------------------------------------------------------

bool LanguageModeler::good() const
{
   return vars != 0 && m_models != 0 && m_models[0] != 0 ;
}

/************************************************************************/
/************************************************************************/

// end of file lmmain.cpp //
