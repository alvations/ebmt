/************************************************************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmtreap.cpp		treap (heap-structure trees) functions	*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,2002,2003,2004,2005,2006,	*/
/*		2007,2008,2009 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmbfs.h"
#include "lmglobal.h"

/************************************************************************/
/*	Helper Functions						*/
/************************************************************************/

// SEE ALSO: BFSNode::compareNode()

bool no_worse_node(const BFSNode *node1, const BFSNode *node2)
{
   // say true if node1 has a better score than node2
   if (node1->score() > node2->score())
      return true ;
   // also say true if node1 has the same score but is otherwise at
   //   least as good as node2: better overlap bonus, fewer arcs, fewer
   //   OOVs, fewer gap markers, less reordering, less interleaving,
   //   better ngram-fraction
   if (node1->score() < node2->score())
      return false ;
   if (node1->overlapBonus() > node2->overlapBonus())
      return true ;
   else if (node1->overlapBonus() < node2->overlapBonus())
      return false ;
   if (node1->numArcs() < node2->numArcs())
      return true ;
   else if (node1->numArcs() > node2->numArcs())
      return false ;
   if (node1->numOOVs() < node2->numOOVs())
      return true ;
   else if (node1->numOOVs() > node2->numOOVs())
      return false ;
   if (node1->gapMarkers() < node2->gapMarkers())
      return true ;
   else if (node1->gapMarkers() > node2->gapMarkers())
      return false ;
   if (reordering_penalty)
      {
      if (node1->arcReorderings() < node2->arcReorderings())
	 return true ;
      else if (node1->arcReorderings() > node2->arcReorderings())
	 return false ;
      }
   size_t inter1 = node1->gapsFilled() + node1->gapsDiscarded() ;
   size_t inter2 = node2->gapsFilled() + node2->gapsDiscarded() ;
   if (inter1 < inter2)
      return true ;
   else 
      return false ;
   if (node1->ngramFraction() >= node2->ngramFraction())
      return true ;
   else //if (node1->ngramFraction() < node2->ngramFraction())
      return false ;
}

/************************************************************************/
/*	Treap manipulation functions					*/
/************************************************************************/

BFSNode *LmTreapInsert(BFSNode *&root, BFSNode *node)
{
   // descend down the tree, keeping track of the path we took, which will
   //   be needed to perform the rotations on the way back up after the
   //   insertion
   BFSNode *path[256] ;
   size_t   pathlen = 0 ;
   BFSNode **parent = &root ;
   BFSNode *curr = root ;
   while (curr && pathlen < lengthof(path))
      {
      int cmp = node->compareNode(curr) ;
      if (cmp < 0)
	 {
	 path[pathlen++] = curr ;
	 parent = curr->leftPtr() ;
	 curr = curr->left() ;
	 }
      else if (cmp > 0)
	 {
	 path[pathlen++] = curr ;
	 parent = curr->rightPtr() ;
	 curr = curr->right() ;
	 }
      else // cmp == 0
	 {
	 // compare the score of the node that's already in the tree against
	 //   the new node's score
	 if (no_worse_node(curr,node))
	    return node ;		// new node is lower-scoring duplicate
	 *parent = node ;
	 node->setLeft(curr->left()) ;  // move current node's children into
	 node->setRight(curr->right()) ; // new node
	 // since the new node has a higher heap value than the one it 
	 //   replaced, it may violate the heap property, so keep swapping
	 //   it with the smaller of its children until the heap property
	 //   is restored 
	 for ( ; ; )
	    {
	    if (!node->left() ||
		(node->right() && no_worse_node(node->left(),node->right())))
	       {
	       if (!node->right() || no_worse_node(node->right(),node))
		  break ;		// we're done
	       else
		  {
		  // swap node with its right child and move down a level
		  BFSNode *child = node->right() ;
		  *parent = child ;
		  parent = child->rightPtr() ;
		  BFSNode *node_left = node->left() ;
		  node->setLeft(child->left()) ;
		  node->setRight(child->right()) ;
		  child->setLeft(node_left) ;
		  child->setRight(node) ;
		  }
	       }
	    else if (!node->left() || no_worse_node(node->left(),node))
	       break ;			// we're done
	    else
	       {
	       // swap node with its left child and move down a level
	       BFSNode *child = node->left() ;
	       *parent = child ;
	       parent = child->leftPtr() ;
	       BFSNode *node_right = node->right() ;
	       node->setLeft(child->left()) ;
	       node->setRight(child->right()) ;
	       child->setLeft(node) ;
	       child->setRight(node_right) ;
	       }
	    }
	 return curr ;			// old node has been removed from tree
	 }
      }
   if (pathlen >= lengthof(path))
      {
      // uh oh, we're so unbalanced that we ran out of our local stack, so
      //   just pretend the new node was a duplicate and try to carry on
      return node ;
      }
   // insert the new node, which may cause a violation of the heap property
   *parent = node ;
   node->setLeft(0) ;
   node->setRight(0) ;
   // work back up the tree as long as the current node violates the
   //   heap property, and perform rotations to locally restore the heap
   while (pathlen > 0 && !no_worse_node(node,path[pathlen-1]))
      {
      BFSNode *ancestor = path[pathlen-1] ;
      if (ancestor->left() == node)
	 {
	 // rotate right
	 ancestor->setLeft(node->right()) ;
	 node->setRight(ancestor) ;
	 }
      else // ancestor->right() == node
	 {
	 // rotate left
	 ancestor->setRight(node->left()) ;
	 node->setLeft(ancestor) ;
	 }
      // adjust the parent's child pointer to point at the new root of
      //   the sub-treap
      if (pathlen > 1)
	 {
	 if (path[pathlen-2]->left() == ancestor)
	    path[pathlen-2]->setLeft(node) ;
	 else
	    path[pathlen-2]->setRight(node) ;
	 }
      else
	 root = node ;
      --pathlen ;		   	// back up to tne next-higher level
      }
   return 0 ;				// node has been inserted
}

//----------------------------------------------------------------------

BFSNode *LmTreapFromList(BFSNode *nodelist)
{
   BFSNode *root = 0 ;
   BFSNode *next ;
   for (BFSNode *nl = nodelist ; nl ; nl = next)
      {
      next = nl->next() ;
      BFSNode *duplicate = LmTreapInsert(root,nl) ;
      if (duplicate)
	 delete duplicate ;
      }
   return root ;
}

//----------------------------------------------------------------------

BFSNode *LmTreapJoin(BFSNode *left, BFSNode *right)
{
   if (!left)
      return right ;
   else if (!right)
      return left ;
   else if (no_worse_node(left,right))
      {
      // right subtree's root becomes root of joined Treap
      right->setLeft(LmTreapJoin(left,right->left())) ;
      return right ;
      }
   else
      {
      // left subtree's root becomes root of joined Treap
      left->setRight(LmTreapJoin(left->right(),right)) ;
      return left ;
      }
}

//----------------------------------------------------------------------

bool LmTreapRemove(BFSNode *&root, BFSNode *node)
{
   BFSNode **parent = &root ;
   BFSNode *curr = root ;
   // descend down the binary search tree looking for the node
   while (curr && curr != node)
      {
      int cmp = node->compareNode(curr) ;
      if (cmp < 0)
	 {
	 parent = curr->leftPtr() ;
	 curr = curr->left() ;
	 }
      else if (cmp > 0)
	 {
	 parent = curr->rightPtr() ;
	 curr = curr->right() ;
	 }
      else
	 {
	 // can't happen!
	 FrWarning("duplicate node in tree!") ;
	 return false ;
	 }
      }
   // now replace the found node with the join of its two children
   if (curr)
      *parent = LmTreapJoin(curr->left(),curr->right()) ;
   return true ;
}

//----------------------------------------------------------------------

BFSNode *LmTreapPopMin(BFSNode *&root)
{
   BFSNode *min_node = root ;
   if (root)
      root = LmTreapJoin(root->left(),root->right()) ;
   return min_node ;
}

//----------------------------------------------------------------------

BFSNode *LmTreapToList(BFSNode *root)
{
   BFSNode *result = 0 ;
   while (root)
      {
      BFSNode *node = root ;
      // pop the lowest-scoring node off the Treap
      root = LmTreapJoin(root->left(),root->right()) ;
      // add it to the list; since this reverses the order of elements,
      //   we get the desired order from highest- to lowest-scoring
      node->setNext(result) ;
      result = node ;
      }
   return result ;
}

//----------------------------------------------------------------------

void LmTreapDelete(BFSNode *root)
{
   if (root)
      {
      LmTreapDelete(root->left()) ;
      LmTreapDelete(root->right()) ;
      delete root ;
      }
   return ;
}

// end of file lmtreap.cpp //
