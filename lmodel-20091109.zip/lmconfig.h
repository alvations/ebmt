/****************************** -*- C++ -*- *****************************/
/*									*/
/*  English Language Model -- configuration file parser			*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmconfig.h							*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2001,2002,2003	*/
/*		2004,2005,2006,2007,2008,2009 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMCONFIG_H_INCLUDED
#define __LMCONFIG_H_INCLUDED

#include "FramepaC.h"
#include "lmgenre.h"

#ifdef FrSTRICT_CPLUSPLUS
# include <cstdio>
# include <cstdlib>
#else
# include <stdio.h>
# include <stdlib.h>
#endif /* FrSTRICT_CPLUSPLUS */

/************************************************************************/
/*	Manifest Constants						*/
/************************************************************************/

#define ENGINE_IGNORE_ARCS	 0x0001
#define ENGINE_FULLSENT_ONLY	 0x0002

/************************************************************************/
/*	Types								*/
/************************************************************************/

struct MTEngineConfig : public FrConfiguration
   {
   private:
      static FrConfigurationTable engine_def[] ;
   public:
      MTEngineConfig *next ;
      FrSymbol 	*tag ;
      char    	*name ;
      FrList 	*length_bonuses ;
      FrList 	*overrides ;
      FrList 	*total_overrides ;
      long int 	options ;
      long int 	max_alts ;
      long int 	max_alts1 ;
      double 	weight ;
      double 	untrans_penalty ;
      double 	threshold ;
      int 	last_local_var ;	// must follow all other data members
   public:
      MTEngineConfig()
         { init() ; }
      MTEngineConfig(const MTEngineConfig &eng) ;
      ~MTEngineConfig() ;
      virtual void init() ;
//      virtual void initUserType(FrConfigVariableType type, void *location) ;
      virtual void resetState() ;
      virtual size_t maxUserType() const ;
      virtual size_t lastLocalVar() const ;
      virtual bool onChange(FrConfigVariableType, void *where) ;
      virtual ostream &dump(ostream &out) const ;
   } ;

//-----------------------------------------------------------------------

struct LModelConfig : public FrConfiguration
   {
   private:
      static FrConfigurationTable model_def[] ;
   public:
      LModelConfig *next ;
      char *name ;			// section name, for dumping config
      char *modelfile ;			// name of file containing model
      char *sourcemodel ;		// name of associated source-lang model
      FrSymbol *smoothing_name ;
      double weight ;
      double context_weight ;
      double discount ;			// discount mass, for .bwt models
      long max_ngram ;
      int last_local_var ;		// must follow all other data members
   public: // methods
      LModelConfig(const char *base_directory, const char *model) ;
      virtual ~LModelConfig() ;
      virtual void init() ;
      virtual void resetState() ;
      virtual size_t maxUserType() const ;
      virtual size_t lastLocalVar() const ;
      virtual bool onChange(FrConfigVariableType, void *where) ;
      virtual ostream &dump(ostream &out) const ;
   } ;

//-----------------------------------------------------------------------

class LMConfig : public FrConfiguration
   {
   public:
      LmGenreSettings dummy_genre ;	// ensure no overlap in offsets
      char *char_enc ;			//   between genre and local settings
      char *dummy_arc ;
      char *ne_spec ;
      FrList *agreement_bonus ;
      LModelConfig *models ;
      MTEngineConfig *engines ;
      long int options ;
      long int score_options ;
      long int output_options ;
      long int maxthreads ;
      LmGenreSettings genre ;
      int last_local_var ;		// must follow all other data members
   private:
      bool engine(const char *line, void *storage_location, void *extra) ;
      bool fix_engine(const char *line, void *storage_location, void *extra) ;
      static FrConfigurationTable LM_def[] ;
   public: // methods
      LMConfig(const char *base_directory) : FrConfiguration(base_directory){} 
      virtual ~LMConfig() ;
      virtual void init() ;
//      virtual void initUserType(FrConfigVariableType type, void *location) ;
      virtual void resetState() ;
      virtual ostream &dump(ostream &out) const ;
//      virtual bool parseUser(FrConfigVariableType type, const char *line,
//			       void *storage_location, void *extra) ;
      virtual size_t maxUserType() const ;
      virtual size_t lastLocalVar() const ;
      virtual bool onRead(FrConfigVariableType, void *where) ;
      virtual bool onChange(FrConfigVariableType, void *where) ;

      const char *baseDirectory() const { return base_dir ; }
   } ;

//-----------------------------------------------------------------------

// flags for Options:
#define LM_RUN_QUIETLY		 0x0001
#define LM_JIGSAW		 0x0002
#define LM_MORPHOLOGY	 	 0x0004
#define LM_STEM_WORDS		 0x0008
#define LM_IGNORE_CASE		 0x0010
#define LM_QUESTION_PARTICLE	 0x0040
#define LM_MULTISTACK		 0x0080

#define LM_MMAP		         0x1000
#define LM_TOUCHMEM	         0x2000
#define LM_DISCARD_OVERRIDDEN    0x4000
#define LM_FUZZY_MATCH	         0x8000
#define LM_AUTO_RARE	        0x10000
#define LM_KEEP_PARTIAL	        0x20000
#define LM_REORDER_UNCOVERED	0x40000
#define LM_STRICT_GAPFILL	0x80000

// flags for Score-Options:
#define LM_FRAGMENTS		 0x0001
#define LM_JOINTPROB		 0x0002
#define LM_CHECK_NBEST		 0x0004
#define LM_USE_BYTE_LEN		 0x0008
#define LM_ADJPROBS		 0x0010
#define LM_GUARANTEE_NBEST	 0x0020
#define LM_MOSES		 0x0040
#define LM_USCORE_LOG		 0x0080
#define LM_CSCORE_LOG		 0x0100
#define LM_ALTRANK		 0x0200
#define LM_IGNORE_PREPDOC	 0x0400

// flags for Output-Options:
#define LM_SHOWCOVERAGE	         0x0001
#define LM_SHOWOVERLAP	         0x0002
#define LM_SHOW_ORIGINS		 0x0010
#define LM_KEEP_ACCENTS	 	 0x0020
#define LM_SHOWMETADATA		 0x0040
#define LM_SHOWSEARCH		 0x0080
#define LM_GENERATE_CHART	 0x0100
#define LM_PRETTYPRINT		 0x0200
#define LM_SORT_NBEST		 0x0400
#define LM_MOSES_MERT		 0x0800

//-----------------------------------------------------------------------

MTEngineConfig *make_MTEngineConfig(istream &input) ;
void delete_MTEngineConfig(MTEngineConfig *cfg) ;
ostream &dump_MTEngineConfig(const MTEngineConfig *cfg, ostream &output) ;

LMConfig *make_LMConfig(istream &input,const char *base_directory = 0) ;

#endif /* !__LMCONFIG_H_INCLUDED */

// end of file lmconfig.h //
