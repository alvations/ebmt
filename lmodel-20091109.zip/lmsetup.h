/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmsetup.h	 compile-time configuration options		*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2001,2003,2006,2008,	*/
/*		2009 Ralf Brown						*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMSETUP_H_INCLUDED
#define __LMSETUP_H_INCLUDED

// configuration options
#define LmSAVE_MEMORY		 	// more compact, but slower data strucs

/************************************************************************/
/*  Definitions conditioned on setup options				*/
/************************************************************************/

#ifdef LmSAVE_MEMORY
typedef short int LmSHORT ;		// save space, use only what's needed
typedef unsigned short LmUSHORT ;
#else
typedef int LmSHORT ;			// save time, use fastest size
typedef unsigned LmUSHORT ;
#endif /* LmSAVE_MEMORY */

/************************************************************************/
/************************************************************************/

#endif /* !__LMSETUP_H_INCLUDED */

// end of file lmsetup.h //

