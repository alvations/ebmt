/************************************************************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmglobal.C	    Language Modeler's global variables		*/
/*  LastEdit: 04nov09    						*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2001,2002,2003	*/
/*		2004,2005,2006,2007,2008,2009 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmconfig.h"
#include "lmglobal.h"
#include "ebmt.h"		// for EbSetCharEncoding

#ifdef FrSTRICT_CPLUSPLUS
# include <cmath>
#else
# include <math.h>
#endif /* FrSTRICT_CPLUSPLUS */

/************************************************************************/
/*    Manifest Constants for this module				*/
/************************************************************************/

/************************************************************************/
/*	Global variables						*/
/************************************************************************/

LMGlobalVariables lm_vars ;

static LMGlobalVariables *active_vars = 0 ;
static LMGlobalVariables *default_vars = 0 ;

//----------------------------------------------------------------------

int LM_trace = 0 ;

// how much to boost scores when multiple engines produce identical arcs
static double default_occurrence_bonuses[] =
{
   0.000, 1.000, 1.414, 1.732, 2.000,   // 0 to 4
   2.236, 2.449, 2.646, 2.828, 3.000,   // 5 to 9
   3.000, 3.000, 3.000, 3.000, 3.000,	// 10 to 14
} ;

extern bool LmUnloadWordStems() ;

/************************************************************************/
/************************************************************************/

LMGlobalVariables::LMGlobalVariables()
{
   genre_list = 0 ;
   genre = new LmGenreSettings(this) ;
   _thread_pool = 0 ;
   _language_model_files = 0 ;	
   _language_model_count = 0 ;
   _wordstem_ht = 0 ;
   _named_entity_spec = 0 ;

   _trace = LM_trace ;
   _LM_port_number = -1 ;		// by default, don't use socket
   _allow_memmapped_model = true ;
   _touch_all_memory = false ;
   _show_coverage = false ;
   _show_overlap_stats = false ;
   _show_search_stats = false ;
   _show_raw_scores = false ;
   _raw_scores_in_CMERT_format = false ;
   _skip_raw_scores = 0 ;		// don't omit any of the raw scores if
					//   we are asked to output them
   _sort_nbest_list = false ;
   _remove_nbest_dups = false ;
   _replace_nbest_dups = false ;
   _nbest_dup_handling = 0 ;
   _smoothing_name = FrSymbolTable::add("SIMPLE_KN") ;
   _lowercase_table = FrLowercaseTable(FrChEnc_Latin1) ;
   _uppercase_table = FrUppercaseTable(FrChEnc_Latin1) ;

   _preparing_for_document = false ;

   _num_occurrence_bonuses = (int)lengthof(default_occurrence_bonuses) ;
   _occurrence_bonuses = FrNewN(double,_num_occurrence_bonuses) ;
   if (_occurrence_bonuses)
      memcpy(_occurrence_bonuses,default_occurrence_bonuses,
	     sizeof(default_occurrence_bonuses)) ;
   
   _symMORPH = makeSymbol("MORPH") ;
   _symNIL = makeSymbol("NIL") ;
   _symSTRING = makeSymbol("STRING") ;
   _symEPSILON = 0 ;
   _sym_empty = makeSymbol("") ;
   applyConfiguration(0) ;
   return ;
}

//----------------------------------------------------------------------

LMGlobalVariables::LMGlobalVariables(const LMGlobalVariables &vars)
{
   *this = vars ;
   // fix up the items which are allocated on the heap
   _language_model_files = 0 ;
   if (vars._language_model_files)
      _language_model_files = (FrList*)vars._language_model_files->deepcopy();
   if (vars._wordstem_ht)
      _wordstem_ht = (FrSymHashTable*)vars._wordstem_ht->deepcopy() ;
   _thread_pool = 0 ;
   // duplicate the genre-specific information records
   LmGenreSettings *g = genre_list ;
   LmGenreSettings *curr_g = genre ;
   genre_list = 0 ;
   genre = 0 ;
   for ( ; g ; g = g->next())
      {
      LmGenreSettings *new_g = new LmGenreSettings(*g,this,0) ;
      if (g == curr_g)
	 genre = new_g ;
      }
   return ;
}

//----------------------------------------------------------------------

LMGlobalVariables::~LMGlobalVariables()
{
   if (this == active_vars)
      default_vars->select() ;
   if (this == &lm_vars && active_vars != 0)
      return ;
   freeVariables() ;
   LmUnloadWordStems() ;
   delete genre ; 		genre = 0 ;
   FrDestroyGlobalThreadPool(_thread_pool) ;  _thread_pool = 0 ;
   return ;
}

//----------------------------------------------------------------------

void LMGlobalVariables::freeVariables()
{
   // free any variables allocated on the heap
   FrFree(_dummy_arc_contents) ;	_dummy_arc_contents = 0 ;
   FrFree(_epsilon_arc_contents) ;	_epsilon_arc_contents = 0 ;
   FrFree(_occurrence_bonuses) ;	_occurrence_bonuses = 0 ;
   free_object(_language_model_files) ;	_language_model_files = 0 ;
   _language_model_count = 0 ;
   while (genre_list)
      {
      LmGenreSettings *g = genre_list ;
      genre_list = genre_list->next() ;
      delete g ;
      }
   genre = 0 ;
   if (this != &lm_vars)
      {
      while (genre_list)
	 {
	 LmGenreSettings *g = genre_list->next() ;
	 delete genre_list ;
	 genre_list = g ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

bool LMGlobalVariables::applyConfiguration(const LMConfig *config)
{
   _ngrams = 0 ;

   _verbose = false ;
   _char_based_model = false ;
   _model_includes_spaces = false ;

   // the decoder's statistics
   _attempted_expansions = 0 ;
   _expansion_collisions = 0 ;
   _unable_to_cover = 0 ;
   _unfillable_gaps = 0 ;
   _successful_expansions = 0 ;
   _overlap_expansions = 0 ;
   _interleaved_expansions = 0 ;
   _reordered_expansions = 0 ;
   _dups_removed = 0 ;
   _beam_exceeded = 0 ;
   _never_inserted = 0 ;
   _reorderings_used = 0 ;
   _total_nodes_expanded = 0 ;
   _total_ngram_probs = 0 ;
   _total_avg_ngram = 0 ;
   _total_sentences = 0 ;

   if (config)
      {
      }
   else
      {
      // set default values
      _char_encoding = FrChEnc_Latin1 ;
      _Unicode_bswap = false ;
      _generate_chart = false ;		// output best path in a chart file?
      _ignore_case = true ;
      _ignore_source_morphology = false ;
      _question_particle_hack = true ;
      _canonicalized_input_data = false ;

      _LM_reach = 1 ;

      _word_reinforcement_weight = 1.0 ;
      }
   return true ;
}

//----------------------------------------------------------------------

LMGlobalVariables *LMGlobalVariables::select()
{
   LMGlobalVariables *prev = active_vars ;
   if (!active_vars && !default_vars)
      default_vars = active_vars = new LMGlobalVariables(lm_vars) ;
   if (this == 0)
      {
      if (default_vars)
	 return default_vars->select() ;
      else
	 {
	 active_vars = 0 ;
	 return prev ;
	 }
      }
   if (this != active_vars)
      {
      if (prev)
	 *prev = lm_vars ;
      lm_vars = *this ;
      active_vars = this ;
      return prev ? prev : active_vars ;
      }
   return prev ;
}

/************************************************************************/
/************************************************************************/

void LmSetCharEncoding(const char *char_enc)
{
   char_encoding = FrParseCharEncoding(char_enc) ;
   if (char_encoding == FrChEnc_Unicode)
      cout << "Sorry, 16-bit Unicode not supported at this time" << endl ;
   uppercase_table = FrUppercaseTable(char_encoding) ;
   lowercase_table = FrLowercaseTable(char_encoding) ;
   EbSetCharEncoding(char_enc) ;
   return ;
}

//----------------------------------------------------------------------

double LmSetScaleFactor(double new_scale)
{
   double old_scale = LM_scale_factor ;
   if (new_scale >= 0.0 && new_scale <= 100.0)
      LM_scale_factor = new_scale ;
   return old_scale ;
}

//----------------------------------------------------------------------

double LmSetScaleAdjust(double new_adjust)
{
   double old_adjust = LM_scale_adjust ;
   if (new_adjust >= 0.0 && new_adjust <= 100.0)
      LM_scale_adjust = new_adjust ;
   return old_adjust ;
}

// end of file lmglobal.cpp //
