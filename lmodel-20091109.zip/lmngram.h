/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmngram.h	BWT-based n-gram language model			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 2004,2005,2006,2007,2008,2009 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef LMNGRAM_H_INCLUDED
#define LMNGRAM_H_INCLUDED

#ifndef __FRAMEPAC_H_INCLUDED
#include "FramepaC.h"
#endif

//----------------------------------------------------------------------

typedef uint32_t LmWordCount_t ;
typedef uint32_t LmWordID_t ;

#define LmMAX_WORD_LENGTH FrMAX_SYMBOLNAME_LEN
#define LmVOCAB_WORD_NOT_FOUND	((LmWordID_t)FrVOCAB_WORD_NOT_FOUND)
#define LmVOCAB_GAP_MARKER	((LmWordID_t)(LmVOCAB_WORD_NOT_FOUND-1))

#define BEGIN_SENTENCE "<s>"
#define END_SENTENCE "</s>"

#define TOKEN_UNKNOWN		"<UNK>"
#define TOKEN_UNKNOWN_LC	"<unk>"
#define TOKEN_NUMBER		"<number>"
#define TOKEN_POSSESSIVE 	"<possessive>"
#define TOKEN_RARE		"<rare>"

//----------------------------------------------------------------------

class LmUnigramRecord ;
class LmNgramRecord ;
class LmCountOfCounts ;
class LmCountMap ;
class LmNgramDiscounts ;
class LmNGramModel ;

//----------------------------------------------------------------------

class LmNGramStates
   {
   private:
      static FrAllocator *m_allocator ;
      LmNGramModel **m_models ;
      FrNGramHistory *m_history ;
      size_t *m_histlengths ;
      double *m_scores ;
      unsigned short m_maxhist ;
      unsigned short m_nummodels ;
      unsigned short m_wordcount ;
   private: // methods
      void initClear() ;
      bool allocHistories(void *oldhist = 0) ;
   public:
      void *operator new(size_t,void *where) { return where ; }
      LmNGramStates() { initClear() ; }
      LmNGramStates(LmNGramModel **models, size_t max_hist) ;
      LmNGramStates(const LmNGramStates *oldhist) ;
      ~LmNGramStates() ;

      // accessors
      bool valid() const { return m_nummodels && m_history && m_scores ; }
      size_t numModels() const { return m_nummodels ; }
      LmNGramModel **models() { return m_models ; }
      LmNGramModel *model(size_t num) { return m_models[num] ; }
      size_t maxHistory() const { return m_maxhist ; }
      FrNGramHistory *history(size_t modelnum) const
	 { return &m_history[modelnum*(m_maxhist+2)] ; }
      double score(size_t modelnum) const { return m_scores[modelnum] ; }
      size_t historyLength(size_t modelnum) const
	 { return m_histlengths[modelnum] ; }
      size_t wordsProcessed() const { return m_wordcount ; }
      size_t maxExist(size_t model_num) const ;

      // manipulators
      void clearHistories() ;
      void incrHistoryLength(size_t model_num) ;
      void processedWord() { m_wordcount++ ; }
      void updateState(size_t model_num, LmWordID_t ID,
		       size_t *max_exist = 0, const char *surf_word = 0) ;
      static void setAllocator(LmNGramModel **models, size_t max_hist) ;
      static void freeAllocator() ;
   } ;

//----------------------------------------------------------------------

class LmUnigramRecord
   {
   private:
      uint32_t	m_freq ;
      uint32_t	m_class_size ;
   public:
      LmUnigramRecord() {}	// internal use only!
      LmUnigramRecord(size_t freq, size_t csize = 1)
	 { FrStoreLong(freq,&m_freq) ; FrStoreLong(csize,&m_class_size) ; }
      LmUnigramRecord(const LmUnigramRecord &orig) ;
      ~LmUnigramRecord() {}

      bool write(FILE *fp) const ;

      // accessors
      uint32_t frequency() const { return FrLoadLong(&m_freq) ; }
      uint32_t classSize() const { return FrLoadLong(&m_class_size) ; }
      double avgFrequency() const { return frequency()/(double)classSize() ; }

      // manipulators
      void setFrequency(size_t freq) { FrStoreLong(freq,&m_freq) ; }
      void setClassSize(size_t csize) { FrStoreLong(csize,&m_class_size) ; }
      void incrClassSize() { setClassSize(classSize()+1) ; }
   } ;

//----------------------------------------------------------------------

class LmNGramsFile
   {
   private:
      FrVocabulary *m_vocab ;			// map from word to ID
      FrVocabulary *m_surfvocab ;		// map adjusting class members
      FrVocabulary *m_stopwords ;		// which words to ignore
      LmUnigramRecord *m_unigrams ;		// array of unigram records
      LmNgramRecord **m_ngram_records ;		// arrays for 2..N-grams
      uint32_t **m_ngram_next ;			// arrays of "next" ptrs
      uint32_t **m_ngram_disc ;			// arrays of smoothing values
      size_t *m_record_counts ;			// array of #records per rank
      LmNgramDiscounts *m_discounts ;		// global discount factors
      size_t m_maxlength ;			// maximum ngram length in file
      size_t m_vocabsize ;			// number of distinct words
      size_t m_numcounts ;			// number of distinct counts
      uint64_t m_numtokens ;			// training data size
      LmCountMap *m_counts ;			// countID -> value mapping
      double m_uniform ;			// uniform 0-gram probability
      LmCountOfCounts *m_countofcounts ;	//
      LmCountOfCounts *m_cumcounts ;		// cumulative counts-of-counts
      FrFileMapping *m_fmap ;			// mmap()ing for file, if any
      FrLMSmoothing m_smoothing ;		// how to smooth probabilities
      uint8_t m_affix_sizes ;
      bool m_case_sensitive ;
      bool m_char_based ;			// is LM character-based?
      bool m_include_spaces ;			// char-based LM incl spaces?
      bool m_OK ;
   private:
      bool allocPerRankData() ;
      void loadCountOfCounts(const char *data) ;
      void loadRecords(const char *recptrs, FILE *fp, const char *mappedmem,
		       size_t max_touchmem_rank = 0) ;
      void computeSmoothingFactors(size_t rank) ;
      uint32_t locateNext(LmWordID_t ID, size_t rank, uint32_t index) const ;
      double discountFactor(size_t rank, size_t count) const ;
      double smoothingFactor(size_t rank, uint32_t index) const ;
      double rawCondProbability(const LmWordID_t *history, size_t histlen,
				LmWordID_t ID, size_t class_size) const ;
      double rawCondProbability(FrNGramHistory *history, size_t histlen,
				LmWordID_t ID, size_t class_size) const ;
      double probabilityKN(const LmWordID_t *IDs, size_t numIDs,
			   size_t *max_exist = 0) const ;
      double probabilityKN(const FrNGramHistory *history,
			   FrNGramHistory *newhistory, size_t numIDs,
			   LmWordID_t ID, size_t *max_exist = 0) const ;
      double probabilityMax(const LmWordID_t *IDs, size_t numIDs,
			    size_t *max_exist = 0) const ;
      double probabilityMax(FrNGramHistory *history, size_t numIDs,
			    LmWordID_t ID, size_t *max_exist = 0) const ;
      double probabilityMean(const LmWordID_t *IDs, size_t numIDs,
			     size_t *max_exist = 0) const ;
      double probabilityMean(FrNGramHistory *history, size_t numIDs,
			     LmWordID_t ID, size_t *max_exist = 0) const ;
      double probabilityBackoff(const LmWordID_t *IDs, size_t numIDs,
				size_t *max_exist = 0) const ;
      double probabilityBackoff(FrNGramHistory *history, size_t numIDs,
				LmWordID_t ID, size_t *max_exist = 0) const ;
      void initZerogram(FrNGramHistory *history) const ;
   public:
      LmNGramsFile(const char *filename, size_t max_rank_to_use,
		   bool allow_mmap = true,
		   bool preload = true) ;
      ~LmNGramsFile() ;
      static bool verifyFormat(const char *filename) ;

      static double smoothingFactor(const LmNgramDiscounts *discounts,
				    const LmCountOfCounts *counts,
				    size_t total_count) ;

      // accessors
      bool OK() const { return m_OK ; }
      bool isCaseSensitive() const { return m_case_sensitive ; }
      bool isCharBased() const { return m_char_based ; }
      bool includesSpaces() const { return m_include_spaces ; }
      uint8_t affixSizes() const { return m_affix_sizes ; }
      FrLMSmoothing smoothing() const { return m_smoothing ; }
      FrVocabulary *vocabulary() const { return m_vocab ; }
      FrVocabulary *surfaceVocabulary() const { return m_surfvocab ; }
      FrVocabulary *stopwordVocabulary() const { return m_stopwords ; }
      size_t maxNgramLength() const { return m_maxlength ; }
      uint64_t trainingSize() const { return m_numtokens ; }
      size_t vocabularySize() const { return m_vocabsize ; }
      size_t classSize(LmWordID_t ID) const
	 { return ID < m_vocabsize ? m_unigrams[ID].classSize() : 1 ; }
      uint32_t unigramFreq(size_t ID) const
	 { return ID < m_vocabsize ? m_unigrams[ID].frequency() : 0 ; }
      size_t ngramCount(size_t N) const
	 { return (N>=1 && N <= maxNgramLength()) ? m_record_counts[N] : 0 ; }
      size_t recordOffset(const LmWordID_t *IDs, size_t rank) const ;
      uint32_t getCount(size_t rank, uint32_t index) const ;
      uint32_t frequency(const LmWordID_t *IDs, size_t numIDs,
			 uint32_t *rec_index = 0) const ;
      uint32_t frequency(size_t prev_rank,LmWordID_t ID,uint32_t index) const ;
      uint32_t frequency(size_t prev_rank,LmWordID_t ID,
			 uint32_t *rec_index) const ;
      size_t longestMatch(const LmWordID_t *IDs, size_t numIDs) const ;
      double probability(const LmWordID_t *IDs, size_t numIDs,
			 size_t *max_exist = 0) const ;
      double probability(FrNGramHistory *history, size_t numIDs,
			 LmWordID_t ID, size_t *max_exist = 0) const ;
      double probability(const char * const *words, size_t numwords,
			 size_t *max_exist = 0) const ;
      double probability(const FrList *words) const ;

      double perplexity(size_t rank, bool use_entropy) const ;

      // manipulators
      //bool unmemmap() ;
      void smoothing(FrLMSmoothing sm) { m_smoothing = sm ; }

      // I/O
      static bool convert(const char *filename, const FrBWTIndex *index,
			    FrVocabulary *vocab, size_t ngram_rank,
			    size_t precomp_rank = ~0,
			    bool char_based = false,
			    bool include_spaces = false,
			    FrVocabulary *surfvocab = 0,
			    FrVocabulary *stopwords = 0) ;
      static bool convert(const char *filename, const char * const *files,
			    size_t ngram_rank, size_t precomp_rank = ~0,
			    size_t scaling_factor = 1,
			    bool char_based = false,
			    bool include_spaces = false) ;
      bool dump(FILE *outfp, const char *modelname,
		  bool run_verbosely = false) const ;
   } ;

//----------------------------------------------------------------------
//  this class provides a unified interface to the various different
//    supported language model file formats

class LmNGramModel
   {
   protected:
      FrVocabulary *m_vocab ;		// mapping from word to ID
      FrVocabulary *m_surfvocab ;	// map from surface to adj within class
      FrVocabulary *m_stopwords ;	//
      LmNGramsFile *m_ngrams ;		// data for .ngm-format model file
      FrBWTIndex   *m_index ;		// data for .bwt-format model file
      class Ngram  *m_srilm ;		// SRI-style language model
      class Vocab  *m_srivcb ;		// vocabulary for SRI-style model
      LmNGramModel *m_sourcemodel ;	// corresponding source-language model
      FrSymbol *m_begsent_sym ;
      FrSymbol *m_endsent_sym ;
      FrSymbol *m_smoothing_name ;
      char *m_name ;			// friendly name (usu. base filename)
      char *m_ident ;			// identifier, used for section name
      double m_baseweight ;		// default weight of this model
      double m_contextweight ;		// context-dependent weight
      double m_weight ;			// effective weight
      double m_sourcecover ;		// accumulated source coverage
      double m_discount_mass ;
      size_t m_max_ngram ;
      size_t m_model_number ;
      LmWordID_t m_begsent_id ;
      LmWordID_t m_unknown_id ;
      FrLMSmoothing m_smoothing ;
      bool m_logspace ;
      bool m_jointprob ;

   private: // methods
      LmWordID_t findWordID_SRI(const char *word) const ;

   protected: // methods
      static bool verifyBWTSignature(const char *filename) ;
      static bool verifyBBOSignature(const char *filename) ;
      static bool verifyNGMSignature(const char *filename)
	 { return LmNGramsFile::verifyFormat(filename) ; }
      static bool verifySRISignature(const char *filename) ;
      void init(const char *filename, const char *sourcefile,
		double weight, double context, double discount,
		FrSymbol *smoothing, const char *ident = 0) ;
      double freq2prob(double freq) const ;
      double adjustProbability(const char *surf, LmWordID_t ID,
			       double prob) const ;
   protected:
      LmNGramModel() {}
   public:
      void *operator new(size_t size) { return FrMalloc(size) ; }
      void operator delete(void *blk) { FrFree(blk) ; }
      LmNGramModel(const char *filename, size_t max_ngram = ~0,
		   const char *sourcefile = 0, const char *ident = 0) ;
      LmNGramModel(const class LModelConfig *) ;
      virtual ~LmNGramModel() ;
      static LmNGramModel *newModel(const char *filename,
				    const char *sourcefile,
				    size_t max_ngrams, double weight,
				    double context_weight, double discount,
				    FrSymbol *smooth_name,
				    const char *ident) ;
      static LmNGramModel *newModel(const char *filename,
				    size_t max_ngram = ~0,
				    const char *sourcefile = 0,
				    const char *ident = 0) ;
      static LmNGramModel *newModel(const class LModelConfig *) ;

      // utility functions
      static bool verifySignature(const char *filename)
	 { return (verifyBWTSignature(filename) || 
		   verifyBBOSignature(filename) ||
		   verifyNGMSignature(filename) ||
		   verifySRISignature(filename)) ; }

      static const char *remapWord(const char *word, FrSymHashTable *stem_ht,
				   bool &is_possessive,
				   bool is_cased = true,
				   uint8_t affix_sizes = 0,
				   bool *using_affix = 0) ;
      static double log(double x) ;

      // accessors
      bool OK() const
	 { return (m_index != 0 && m_vocab != 0) ||
	      (m_ngrams != 0 && m_ngrams->OK() && m_vocab != 0) ||
	      (m_srilm && m_srivcb) ; }
      virtual bool isCaseSensitive() const ;
      virtual bool isCharBased() const ;
      virtual bool includesSpaces() const ;
      virtual uint8_t affixSizes() const ;
      virtual uint64_t trainingSize() const ;
      size_t modelNumber() const { return m_model_number ; }
      size_t maxNgramLength() const { return m_max_ngram ; }
      bool usingLogSpace() const { return m_logspace ; }
      bool usingJointProb() const { return m_jointprob ; }
      LmWordID_t wordID_begsent() const { return m_begsent_id ; }
      FrSymbol *word_begsent() const { return m_begsent_sym ; }
      FrSymbol *word_endsent() const { return m_endsent_sym ; }
      FrLMSmoothing smoothing() const { return m_smoothing ; }
      FrSymbol *smoothingName() const { return m_smoothing_name ; }
      double discountMass() const { return m_discount_mass ; }
      LmWordID_t wordID_unknown() const { return m_unknown_id ; }
      FrSymbol *wordForID(LmWordID_t ID) const ;
      FrVocabulary *vocabulary() const { return m_vocab ; }
      FrVocabulary *surfaceVocabulary() const { return m_surfvocab ; }
      FrBWTIndex *ngramModel() const { return m_index ; }
      LmNGramsFile *ngramsFile() const { return m_ngrams ; }
      class Ngram *sriModel() const { return m_srilm ; }
      class Vocab *sriVocab() const { return m_srivcb ; }
      LmNGramModel *sourceModel() const { return m_sourcemodel ; }
      double weight() const { return  m_weight ; }
      double baseWeight() const { return m_baseweight ; }
      double contextWeight() const { return m_contextweight ; }
      const char *name() const { return m_name ; }
      const char *sectionName() const { return m_ident ; }
      virtual LmWordID_t getUnknownID() const ;

      virtual double rawProbability(size_t numwords, const LmWordID_t *IDs,
				    size_t *max_exist) const ;
      virtual double rawProbability(size_t numwords, FrNGramHistory *hist,
				    LmWordID_t ID, size_t *max_exist) const ;

      static int string2words(const char *string, char **&wordlist) ;
      LmWordID_t findWordID(const char *word) const ;
      bool isStopWord(const char *word) const ;
      size_t longestMatch(const LmWordID_t *IDs, size_t numIDs) const ;

      double rawProbability(const LmWordID_t *IDs, size_t numIDs,
			    size_t *max_exist = 0,
			    const char *surf_word = 0) const ;
      double rawProbability(FrNGramHistory *history, size_t numIDs,
			    LmWordID_t ID, size_t *max_exist = 0,
			    const char *surf_word = 0) const ;
      double probability(const LmWordID_t *IDs, size_t numwords,
			 size_t *max_exist = 0,
			 const char *surf_word = 0) const ;
      double probability(FrNGramHistory *history, size_t numIDs,
			 LmWordID_t ID, size_t *max_exist,
			 const char *surf_word = 0) const ;
      double probability(const FrList *ngram) const ;
      size_t frequency(const FrList *words) const ;
      virtual size_t frequency(const LmWordID_t *IDs, size_t numwords) const ;
      virtual size_t classSize(LmWordID_t ID) const ;
      virtual double perplexity(size_t rank) const ;
      double scaledProbability(double prob) const ;

      // manipulators
      void useLogSpace(bool logsp = true) ;
      void useJointProb(bool joint = true) { m_jointprob = joint ; }
      void maxNgramLength(size_t len) ;
      void setSentMarkers() ;
      void smoothing(FrSymbol *smoothing_name) ;
      void smoothing(FrLMSmoothing sm) ;
      void modelNumber(size_t N) { m_model_number = N ; }
      void weight(double wt)
	 { m_baseweight = (wt >= 0.0 ? wt : 0.0) ;
	   m_weight = m_baseweight * contextWeight() ; }
      void contextWeight(double wt)
	 { m_contextweight = (wt >= 0.0 ? wt : 0.0) ;
	   m_weight = baseWeight() * m_contextweight ; }
      bool convertBWTtoNGM(const char *destfile, size_t rank = 4,
			     size_t precomp_rank = 4) const ;

      // source-cover computation
      bool accumulateCoverBegin() ;
      bool accumulateCover(const FrList *words) ;
      double accumulatedCoverage() const { return m_sourcecover ; }
      bool accumulateCoverDone(double total_cover, size_t total_models) ;

      // I/O and debugging
      bool dump(FILE *outfp, const char *modelname,
		  bool run_verbosely = false) const ;
      void dumpConfig(ostream &out) const ;
   } ;

/************************************************************************/
/************************************************************************/

class LmNGramModelBWT : public LmNGramModel
   {
   private:
      void initBWT(const char *filename, size_t max_ngram, double discount) ;
   public:
      LmNGramModelBWT(const char *filename,
		      const char *sourcemodelfile,
		      size_t max_ngram, double weight,
		      double context_weight,
		      double discount,
		      FrSymbol *smooth_name,
		      const char *ident) ;
      virtual LmWordID_t getUnknownID() const ;
      virtual double perplexity(size_t rank) const ;
      virtual size_t classSize(LmWordID_t ID) const ;
      virtual size_t frequency(const LmWordID_t *IDs, size_t numwords) const ;
      virtual size_t longestMatch(const LmWordID_t *IDs, size_t numwords) const ;
      virtual double rawProbability(size_t numwords, const LmWordID_t *IDs,
				    size_t *max_exist) const ;
      virtual double rawProbability(size_t numwords, FrNGramHistory *hist,
				    LmWordID_t ID, size_t *max_exist) const ;
      virtual bool isCaseSensitive() const ;
      virtual bool isCharBased() const ;
      virtual bool includesSpaces() const ;
      virtual uint8_t affixSizes() const ;
      virtual uint64_t trainingSize() const ;
      virtual bool dump(FILE *outfp, const char *modelname, bool verb) const ;
   } ;

//----------------------------------------------------------------------

class LmNGramModelNGM : public LmNGramModel
   {
   private:
      void initNGM(const char *filename, size_t max_ngram) ;
   public:
      LmNGramModelNGM(const char *filename,
		      const char *sourcemodelfile,
		      size_t max_ngram, double weight,
		      double context_weight,
		      double discount,
		      FrSymbol *smooth_name,
		      const char *ident) ;
      virtual LmWordID_t getUnknownID() const ;
      virtual double perplexity(size_t rank) const ;
      virtual size_t classSize(LmWordID_t ID) const ;
      virtual size_t frequency(const LmWordID_t *IDs, size_t numwords) const ;
      virtual size_t longestMatch(const LmWordID_t *IDs, size_t numwords) const ;
      virtual double rawProbability(size_t numwords, const LmWordID_t *IDs, 
				    size_t *max_exist) const ;
      virtual double rawProbability(size_t numwords, FrNGramHistory *hist,
				    LmWordID_t ID, size_t *max_exist) const ;
      virtual bool isCaseSensitive() const ;
      virtual bool isCharBased() const ;
      virtual bool includesSpaces() const ;
      virtual uint8_t affixSizes() const ;
      virtual uint64_t trainingSize() const ;
      virtual bool dump(FILE *outfp, const char *modelname, bool verb) const ;
   } ;

//----------------------------------------------------------------------

class LmNGramModelSRILM : public LmNGramModel
   {
   private:
      void initSRI(const char *filename) ;
      void setSentMarkersSRI() ;
   public:
      LmNGramModelSRILM(const char *filename,
			const char *sourcemodelfile,
			size_t max_ngram, double weight,
			double context_weight,
			double discount,
			FrSymbol *smooth_name,
			const char *ident) ;
      virtual ~LmNGramModelSRILM() ;
      //virtual LmWordID_t getUnknownID() const ;
      virtual double perplexity(size_t rank) const ;
      //virtual size_t classSize(LmWordID_t ID) const ;
      virtual size_t frequency(const LmWordID_t *IDs, size_t numwords) const ;
      virtual size_t longestMatch(const LmWordID_t *IDs, size_t numwords) const ;
      virtual double rawProbability(size_t numwords, const LmWordID_t *IDs,
				    size_t *max_exist) const ;
      virtual double rawProbability(size_t numwords, FrNGramHistory *hist,
				    LmWordID_t ID, size_t *max_exist) const ;
      virtual bool isCaseSensitive() const ;
      virtual bool isCharBased() const ;
      virtual bool includesSpaces() const ;
      //virtual uint8_t affixSizes() const ;
      virtual uint64_t trainingSize() const ;
      virtual bool dump(FILE *outfp, const char *modelname, bool verb) const ;
   } ;

/************************************************************************/
/************************************************************************/

#define PACK_AFFIX_LENGTHS(prefix,suffix) (((prefix & 0xF) << 4) | (suffix & 0xF))
#define UNPACK_AFFIX_LENGTHS(affix,prefix,suffix) (prefix = ((affix >> 4) & 0xF), suffix = (affix & 0xF))
#define AFFIX_CHAR '\x02'

/************************************************************************/
/************************************************************************/

bool LmNgramModelWeights(LmNGramModel **models, size_t num_models,
			   const FrList *weights) ;

template <class T> void LmNgramScore(LmNGramModel **models, T words[],
				     size_t num_words, size_t max_ngram=0) ;
    // note: T may be TargetWordRef or TargetWordStats; if max_ngram==0,
    //   use global max_ngram_length
template <class T> void LmNgramScore(LmNGramStates *modelstates, T words[],
				     size_t num_words, size_t max_ngram=0) ;
    // note: T may be TargetWordRef or TargetWordStats

double LmNGramProbability(const LmNGramModel *model, const char **words) ;
double LmNGramSourceCoverage(const LmNGramModel *model, const FrList *words,
			     double power = 1.0) ;
    // note: returns sum of maximal match starting from each word raised to
    //   the given power

bool LmIsNumber(const char *word) ;

#endif /* !LMNGRAM_H_INCLUDED */

// end of file lmngram.cpp //
