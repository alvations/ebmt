/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmbitset.h		functions for bit-sets			*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright  2006,2007,2008,2009 Ralf Brown			*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#ifndef __LMBITSET_H_INCLUDED
#define __LMBITSET_H_INCLUDED

#ifndef __FRAMEPAC_H_INCLUDED
#include "FramepaC.h"
#endif

/************************************************************************/
/************************************************************************/

#if __BITS__ == 64
typedef unsigned long LmBitFlags ;
#else
typedef unsigned LmBitFlags ;
#endif

#define LM_BITS_PER_ENTRY (CHAR_BIT * sizeof(LmBitFlags))

inline LmBitFlags *LmAllocBitFlags(size_t N)
{
   return FrNewC(LmBitFlags,(N+LM_BITS_PER_ENTRY-1)/LM_BITS_PER_ENTRY) ;
}

inline bool LmGetBit(const LmBitFlags *flags, size_t N)
{
   return (flags[N/LM_BITS_PER_ENTRY] & (1UL << (N%LM_BITS_PER_ENTRY))) != 0 ;
}

inline void LmSetBit(LmBitFlags *flags, size_t N)
{
   flags[N/LM_BITS_PER_ENTRY] |= (1UL << (N%LM_BITS_PER_ENTRY)) ;
   return ;
}

inline void LmClearBit(LmBitFlags *flags, size_t N)
{
   flags[N/LM_BITS_PER_ENTRY] &= ~(1UL << (N%LM_BITS_PER_ENTRY)) ;
   return ;
}

inline void LmSetBits(LmBitFlags *flags, size_t first, size_t N)
{
   for (size_t i = first ; i < first + N ; i++)
      LmSetBit(flags,i) ;
   return ;
}

/************************************************************************/
/************************************************************************/

#endif /* !__LMBITSET_H_INCLUDED */

// end of file lmbitset.h
