/************************************************************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmprique.cpp		priority queues				*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,2002,2003,2004,2005,2006,	*/
/*		2007,2008,2009 Ralf Brown				*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmbfs.h"
#include "lmprique.h"
#include "lmglobal.h"
#ifndef NDEBUG
#  include "lmarcs.h"
#endif /* !NDEBUG */

#ifdef FrSTRICT_CPLUSPLUS
#  include <cmath>
#else
#  include <math.h>
#endif /* FrSTRICT_CPLUSPLUS */

/************************************************************************/
/*    Helper Function							*/
/************************************************************************/

bool no_worse_node(const BFSNode *node1, const BFSNode *node2) ;
// in lmtreap.cpp //

/************************************************************************/
/*    Methods for class PriorityQueue					*/
/************************************************************************/

PriorityQueue::PriorityQueue(size_t limit, double ratio, bool keep_pruned,
			     size_t nbest_list_size)
{
   m_nodes = 0 ;
   m_sorted = 0 ;
   maxlength = limit ;
   m_length = 0 ;
   maxlength_used = 0 ;
   m_cutoff = m_highscore = -DBL_MAX ;
   m_cutoff_ratio = ratio ;
   clearPruning() ;
   setPruningLimit(nbest_list_size) ;
   remember_pruned = keep_pruned ;
   nodes_sorted = false ;
   return ;
}

//----------------------------------------------------------------------

PriorityQueue::~PriorityQueue()
{
   LmTreapDelete(m_nodes) ;
   m_nodes = 0 ;
   m_length = 0 ;
   LmTreapDelete(m_pruned) ;
   m_pruned = 0 ;
   num_pruned = 0 ;
   while (m_sorted)
      {
      BFSNode *node = m_sorted ;
      m_sorted = m_sorted->next() ;
      delete node ;
      }
   clearPruning() ;
   maxlength = 0 ;
   return ;
}

//----------------------------------------------------------------------

void PriorityQueue::checkTree(const BFSNode *node)
{
   if (node)
      {
      assertq(node->wordList() != 0) ;
      checkTree(node->left()) ;
      checkTree(node->right()) ;
      }
   return ;
}

//----------------------------------------------------------------------

BFSNode *PriorityQueue::pop()
{
   sort() ;
   BFSNode *node = m_sorted ;
   if (m_sorted)
      {
      m_sorted = m_sorted->next() ;
      --m_length ;
      }
   return node ;
}

//----------------------------------------------------------------------

BFSNode *PriorityQueue::popAll()
{
   sort() ;
   BFSNode *nodes = m_sorted ;
   m_sorted = 0 ;
   m_length = 0 ;
   return nodes ;
}

//----------------------------------------------------------------------

BFSNode *PriorityQueue::peek()
{
   sort() ;
   return m_sorted ;
}

//----------------------------------------------------------------------

#ifndef NDEBUG
static void show_skipped_newelt(BFSNode *newelt, bool duplicated)
{
   cerr << " -skip- " << newelt->score()  << " (raw=" << newelt->rawScore()
	<< ",ngfrac=" << newelt->ngramFraction() << ") " ;
   int len = newelt->outputLength() ;
   const TargetWordRef *words = newelt->wordList() ;
   for (int wrd = 0 ; wrd < len ; wrd++)
      {
      const FrSymbol *w = words[wrd].name() ;
      cerr << (w ? w->symbolName() : "{}") << ' ' ;
      }
   if (duplicated)
      cerr << " (dup)" ;
   cerr << endl ;
   return ;
}
#endif /* !NDEBUG */

//----------------------------------------------------------------------

#ifndef NDEBUG
static void show_removed_elt(BFSNode *curr)
{
   cerr << " -- removing " << curr->score()  << " (raw=" << curr->rawScore()
	<< ",ngfrac=" << curr->ngramFraction() << ") " ;
   int len = curr->outputLength() ;
   const TargetWordRef *words = curr->wordList() ;
   for (int wrd = 0 ; wrd < len ; wrd++)
      {
      const FrSymbol *w = words[wrd].name() ;
      cerr << (w ? w->symbolName() : "{}") << ' ' ;
      }
   cerr << endl ;
   return ;
}
#endif /* !NDEBUG */

//----------------------------------------------------------------------

#ifndef NDEBUG
static void show_inserted_newelt(BFSNode *newelt)
{
   cerr << " inserted/" << newelt->inputCoverage() << ' '
	<< newelt->score() << " (raw=" << newelt->rawScore()
	<< ",ngfrac=" << newelt->ngramFraction() << ") " ;
   int len = newelt->outputLength() ;
   const TargetWordRef *words = newelt->wordList() ;
   for (int wrd = 0 ; wrd < len ; wrd++)
      {
      const FrSymbol *w = words[wrd].name() ;
      cerr << (w ? w->symbolName() : "{}") << ' ' ;
      }
   cerr << endl ;
   if ((trace >= 15 && newelt->complete()) || trace > 20)
      newelt->dumpArcs(cerr) ;
   return ;
}
#endif /* !NDEBUG */

//----------------------------------------------------------------------

void PriorityQueue::setCutoff(double hiscore)
{
   m_highscore = hiscore ;
   if (hiscore > 0.0 && !moses_style_scoring)
      m_cutoff = (m_cutoff_ratio > 1.0) ? hiscore / m_cutoff_ratio : 0.0 ;
   else if (hiscore < 0.0)
      m_cutoff = hiscore * m_cutoff_ratio ;
   else
      m_cutoff = -m_cutoff_ratio ;
   return ;
}

//----------------------------------------------------------------------

void PriorityQueue::setPruningLimit(size_t factor)
{
   if (factor == 0)
      max_pruned = (size_t)~0 ;
   else if (guarantee_nbest || factor <= 2)
      max_pruned = factor * maximumLength() ;
   else
      max_pruned = (size_t)((::sqrt(factor) + 0.75) * maximumLength()) ;
   return ;
}

//----------------------------------------------------------------------

void PriorityQueue::clearPruning()
{
   m_pruned = 0 ;
   num_pruned = 0 ;
   return ;
}

//----------------------------------------------------------------------

bool PriorityQueue::insertPruned(BFSNode *newelt, size_t &prune_count)
{
   if (remember_pruned)
      {
      if (num_pruned >= max_pruned && newelt->score() < m_pruned->score())
	 {
	 prune_count++ ;
	 delete newelt ;
	 return true ;	 		// node has been used or deleted
	 }
      BFSNode *duplicate = LmTreapInsert(m_pruned,newelt) ;
      if (duplicate)
	 delete duplicate ;
      else
	 {
	 num_pruned++ ;
	 prune_count++ ;
	 if (num_pruned > max_pruned)
	    {
	    BFSNode *min_node = LmTreapPopMin(m_pruned) ;
	    delete min_node ;
	    num_pruned-- ;
	    }
	 }
      }
   else
      delete newelt ;
   return true ;			// node has been used or deleted
}

//----------------------------------------------------------------------

bool PriorityQueue::insertMultiple(BFSNode *nodes, size_t &prune_count)
{
   BFSNode *next ;
   bool success = true ;
   lock() ;
   for ( ; nodes ; nodes = next)
      {
      next = nodes->next() ;
      nodes->setNext(0) ;
      if (!insert(nodes,prune_count))
	 {
	 success = false ;
prune_count++;
	 delete nodes ;
	 }
      }
   unlock() ;
   return success ;
}

//----------------------------------------------------------------------

bool PriorityQueue::insert(BFSNode *newelt, size_t &prune_count)
{
   NTRACE(19,(cout << "PriQ::insert (prune="<<prune_count<<"):\n",newelt->dumpArcs(cout))) ;
   double newscore = newelt->score() ;
   // invariants for a queue containing only elements with a single
   //   value for inputCoverage():
   //	currentLength() <= maximumLength()
   //	no nodes that are compareNode()==0 of other nodes in queue
   //	lowest-valued element >= max-valued / beam_ratio
   if (nodes_sorted)
      {
      m_nodes = LmTreapFromList(m_sorted) ;
      m_sorted = 0 ;
      nodes_sorted = false ;
      }
   if (newscore < cutoff() ||
       (currentLength() >= maximumLength() && no_worse_node(m_nodes,newelt)))
      {
      // don't bother inserting, it's fallen off the beam
      NTRACE(8,(show_skipped_newelt(newelt,0))) ;
      INCR_STATS(never_inserted) ;
      return insertPruned(newelt,prune_count) ;
      }
   if (newscore > highestScore())	// will it be new head of list?
      setCutoff(newscore) ;
   BFSNode *duplicate = LmTreapInsert(m_nodes,newelt) ;
   if (duplicate)
      {
      if (duplicate == newelt)
	 {
	 // don't bother inserting, it's a duplicate that will never be chosen
	 NTRACE(8,(show_skipped_newelt(newelt,1))) ;
	 INCR_STATS(never_inserted) ;
	 }
      else
	 {
	 // the new node has knocked some other node out of the queue because
	 //   it's better, so delete the replaced node
	 NTRACE(6,(show_inserted_newelt(newelt))) ;
	 NTRACE(7,(show_removed_elt(duplicate))) ;
	 INCR_STATS(dups_removed) ;
	 }
      delete duplicate ;
      return true ;
      }
   // the new element has been inserted, so now check whether we need to
   //   trim the queue
   m_length++ ;
   NTRACE(6,(show_inserted_newelt(newelt))) ;
   // successively delete the lowest-scoring member until we are once
   //   again below the maximum length and above the cutoff
   while (currentLength() > maximumLength() ||
	  (m_nodes && m_nodes->score() < cutoff()))
      {
      BFSNode *min_node = LmTreapPopMin(m_nodes) ;
      NTRACE(9,(show_removed_elt(min_node))) ;
      // since the beam is full, we can raise the cutoff to be as high as
      //   the score of any nodes which fall off the beam and thus avoid
      //   searching the treap for some future insertions
      if (min_node->score() > cutoff())
	 m_cutoff = min_node->score() ;
      delete min_node ;
      m_length-- ;
      INCR_STATS(beam_exceeded) ;
      }
   if (m_length > maxlength_used)
      maxlength_used = m_length ; 
   return true ;			// node has been added to queue
}

//----------------------------------------------------------------------

void PriorityQueue::sort()
{
   if (!nodes_sorted)
      {
      m_sorted = LmTreapToList(m_nodes) ;
      m_nodes = 0 ;
      nodes_sorted = true ;
      }
   return ;
}

//----------------------------------------------------------------------

bool PriorityQueue::refill(size_t num_remaining)
{
   if (m_pruned)
      {
      TRACE(6,(cout<<"start refill"<<endl)) ;
      // convert tree of pruned nodes into a list sorted by descending score
      BFSNode *pool = LmTreapToList(m_pruned) ;
      clearPruning() ;
      setCutoff(pool->score()) ;
      if (nodes_sorted)
	 {
	 m_nodes = LmTreapFromList(m_sorted) ;
	 m_sorted = 0 ;
	 nodes_sorted = false ;
	 }
      // reinsert the highest-scoring nodes into the queue
      NTRACE(9,(cout<<"  reinserting pruned nodes"<<endl)) ;
      while (pool && currentLength() < maximumLength() &&
	     pool->score() >= cutoff())
	 {
	 BFSNode *node = pool ;
	 pool = pool->next() ;
	 BFSNode *duplicate = LmTreapInsert(m_nodes,node) ;
	 if (duplicate)
	    delete duplicate ;
	 else
	    m_length++ ;
	 }
      // whatever is left goes back into the set of pruned nodes
      NTRACE(9,(cout<<"  placing nodes on prune list"<<endl)) ;
      setPruningLimit(num_remaining) ;
      while (pool && numPruned() < maxPruned())
	 {
	 BFSNode *node = pool ;
	 pool = pool->next() ;
	 BFSNode *duplicate = LmTreapInsert(m_pruned,node) ;
	 if (duplicate)
	    delete duplicate ;
	 else
	    num_pruned++ ;
	 }
      // anything beyond the pruning limit can safely be discarded at this
      //   point
      NTRACE(9,(cout<<"  discarding low-scoring nodes"<<endl)) ;
      while (pool)
	 {
	 BFSNode *node = pool ;
	 pool = pool->next() ;
	 delete node ;
	 }
      TRACE(6,(cout<<"refill done"<<endl)) ;
      return true ;
      }
   return false ;
}

// end of file lmprique.cpp //
