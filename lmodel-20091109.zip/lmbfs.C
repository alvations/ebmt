/****************************** -*- C++ -*- *****************************/
/*									*/
/*  Pangloss Language Model						*/
/*  Version 2.90							*/
/*	by Ralf Brown <ralf@cs.cmu.edu>					*/
/*									*/
/*  File lmbfs.cpp	best-first search				*/
/*  LastEdit: 04nov09							*/
/*									*/
/*  (c) Copyright 1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,	*/
/*		2004,2005,2006,2007,2008,2009 Ralf Brown		*/
/*	This program is free software; you can redistribute it and/or	*/
/*	modify it under the terms of the GNU General Public License as	*/
/*	published by the Free Software Foundation, version 3.		*/
/*									*/
/*	This program is distributed in the hope that it will be		*/
/*	useful, but WITHOUT ANY WARRANTY; without even the implied	*/
/*	warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR		*/
/*	PURPOSE.  See the GNU General Public License for more details.	*/
/*									*/
/*	You should have received a copy of the GNU General Public	*/
/*	License (file COPYING) along with this program.  If not, see	*/
/*	http://www.gnu.org/licenses/					*/
/*									*/
/************************************************************************/

#include "lmbfs.h"
#include "lmconfig.h"
#include "lmngram.h"
#include "lmpchart.h"
#include "lmprique.h"
#include "lmmain.h"
#include "lmglobal.h"

#ifdef FrSTRICT_CPLUSPLUS
# include <cmath>
#else
# include <math.h>
#endif /* FrSTRICT_CPLUSPLUS */

/************************************************************************/
/*    Manifest Constants for this module				*/
/************************************************************************/

// there's an occasional occurrence of nodes that have coverage>input_length
//   this is a workaround; once fixed, set to 0
#define OVERRUN 1

#define MAX_REORDER_STACKS 8

// dispatch multiple nodes for expansion in a batch to cut down on the
//   task-switching and task-synchronization overhead
#define DISPATCH_MIN_BLOCKING_FACTOR	100
#define DISPATCH_MAX_BLOCKING_FACTOR	1000

// define the discounting function for discount_by_proportion
//   the first DISCOUNT_START words get zero weight, those after DISCOUNT_END
//   get full weight, and those in between are linearly interpolated between
//   the two extremes
#define DISCOUNT_START 3
#define DISCOUNT_WINDOW 3
#define DISCOUNT_END (DISCOUNT_START + DISCOUNT_WINDOW)

/************************************************************************/
/*    Global data for this module					*/
/************************************************************************/

/************************************************************************/
/*    Global variables for this module				       	*/
/************************************************************************/

FrAllocator BestFirstSearch::allocator("BestFirstSearch",
				       sizeof(BestFirstSearch)) ;
FrAllocator BFSScoreInfo::allocator("BFSScoreInfo",sizeof(BFSScoreInfo)) ;
FrAllocator BFSNode::allocator("BFSNode",sizeof(BFSNode)) ;
FrAllocator *BFSNode::cover_allocator = 0 ; 
FrAllocator **BFSNode::word_allocators = 0 ; 

BestFirstSearch *lm_active_search = 0 ;

/************************************************************************/
/*	Helper functions						*/
/************************************************************************/

static double discount_by_proportion(double value, size_t so_far, size_t whole,
				     bool use_all_words = true)
{
   size_t window =
      use_byte_lengths ? DISCOUNT_WINDOW * 5 : DISCOUNT_WINDOW ;
   size_t discount_start =
      use_byte_lengths ? DISCOUNT_START * 5 : DISCOUNT_START ;
   size_t discount_end =
      use_byte_lengths ? DISCOUNT_END * 5 : DISCOUNT_END ;
   if (use_all_words)
      {
      if (so_far >= window)
	 return value ;
      }
   else
      {
      if (so_far < discount_start && so_far < whole)
	 return 0.0 ;
      if (so_far >= discount_end ||	// give full value if input is
	  whole <= discount_start)	//   very short
	 return value ;		
      size_t first = ((whole >= discount_end)
		      ? discount_start : (whole - window)) ;
      whole -= first ;
      so_far -= first ;
      }
   // figure out which proportion of the words in the transition window
   //   are covered, and pro-rate the given score by that proportion
   if (whole < window)
      window = whole ;
   return value * (so_far / window) ;
}

//----------------------------------------------------------------------

inline bool in_range(size_t x, size_t low, size_t high)
{
   return (x >= low && x <= high) ;
}

//----------------------------------------------------------------------

void erase_list(BFSNode *list)
{
   while (list)
      {
      BFSNode *tmp = list ;
      list = list->next() ;
      delete tmp ;
      }
   return ;
}

/************************************************************************/
/*    Methods for class BFSScoreInfo					*/
/************************************************************************/

BFSScoreInfo::BFSScoreInfo(const BFSScoreInfo *orig)
{
   if (orig)
      {
      for (size_t i = 0 ; i < MAX_USER_SCORES ; i++)
	 m_userscores[i] = orig->m_userscores[i] ;
      arcScores(orig->arcScores()) ;
      arcQualities(orig->arcQualities()) ;
      arcWeights(orig->arcWeights()) ;
      untransPenalty(orig->untransPenalty()) ;
      lenBonus(orig->lenBonus()) ;
      docContext(orig->docContext()) ;
      sentContext(orig->sentContext()) ;
      phraseContext(orig->phraseContext()) ;
      chunkingBonus(orig->m_chunkbonus) ;
      }
   else
      {
      for (size_t i = 0 ; i < MAX_USER_SCORES ; i++)
	 m_userscores[i] = 0.0 ;
      arcScores(0.0) ;
      arcQualities(0.0) ;
      arcWeights(0.0) ;
      untransPenalty(0.0) ;
      lenBonus(0.0) ;
      docContext(0.0) ;
      sentContext(0.0) ;
      phraseContext(0.0) ;
      chunkingBonus(0.0) ;
      }
   return ;
}

/************************************************************************/
/*    Methods for class BFSNode						*/
/************************************************************************/

BFSNode::BFSNode(ParseChart *parsechart)
{
   assertq(parsechart != 0) ;
   setLeft(0) ;
   setRight(0) ;
   chart = parsechart ;
   m_coverage = OOV_count = m_nulltrans = 0 ;
   numarcs = 0 ;
   setActiveArc(~0) ;
   m_bytecover = 0 ;
   m_bytelength = 0 ;
   allocCovered() ;
   arcs = 0 ;
   m_numwords = 0 ;
   m_twordalloc = 0 ;
   num_gap_markers = 0 ;
   num_gaps_filled = 0 ;
   num_gaps_discarded = 0 ;
   arc_reorderings = 0 ;
   _score = m_ngramfrac = 0.0 ;
   m_scoreinfo = 0 ;
   initScoreInfo() ;
   m_modelstates.setAllocator(chart->models(),max_ngram_length) ;
   initHistories(chart->models(),max_ngram_length) ;
   m_ovrbonus = 0.0 ;
   m_prob = 0.0 ;
   m_featweight = 0.0 ;
   allocTargetWords() ;
   return ;
}

//----------------------------------------------------------------------

void BFSNode::initScoreInfo(bool force)
{
   if (!m_scoreinfo &&(show_raw_scores || force))
      m_scoreinfo = new BFSScoreInfo ;
   return ;
}

//----------------------------------------------------------------------

void BFSNode::initHistories(LmNGramModel **models,size_t max_hist)
{
   (void)new (&m_modelstates) LmNGramStates(models,max_hist) ;
   return ;
}

//----------------------------------------------------------------------

void BFSNode::copyNodeInfo(BFSNode *dest, const BFSNode *oldnode)
{
   dest->m_prob = oldnode->probability() ;
   dest->m_featweight = oldnode->extraFeatureScore() ;
   dest->m_ovrbonus = oldnode->overlapBonus() ;
   dest->m_ngramfrac = oldnode->ngramFraction() ;
   dest->_score = oldnode->_score ;
   dest->chart = oldnode->chart ;
   dest->m_numwords = oldnode->outputLength() ;
   dest->m_coverage = oldnode->inputCoverage() ;
   dest->numarcs = (LmUSHORT)(oldnode->numarcs + 1) ;
   dest->OOV_count = oldnode->OOV_count ;
   dest->m_nulltrans = oldnode->m_nulltrans ;
   dest->arc_reorderings = oldnode->arc_reorderings ;
   dest->setActiveArc(oldnode->activeArc()) ;
   dest->m_bytecover = (LmUSHORT)oldnode->byteCover() ;
   dest->m_bytelength = (LmUSHORT)oldnode->byteLength() ;
   dest->num_gap_markers = oldnode->num_gap_markers ;
   dest->num_gaps_filled = oldnode->num_gaps_filled ;
   dest->num_gaps_discarded = oldnode->num_gaps_discarded ;
   (void)new (&dest->m_modelstates) LmNGramStates(&oldnode->m_modelstates) ;
   if (oldnode->m_scoreinfo)
      dest->m_scoreinfo = new BFSScoreInfo(oldnode->m_scoreinfo) ;
   else
      dest->m_scoreinfo = 0 ;
   dest->words = 0 ;
   dest->arcs = 0 ;
   dest->allocCovered(oldnode->coveredInput()) ;
   dest->setLeft(0) ;
   dest->setRight(0) ;
   return ;
}

//----------------------------------------------------------------------

BFSNode::BFSNode(const BFSNode *oldnode)
{
   copyNodeInfo(this,oldnode) ;
   allocTargetWords() ;
   if (words)
      {
      for (size_t i = 0 ; i < outputLength() ; i++)
	 words[i].init(oldnode->words[i]) ;
      }
   usedArcs(oldnode,0,0,0) ;
   return ;
}

//----------------------------------------------------------------------

void BFSNode::updateActiveArc(size_t last_target)
{
   NTRACE(19,(cout<<"updateActiveArc()\n")) ;
   // the new active arc is the one with the right-most start in the target
   //   and (in case of tie) the shortest nonzero target-side length
   size_t where ;
   if (numArcs() == 0)
      where = ~0 ;		// need to use initial arc
   else
      {
      size_t last_trg = last_target ;
      size_t last_len = ~0 ;
      where = ~0 ;
      for (size_t arcnum = 0 ; arcnum < numArcs() ; arcnum++)
	 {
	 size_t tpos = arcs[arcnum].targetPosition() ;
	 if (tpos >= last_trg)
	    {
	    const ChartArc *a = arcs[arcnum].arc() ;
	    if (!a)
	       continue ;
	    if (tpos > last_trg ||
		(tpos == last_trg && (a->arcLength() < last_len
				      || last_len == 0)))
	       {
	       where = arcnum ;
	       last_trg = tpos ;
	       last_len = a->arcLength() ;
	       }
	    }
	 }
      }
   setActiveArc(where) ;
   NTRACE(19,(cout<<"  ==> ",dumpActiveArc(cout))) ;
   return ;
}

//----------------------------------------------------------------------

bool BFSNode::nextActiveArc()
{
   if (numArcs() == 0)
      return false ;
   size_t active = activeArc() ;
   if (!arcs[active].arc())
      return false ;
   size_t tpos = arcs[active].targetPosition() ;
   size_t tlen = arcs[active].arc()->arcLength() ;
   size_t next = ~0 ;
   size_t nextlen = ~0 ;
   for (size_t arcnum = 0 ; arcnum < numArcs() ; arcnum++)
      {
      if (arcs[arcnum].targetPosition() == tpos && arcnum != active)
	 {
	 const ChartArc *a = arcs[arcnum].arc() ;
	 if (!a)
	    continue ;
	 size_t len = a->arcLength() ;
	 if (len > tlen && len < nextlen)
	    {
	    nextlen = len ;
	    next = arcnum ;
	    }
	 }
      }
   if (next != (size_t)~0)
      {
      setActiveArc(next) ;
      return true ;
      }
   // there aren't any longer arcs starting at the currently-active arc's
   //   target position, but if the active arc is subsumed within a composite
   //   arc, we should look at other arcs within that composite arc
   size_t targpos = 0 ;
   nextlen = ~0 ;
   next = ~0 ;
   for (size_t arcnum = 0 ; arcnum < numArcs() ; arcnum++)
      {
      const ChartArc *a = arcs[arcnum].arc() ;
      if (!a)
	 continue ;
      size_t pos = arcs[arcnum].targetPosition() ;
      if (pos < tpos && pos >= targpos)
	 {
	 size_t len = a->arcLength() ;
	 if (pos > targpos)
	    {
	    targpos = pos ;
	    nextlen = len ;
	    }
	 else // pos == targpos
	    {
	    if (len < nextlen)
	       {
	       nextlen = len ;
	       next = arcnum ;
	       }
	    }
	 }
      }
   if (next != (size_t)~0)
      {
      setActiveArc(next) ;
      return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

void BFSNode::adjustTargetPositions(size_t *map)
{
   if (map)
      {
      for (size_t i = 0 ; i < numArcs() ; i++)
	 {
	 size_t pos = arcs[i].targetPosition() ;
	 if (pos < outputLength())
	    arcs[i].setTargetPosition(map[pos]) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

void BFSNode::updateUserScores(const ChartArc *arc)
{
   if (arc->hasUserScores())
      {
      initScoreInfo(true) ;
      int arclen = arc->arcLength() ;
      for (size_t i = 0 ; i < MAX_USER_SCORES ; i++)
	 {
	 incrUserScore(i,arc->userScore(i) * arclen) ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

BFSNode::BFSNode(const BFSNode *oldnode, size_t newcover, size_t wordcount,
		 const ChartArc *new_arc, const ParseChart *chart,
		 size_t overlap)
{
   copyNodeInfo(this,oldnode) ;
   m_coverage = (LmUSHORT)newcover ;
   m_numwords = (LmUSHORT)wordcount ;
   allocTargetWords() ;
   if (words && new_arc)
      {
      new_arc->updateInputCover(coveredInputMod(),m_bytecover,
				chart->wordBoundaries());
      updateUserScores(new_arc) ;
      size_t prev = oldnode->outputLength() ;
      size_t new_start = (prev > overlap) ? prev - overlap : 0 ;
      size_t new_end = new_start + new_arc->arcLength() ;
      // copy over the words from the previous node and the new arc, making
      //   appropriate adjustments
      LmMergeTargetWords(words,wordcount,oldnode->wordList(),prev,
			 new_arc->targetWordStats(),new_start,new_end,
			 this,OOV_count) ;
      usedArcs(oldnode,new_arc,overlap,new_start) ;
      }
   return ;
}

//----------------------------------------------------------------------

BFSNode::~BFSNode()
{
   freeTargetWords() ;
   freeCovered() ; 
   FrFree(arcs) ;		arcs = 0 ;
   delete m_scoreinfo ; 	m_scoreinfo = 0 ;
   m_coverage = 0 ;
   m_bytecover = 0 ;
   m_numwords = 0 ;
   m_bytelength = 0 ;
   _score = -999.9 ;
   return ;
}

//----------------------------------------------------------------------

size_t BFSNode::inputLength() const
{
   return chart->numWordBoundaries() ;
}

//----------------------------------------------------------------------

bool BFSNode::inTree(const BFSNode *node) const
{
   if (this == 0)
      return false ;
   if (this == node || ((BFSNode*)left())->inTree(node) ||
       ((BFSNode*)right())->inTree(node))
      return true ;
   return false ;
}

//----------------------------------------------------------------------

void BFSNode::showUsedArcs(ostream &out) const
{
   out << "used arcs:" ;
   if (numArcs() == 0) out << " none" ;
   out << endl ;
   for (size_t i = 0 ; i < numArcs() ; i++)
      {
      const ChartArc *arc = arcs[i].arc() ;
      const char *target = arc->targetText() ;
      if (!target)
	 target = "<null>" ;
      out << (arcs[i].subsumed() ? "< " : "  ")
	  << setw(3) << arc->startPosition()
	  << '-' << arc->endPosition() << '@' << arcs[i].targetPosition()
	  << ((i == activeArc()) ? '*' : ':')
          << '\t' << arc->sourceText() << " ==> " << target << endl ;
      }
   out << flush ;
   return ;
}

//----------------------------------------------------------------------

void BFSNode::showUsedArcs() const
{
   showUsedArcs(cout) ;
   return ;
}

//----------------------------------------------------------------------

void BFSNode::showCoverage(ostream &out) const
{
   out << "coverage: " ;
   size_t len = inputLength() ;
   const ChartArc *act = lastArcUsed() ;
   size_t src_pos = chart->wordIndex(act->startPosition()) ;
   size_t src_end = chart->wordIndex(act->pastEndPosition()) ;
   for (size_t j = 0 ; j < len ; j++)
      {
      char cov = (j >= src_pos && j < src_end) ? '#' : '*' ;
      out << (inputCovered(j) ? cov : '.') ;
      }
   out << " act=" << activeArc()  << '@' << src_pos << "/" << numArcs()
       << " cov=" << inputCoverage() << "/" << byteCover()
       << ", sc=" << score() << ", gp=" << gapMarkers() << endl ;
   return ;
}

//----------------------------------------------------------------------

void BFSNode::showCoverage() const
{
   showCoverage(cout) ;
   return ;
}

//----------------------------------------------------------------------

bool BFSNode::newCoverAllocator(size_t input_length)
{
   delete cover_allocator ;
   size_t num_entries
      = (input_length + LM_BITS_PER_ENTRY - 1) / LM_BITS_PER_ENTRY ;
   cover_allocator = new FrAllocator("BFSNode coverage",
				     num_entries*sizeof(LmBitFlags)) ;
   return (cover_allocator != 0) ;
}

//----------------------------------------------------------------------

void BFSNode::deleteCoverAllocator()
{
   delete cover_allocator ;
   cover_allocator = 0 ;
   return ;
}

//----------------------------------------------------------------------

bool BFSNode::newWordAllocators()
{
   deleteWordAllocators() ;
   word_allocators = FrNewC(FrAllocator*,WORD_ALLOC_BINS) ;
   if (word_allocators)
      {
      for (size_t i = 0 ; i < WORD_ALLOC_BINS ; i++)
	 {
	 char *name = Fr_aprintf("targetwords%2d",(int)(i+1)) ;
	 word_allocators[i]
	    = new FrAllocator(name,
			      (i+1)*WORD_ALLOC_STEP*sizeof(TargetWordRef)) ;
	 FrFree(name) ;
	 if (!word_allocators[i])
	    {
	    deleteWordAllocators() ;
	    return false ;
	    }
	 }
      }
   return (word_allocators != 0) ;
}

//----------------------------------------------------------------------

void BFSNode::deleteWordAllocators()
{
   if (word_allocators)
      {
      for (size_t i = 0 ; i < WORD_ALLOC_BINS ; i++)
	 delete word_allocators[i] ;
      FrFree(word_allocators) ;
      word_allocators = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

static int compare_arc_position(const ChartArc *arc1,
				const ChartArc *arc2)
{
   assertq(arc1 != 0) ;
   assertq(arc2 != 0) ;
   size_t start1 = arc1->startPosition() ;
   size_t start2 = arc2->startPosition() ;
   if (start1 < start2)
      return -1 ;
   else if (start1 > start2)
      return +1 ;
   size_t wc1 = arc1->sourceWordCount() ;
   size_t wc2 = arc2->sourceWordCount() ;
   if (wc1 < wc2)
      return -1 ;
   else if (wc1 > wc2)
      return +1 ;
   size_t cover1 = arc1->coverage() ;
   size_t cover2 = arc2->coverage() ;
   if (cover1 < cover2)
      return -1 ;
   else if (cover1 > cover2)
      return +1 ;
   return 0 ;				// arcs are equiv for sort order
}

//----------------------------------------------------------------------

void BFSNode::usedArcs(const BFSNode *prev_node, const ChartArc *arc,
		       size_t overlap, size_t trgpos)
{
   size_t new_numarcs = numArcs() ;
   if (arc)
      new_numarcs += arc->numSubsumedArcs() ;
   arcs = FrNewN(ComponentArcInfo,new_numarcs) ;
   if (arcs)
      {
      size_t count = prev_node->numArcs() ;
      if (arc)
	 {
	 const ComponentArcInfo *prev_arcs =  prev_node->usedArcs() ;
	 // we need to keep the component arcs sorted by starting position
	 //   in the input, so scan until we find the proper insertion point,
	 //   copying as we scan and shifting up any arcs after that point
	 size_t where = count ;
	 for (size_t i = 0 ; i < prev_node->numArcs() ; i++)
	    {
	    if (compare_arc_position(prev_arcs[i].arc(),arc) > 0)
	       {
	       where = i ;
	       // copy the rest of the previous node's arcs, leaving a gap
	       memcpy(arcs+i+1,prev_arcs+i,sizeof(ComponentArcInfo)*(count-i));
	       break ;
	       }
	    else
	       arcs[i] = prev_arcs[i] ;
	    }
	 if (overlap > (size_t)arc->arcLength())
	    overlap = 0 ;
	 new (&arcs[where]) ComponentArcInfo(arc,overlap,trgpos) ;
	 count++ ;
	 const ComponentArcInfo *subsumed = arc->subsumedArcs() ;
	 if (subsumed)
	    {
	    NVTRACE(8,(cout<<"adding subsumed arcs to used arcs"<<endl)) ;
	    for (size_t s = 0 ; s < arc->numSubsumedArcs() ; s++)
	       {
	       where = 0 ;
	       for (size_t i = count ; i > 0 ; i--)
		  {
		  if (compare_arc_position(arcs[i-1].arc(),
					   subsumed[s].arc()) <= 0)
		     {
		     where = i ;
		     break ;
		     }
		  arcs[i] = arcs[i-1] ;
		  }
	       count++ ;
	       if (overlap > (size_t)arc->arcLength())
		  overlap = 0 ;
	       size_t trgoff = subsumed[s].targetPosition() ;
	       new (&arcs[where]) ComponentArcInfo(subsumed[s].arc(),
						   overlap,trgpos+trgoff,
						   subsumed[s].subsumed());
	       }
	    }
	 numarcs = (LmUSHORT)count ;
	 updateActiveArc(trgpos) ;
	 }
      else
	 {
	 memcpy(arcs,prev_node->usedArcs(),sizeof(ComponentArcInfo)*count) ;
	 numarcs = (LmUSHORT)count ;
	 }
      }
   return ;
}

//----------------------------------------------------------------------

FrSymbol *BFSNode::outputWord(size_t N) const
{
   return (FrSymbol*)words[N].name() ; 
}

//----------------------------------------------------------------------

const ChartArc *BFSNode::lastArcUsed() const
{
   if (numArcs() == 0 || activeArc() > numArcs())
      return chart->initialArc() ;
   else
      return arcs[activeArc()].arc() ;
}

//----------------------------------------------------------------------

size_t BFSNode::lastArcPosition() const
{
   if (numArcs() == 0 || activeArc() > numArcs())
      return 0 ;
   else
      return arcs[activeArc()].targetPosition() ;
}

//----------------------------------------------------------------------

size_t BFSNode::lastArcEnd() const
{
   if (numArcs() == 0 || activeArc() > numArcs())
      return 0 ;
   else
      {
      ComponentArcInfo *arc = &arcs[activeArc()] ;
      return arc->targetPosition() + arc->arc()->arcLength() ;
      }
}

//----------------------------------------------------------------------

bool BFSNode::lastArcSubsumed() const
{
   if (numArcs() == 0 || activeArc() > numArcs())
      return false ;
   else
      return arcs[activeArc()].subsumed() ;
}

//----------------------------------------------------------------------

size_t BFSNode::gapInCoverage() const
{
   // if any words after the position indicated by the number of input
   //   words covered by the node are covered, that means some word prior
   //   to that position is NOT covered and therefore we have a gap
   size_t last = inputLength() ;
   if (inputCoverage() + max_reorder_window < last)
      last = inputCoverage() + max_reorder_window ;
   size_t gapsize = 0 ;
   const LmBitFlags *cov = coveredInput() ;
   for (size_t i = inputCoverage() ; i < last ; i++)
      {
      if (LmGetBit(cov,i))
	 gapsize++ ;
      }
   return gapsize ;
}

//----------------------------------------------------------------------

size_t BFSNode::futureReordering() const
{
   // compute by how many positions we need to reorder future gap fillers
   size_t last = 0 ;
   const LmBitFlags *cov = coveredInput() ;
   for (size_t i = inputLength() ; i > 0 ; i--)
      {
      if (LmGetBit(cov,i-1))
	 {
	 last = i - 1 ;
	 break ;
	 }
      }
   size_t reorders = 0 ;
   if (last > inputCoverage())
      {
      // we have gaps, so now find them
      int lastpos = last ;
      for (int i = 0 ; i < (int)last ; i++)
	 {
	 if (!LmGetBit(cov,i))
	    {
	    // assume minimum required reordering: an initial jump back
	    //   followed by successive minimal jumps forward
	    reorders += abs(lastpos - i) ;
	    lastpos = i + 1 ;
	    }
	 }
      if (lastpos < (int)last)
	 reorders += (last - lastpos) ;	// need one more jump to get back
      }
   return reorders ;
}

//----------------------------------------------------------------------

bool BFSNode::isQuestion() const
{
   if (!question_particle_hack || !arcs)
      return false ;
   // have we used the question particle in the walk?
   for (size_t i = 0 ; i < numArcs() ; i++)
      {
      if (arcs[i].arc() && arcs[i].arc()->isQuestion())
	 return true ;
      }
   return false ;
}

//----------------------------------------------------------------------

bool BFSNode::removeGapMarkers(bool force)
{
   size_t dest = 0 ;
   bool no_embedded = true ;
   FrLocalAlloc(size_t,map,512,outputLength()+1) ;
   if (!map)
      {
      FrNoMemory("while allocating position map") ;
      return false ;
      }
   for (size_t i = 0 ; i < dest ; i++)
      {
      map[i] = i ;
      }
   for (size_t i = dest ; i < outputLength() ; i++)
      {
      map[i] = dest ;
      TargetWord *word = words[i].targetWord() ;
      if (!word)			// an optional context marker or
	 {				//   question particle may be missing
	 continue ;
	 }
      if (word->isGapMarker())
	 {
	 if (word->isEmbeddedGapMarker())
	    no_embedded = false ;
	 const ChartArc *arc = word->sourceArc() ;
	 if (!arc)
	    {
	    decrGapMarkers() ;
	    gapDiscarded() ;
	    continue ;
	    }
	 if (inputCovered(word->gapFillerLocation()))
	    {
	    NVTRACE(23,(cout<< "removed gap marker " << word->name() << " @ "
			<< i << endl)) ;
	    // it's a gap marker that's been covered elsewhere, so skip it
	    decrGapMarkers() ;
	    }
	 else if (force)
	    {
	    NVTRACE(23,(cout<< "discarded gap marker " << word->name() << " @ "
			<< i << endl)) ;
	    decrGapMarkers() ;
	    gapDiscarded() ;
	    }
	 else
	    {
	    words[dest].init(words[i]) ;
	    if (!no_embedded)
	       words[dest].invalidateProbability() ;
	    dest++ ;
	    }
	 }
      else if (dest == i)
	 dest++ ;			// no gaps yet, just advance ptr
      else
	 {
	 words[dest].init(words[i]) ;
	 if (!no_embedded)
	    words[dest].invalidateProbability() ;
	 dest++ ;
	 }
      word->removeReference() ;		// original copy no longer referenced
      }
   for (size_t i = dest ; i < outputLength() ; i++)
      words[i].init(0,1) ;
   m_numwords = (LmUSHORT)dest ;
   adjustTargetPositions(map) ;
   FrLocalFree(map) ;
   return no_embedded ;
}

//----------------------------------------------------------------------

static double ratio_mismatch(size_t input_len, size_t output_len)
{
   double expected = average_length_ratio * input_len ;
   double ratio ;
   if (output_len == 0)
      ratio = (expected + 0.5) / 0.5 ;
   else if (output_len <= expected)
      ratio = (expected / output_len) ;
   else if (expected > 0)
      ratio = (output_len / expected) ;
   else
      ratio = 1.0 ;
   return ratio - 1.0 ;
}

//----------------------------------------------------------------------

void BFSNode::setDiscountedScore()
{
   size_t input_cover ;
   size_t input_len ;
   double v_pen ;
   size_t output_words = moses_style_scoring ? 1 : outputLength() ;
   if (use_byte_lengths)
      {
      input_len = chart->chartLength() ;
      input_cover = byteCover() ;
      v_pen = length_mismatch_penalty_base * ratio_mismatch(input_cover,
							    byteLength()) ;
      }
   else
      {
      input_len = inputLength() ;
      input_cover = inputCoverage() ;
      v_pen = length_mismatch_penalty_base * ratio_mismatch(input_cover,
							    output_words) ;
      }
   if (output_words < 1)
      output_words = 1 ;
   double reord = (moses_style_scoring
		   ? arcReorderings()
		   : LmNGramModel::log(1+arcReorderings())) ;
   double r_pen = reordering_penalty * reord ;
   double o_pen = (OOV_penalty * LmNGramModel::log(1+OOV_count)) ;
   double i_pen = (interleave_penalty *
		   LmNGramModel::log(1.0+gapsFilled()+gapsDiscarded())) ;
   double remaining_words = ((inputLength() - inputCoverage())
			     * average_length_ratio) ;
   if (remaining_words < 1.0)
      remaining_words = 1.0 ;

   double future ;
   if (moses_style_scoring)
      future = futureUtilityMoses();
   else
      future = (futureUtility()
		- (reordering_penalty / remaining_words *
		   LmNGramModel::log(1+futureReordering()))) ;

   _score = ((rawScore() + overlapBonus()) / output_words) ;
   _score += ngram_length_bonus * LmNGramModel::log(1.0 + ngramFraction()) ;
   _score += weightof_future * future ;
   if (moses_style_scoring)
      {
      _score -= r_pen ;
      _score -= o_pen + i_pen;
      _score -= length_mismatch_penalty_base * (double)(outputLength()-1);
      }
   else
      {
      _score -= discount_by_proportion(r_pen,input_cover,input_len) ;
      _score -= discount_by_proportion(o_pen + i_pen,input_cover,input_len) ;
      _score -= discount_by_proportion(v_pen,input_cover,input_len,false) ;
      }
   NTRACE(15,(cerr << " node's score = " << _score << ", prob=" << probability()
	           << ", incover=" << input_cover << ", out=" << output_words
	           << ", v_pen=" << v_pen << ", r_pen=" << r_pen
	           << ", o_pen=" << o_pen << ", i_pen=" << i_pen
	           << ", xfeat=" << m_featweight
	           << ", ovrlp=" << overlapBonus() << ", fut=" << future
	           << endl)) ;
   if (m_scoreinfo)
      {
      double user_score = 0.0 ;
      for (size_t i = 0 ; i < MAX_USER_SCORES ; i++)
	 user_score += weightof_user[i] * userScore(i) ;
      _score += user_score / output_words ;
      }
   return ; 
}

//----------------------------------------------------------------------

bool BFSNode::allocCovered(const LmBitFlags *init)
{
   LmBitFlags *covered ;
   if (inputLength() <= CHAR_BIT * sizeof(LmBitFlags*))
      covered = (LmBitFlags*)&m_covered ;
   else
      {
      covered = m_covered = (LmBitFlags*)cover_allocator->allocate() ;
      if (!m_covered)
	 {
	 FrNoMemory("while allocating coverage map for search node") ;
	 return false ;
	 }
      }
   size_t entries = coverageEntries() ;
   if (init)
      {
      for (size_t i = 0 ; i < entries ; i++)
	 covered[i] = init[i] ;
      }
   else
      {
      for (size_t i = 0 ; i < entries ; i++)
	 covered[i] = 0 ;
      }
   return true ;
}

//----------------------------------------------------------------------

void BFSNode::freeCovered()
{
   if (inputLength() > CHAR_BIT * sizeof(LmBitFlags*) && m_covered)
      {
      cover_allocator->release(m_covered) ;
      m_covered = 0 ;
      }
   return ;
}

//----------------------------------------------------------------------

void BFSNode::allocTargetWords()
{
   m_twordalloc = outputLength() ;
   size_t bin = outputLength() / WORD_ALLOC_STEP ;
   if (bin < WORD_ALLOC_BINS)
      words = (TargetWordRef*)word_allocators[bin]->allocate() ;
   else
      words = FrNewN(TargetWordRef,outputLength()) ;
   return ;
}

//----------------------------------------------------------------------

void BFSNode::freeTargetWords()
{
   if (!words)
      return ;
   for (size_t i = 0 ; i < m_twordalloc ; i++)
      {
      TargetWord *tw = words[i].targetWord() ;
      if (tw) tw->removeReference() ;
      }
   size_t bin = m_twordalloc / WORD_ALLOC_STEP ;
   if (bin < WORD_ALLOC_BINS)
      word_allocators[bin]->release(words) ;
   else
      FrFree(words) ;
   m_twordalloc = 0 ;
   words = 0 ;
   return ;
}

//----------------------------------------------------------------------

bool BFSNode::complete() const
{
   return (inputCoverage() >= inputLength() && gapMarkers() == 0) ;
}

//----------------------------------------------------------------------

void *BFSNode::value() const
{
   int i ;
   int n_words = outputLength() ;
   while (n_words > 0 &&
	  words[n_words-1].targetWord() == chart->endSentence())
      {
      n_words-- ;   // drop trailing context cues
      }
   int len = n_words ;
   for (i = 0 ; i < n_words ; i++)
      {
      const FrSymbol *w = words[i].name() ;
      if (w)
	 {
	 const ChartArc *src_arc = words[i].sourceArc() ;
	 const char *pref = src_arc->targetPrefix() ;
	 const char *suff = src_arc->targetSuffix() ;
	 const char *wordstr ;
	 bool copy = false ;
	 if (w == symEPSILON)
	    {
	    wordstr = epsilon_arc_contents ;
	    if (!wordstr || !*wordstr)
	       pref = suff = 0 ;
	    else if (*wordstr == '=' && wordstr[1] == '\0')
	       {
	       if (src_arc->sourceWordSpan() == 1)
		  wordstr = src_arc->sourceWordInfo()->surface() ;
	       if (src_arc->sourceWordSpan() > 1 || !wordstr)
		  {
		  // grab the original source text from the lattice
		  if (chart)
		     {
		     wordstr = chart->sourceText(src_arc) ;
		     copy = true ;
		     }
		  }
	       }
	    }
	 else
	    wordstr = w->symbolName() ;
         len += strlen(wordstr) ;
	 if (copy)
	    FrFree((char*)wordstr) ;
	 if (pref)
	    len += strlen(pref) ;
	 if (suff)
	    len += strlen(suff) ;
	 }
      }
   char *string = FrNewN(char,len+1) ;
   if (!string)
      FrNoMemory("allocating string in BFSNode::value") ;
   char *s = string ;
   for (i = 0 ; i < n_words ; i++)
      {
      const FrSymbol *w = words[i].name() ;
      if (w)
         {
	 const ChartArc *src_arc = words[i].sourceArc() ;
	 const char *pref = src_arc->targetPrefix() ;
	 const char *suff = src_arc->targetSuffix() ;
	 const char *wordstr ;
	 bool copy = false ;
	 if (w == symEPSILON)
	    {
	    wordstr = epsilon_arc_contents ;
	    if (!wordstr || !*wordstr)
	       pref = suff = 0 ;
	    else if (*wordstr == '=' && wordstr[1] == '\0')
	       {
	       if (src_arc->sourceWordSpan() == 1)
		  wordstr = src_arc->sourceWordInfo()->surface() ;
	       if (src_arc->sourceWordSpan() > 1 || !wordstr)
		  {
		  // grab the original source text from the lattice
		  if (chart)
		     {
		     wordstr = chart->sourceText(src_arc) ;
		     copy = true ;
		     }
		  }
	       }
	    }
	 else
	    wordstr = w->symbolName() ;
	 if (pref)
	    {
	    strcpy(s,pref) ;
	    s = strchr(s,'\0') ;
	    }
         strcpy(s,wordstr) ;
         s = strchr(s,'\0') ;
	 if (suff)
	    {
	    strcpy(s,suff) ;
	    s = strchr(s,'\0') ;
	    }
	 if (i+1 < n_words)
	    *s++ = ' ' ;
	 if (copy)
	    FrFree((char*)wordstr) ;
         }
      }
   *s = '\0' ;
   return new FrString(string,len,sizeof(char),false) ;
}

//----------------------------------------------------------------------

void *BFSNode::optionalInfo() const
{
   if (generate_chart || show_origins || !run_LM_quietly)
      {
      size_t outlen = outputLength() ;
      if (outlen > 0 && words[outlen-1].targetWord() == chart->endSentence())
	 outlen-- ;  // don't output the end-of-sentence marker
      TargetWordList *twl = new TargetWordList(words,outlen,chart->models()) ;
      if (twl)
	 twl->addArcs(usedArcs(),numArcs()) ;
      return twl ;
      }
   else
      return 0 ;
}

//----------------------------------------------------------------------

static void push_score(const char *name, double val, double scale,
		       FrList *&scores)
{
   for (const FrList *skip = skip_raw_scores ; skip ; skip = skip->rest())
      {
      const char *skipname = FrPrintableName(skip->first()) ;
      if (skipname && Fr_stricmp(skipname,name) == 0)
	 return ;
      }
   bool invert_MER_score = false ;
   if (raw_scores_in_CMERT_format) invert_MER_score = true ;
   if (invert_MER_score)
      val = -val ;
   pushlist(new FrList(makeSymbol(name),
		       new FrFloat(val),
		       new FrFloat(scale * val)),
	    scores) ;
   return ;
}

//----------------------------------------------------------------------

FrList *BFSNode::scoreInfo() const
{
   if (show_raw_scores)
      {
      double ratio ;
      size_t o_words = moses_style_scoring ? 1 : outputLength() ;
      if (moses_style_scoring)
	 ratio = (double)(outputLength()-1) ;
      else if (use_byte_lengths)
	 ratio = ratio_mismatch(byteCover(),byteLength()) ;
      else
	 ratio = ratio_mismatch(inputCoverage(),o_words) ;
      if (o_words < 1)
	 o_words = 1 ;
      double ovrbonus = overlapBonus() / o_words ; 
      if (overlap_bonus) ovrbonus /= overlap_bonus ;
      double ngfrac = 1.0 + ngramFraction() ;
      double arcweights = m_scoreinfo ? m_scoreinfo->arcWeights() : 0.0 ;
      double lmprob = probability() ;
      if (LM_scale_factor != 0.0)
	 lmprob /= LM_scale_factor ;
      FrList *scores = 0 ;
      for (size_t i = MAX_USER_SCORES ; i > 0 ; i--)
	 {
	 char *name = Fr_aprintf("WeightOf-User%lu",(unsigned long)i) ;
	 push_score(name,-userScore(i-1) / o_words,
		    weightof_user[i-1],scores) ;
	 FrFree(name) ;
	 }
      double reord = (moses_style_scoring
		      ? arcReorderings()
		      : LmNGramModel::log(1.0+arcReorderings())) ;
      push_score("WeightOf-Untranslated",-untranslatedPenalty() / o_words,
		 weightof_untrans,scores) ;
      push_score("OOV-Penalty",LmNGramModel::log(1+OOV_count),
		 OOV_penalty,scores) ;
      push_score("Interleave-Penalty",LmNGramModel::log(1.0+gapsFilled()+
							gapsDiscarded()),
		 interleave_penalty,scores) ;
      push_score("Reorder-Penalty",reord,reordering_penalty,scores) ;
      push_score("Verbosity-Penalty",ratio,
		 length_mismatch_penalty_base,scores) ;
      push_score("Overlap-Bonus",(-ovrbonus),overlap_bonus,scores) ;
      push_score("WeightOf-PhrContext",-phraseContext(),
		 weightof_phrcontext, scores) ;
      push_score("WeightOf-SntContext",-sentContext(),
		 weightof_sntcontext, scores) ;
      push_score("WeightOf-DocContext",-docContext(),
		 weightof_doccontext, scores) ;
      push_score("WeightOf-Chunking",(-chunkingBonus() / o_words),
		 weightof_chunking,scores) ;
      push_score("WeightOf-Quality",(-arcQualities() / o_words),
		 weightof_quality,scores) ;
      push_score("WeightOf-Score",(-arcScores() / o_words),
		 weightof_score,scores) ;
      push_score("WeightOf-LengthBonus",(-lengthBonus() / o_words),
		 weightof_lengthbonus,scores) ;
      push_score("WeightOf-ArcWeight",(-arcweights / o_words),
		 weightof_arcweight,scores) ;
      push_score("WeightOf-NGramLength",(-LmNGramModel::log(ngfrac)),
		 ngram_length_bonus,scores) ;
      push_score("LM-Scale-Factor",(-lmprob / o_words),
		 LM_scale_factor,scores) ;

#if 0 //DEBUG
      double total_score = 0.0 ;
      for (const FrList *sc = scores ; sc ; sc = sc->rest())
	 {
	 const FrList *s = (const FrList*)sc->first() ;
	 total_score += s->third()->floatValue() ;
	 }
//      push_score("Total-Score", total_score, 1.0, scores) ;
//      push_score("Node-Score", score(), 1.0, scores) ;
if (fabs(total_score+score()) > 1e-10)cout<<"total="<<-total_score<<", but node score="<<score()<<endl<<scores<<endl;
//cout<<scores<<endl;
#endif
      return scores ;
      }
   else
      return 0 ;
}

//----------------------------------------------------------------------
// SEE ALSO: no_worse_node in lmtreap.C

int BFSNode::compareNode(const BFSNode *node) const
{
   size_t n = outputLength() ;
   size_t n2 = node->outputLength() ;
   size_t reach = LM_reach ;
   if (n < n2)				// check whether output is same length
      return -1 ;			// since that affects verbosity penalty
   else if (n > n2)
      return +1 ;
   else if (n == 0)
      return 0 ;			// no output words, thus duplicates
   if (n < reach || (complete() && node->complete()))
      reach = n ;			// complete nodes don't use LM any more
   for (size_t i = 1 ; i <= reach ; i++)
      {
      const TargetWord *w1 = words[n-i].targetWord() ;
      const TargetWord *w2 = node->words[n2-i].targetWord() ;
      // note: we can compare just pointers because we have used symbols, which
      //  are unique, merging duplicate words into one object
      if ((uintptr_t)w1->name() < (uintptr_t)w2->name())
	 return -1 ;
      else if ((uintptr_t)w1->name() > (uintptr_t)w2->name())
	 return +1 ;
      }
   if (!complete() || !node->complete())
      {
      // OK, trailing words that can still affect the LM score are the same, so
      //   now double-check that we are covering the same portion of the input
      const LmBitFlags *c1 = coveredInput() ;
      const LmBitFlags *c2 = node->coveredInput() ;
      assertq(c1 && c2) ;
      size_t ent = coverageEntries() ;
      for (size_t j = 0 ; j < ent ; j++)
	 {
	 if (c1[j] < c2[j])
	    return -1 ;
	 else if (c1[j] > c2[j])
	    return +1 ;
	 }
      // if the coverage is the same, check the other bonus and penalty factors
      //   that affect the overall score of a path
#if 0
      if (reordering_penalty)
	 {
	 size_t r1 = arcReorderings() ;
	 size_t r2 = node->arcReorderings() ;
	 if (r1 < r2)
	    return -1 ;
	 else if (r1 > r2)
	    return +1 ;
	 }
#endif /* 0 */
      }
   // if we got through all the above, the nodes are for all intents and
   //  purposes duplicates of each other
#ifndef NDEBUG
   if (trace > 12)
      {
      cout << "compareNode-" ;
      showCoverage() ;
      FrString *val1 = (FrString*)value() ;
      FrString *val2 = (FrString*)node->value() ;
      cout << "  --> " << val1 << " and " << val2 << " are duplicates" << endl;
      if (trace > 17 && verbose && usedArcs() && node->usedArcs())
	 {
	 cout << "Node1 (sc=" << score() << ", reord="
	      << arcReorderings() << ") arcs: " << endl ;
	 dumpArcs(cout) ;
	 cout << "Node2 (sc=" << node->score() << ", reord="
	      << node->arcReorderings() << ") arcs: " << endl ;
	 node->dumpArcs(cout) ;
	 }
      free_object(val1) ;
      free_object(val2) ;
      }
#endif /* !NDEBUG */
   return 0 ;				
}

//----------------------------------------------------------------------

#ifndef NDEBUG
static void show_new_node(BFSNode *newnode, double totalprob)
{
   cerr << "New: " ;
   int len = newnode->outputLength() ;
   const TargetWordRef *words = newnode->wordList() ;
   for (int wrd = 0 ; wrd < len ; wrd++)
      {
      const FrSymbol *w = words[wrd].name() ;
      cerr << (w ? w->symbolName() : "{}") << ' ' ;
      }
   cerr << "  rawsc=" << newnode->rawScore() << " totP=" << totalprob << endl ;
   return ;
}
#endif /* !NDEBUG */

//----------------------------------------------------------------------

bool BFSNode::canCoverRemainder() const
{
   // check whether this is a dead end in the search (so we don't bother
   //   putting it on a stack)
   size_t inputlen = inputLength() ;
   size_t first_uncov = inputlen ;
   size_t last_cov = 0 ;
   for (size_t i = 0 ; i < inputlen ; i++)
      {
      if (inputCovered(i))
	 last_cov = i ;
      else
	 {
	 first_uncov = i ;
	 break ;
	 }
      }
   size_t last_uncov = first_uncov ;
   for (size_t i = first_uncov ; i < inputlen ; i++)
      {
      if (inputCovered(i))
	 last_cov = i ;
      else // if (!inputCovered(i))
	 {
	 if (inputCovered(i+1))
	    last_uncov = i ;
	 }
      }
   size_t next = last_cov + 1 ;
   if (activeArc() < numArcs())
      {
      const ChartArc *arc = arcs[activeArc()].arc() ;
      if (arc)
	 {
	 size_t start = chart->wordIndex(arc->pastEndPosition()) ;
	 if (start < next)
	    next = start ;
	 }
      }
   NTRACE(19,(cout<<"canCoverRem(n="<<next<<",f="<<first_uncov 
	      <<",l="<<last_uncov<<",c="<<last_cov<<", ")) ;
   NTRACE(19,{for(size_t i=0;i<inputlen;i++) cout<<(inputCovered(i)?'*':'.');});
   if (first_uncov < last_cov)
      {
      if (next > last_uncov && next - last_uncov > max_reorder_window)
	 {
	 NTRACE(19,(cout<<") --> false (next/last)"<<endl)) ;
	 return false ;			// too big a jump to reach across
	 }
      if (last_cov >= last_uncov && last_cov - last_uncov >= max_reorder_window)
	 {
	 NTRACE(19,(cout<<") --> false (cov/uncov)"<<endl)) ;
	 return false ;			// too big a jump to reach across
	 }
      if (first_uncov > next && first_uncov - next > max_reorder_window)
	 {
	 NTRACE(19,(cout<<") --> false (next/first)"<<endl)) ;
	 return false ;			// can't jump that far forward
	 }
      if (reorder_window_is_uncovered)
	 {
	 // we can jump back arbitrarily far, but we can only jump forward by
	 //   the size of the reordering window, so check that there are gaps
	 //   sufficiently close together to actually be able to fill them all
	 if (last_uncov - first_uncov > max_reorder_window)
	    {
	    size_t span = 0 ;
	    for (size_t i = first_uncov + 1 ; i <= last_cov ; i++)
	       {
	       if (!inputCovered(i))
		  span = 0 ;
	       else if (++span >= max_reorder_window)
		  {
		  NTRACE(19,cout<<") --> false (span)"<<endl) ;
		  return false ;
		  }
	       }
	    if (span >= max_reorder_window)
	       {
	       NTRACE(19,cout<<") --> false (span)"<<endl) ;
	       return false ;
	       }
	    }
	 }
      else if (next > first_uncov && next - first_uncov > max_reorder_window)
	 {
	 NTRACE(19,cout<<") --> false (first/next)"<<endl) ;
	 return false ;			// too big a jump for reordering
	 }
      }
#if 0
   if (gapMarkers() > 0)
      {
      for (size_t i = 0 ; i < outputLength() ; i++)
	 {
	 // if this is a gap marker, check whether the source position it
	 //   expected to be filling the gap has already been covered
	 if (words[i]->isGapMarker() &&
	     inputCovered(words[i]->gapFillerLocation()))
	    return false ;
	 }
      }
#endif
   NTRACE(19,cout<<") --> true"<<endl) ;
   return true ;
}

//----------------------------------------------------------------------

bool BFSNode::arcAlreadyUsed(const ChartArc *arc) const
{
   if (arc && arcs)
      {
      size_t count = numArcs() ;
      size_t arc_start = arc->startPosition() ;
      // since the new arc will likely be near the end of the path built so
      //   far, and the already-used arcs are sorted by start position, scan
      //   the list in reverse order to minimize the work we do
      for (size_t i = count ; i > 0 ; i--)
	 {
	 const ChartArc *a = arcs[i-1].arc() ;
	 if (a == arc)
	    return true ;
	 else if (a->startPosition() < arc_start)
	    break ;
	 }
      }
   return false ;
}

//----------------------------------------------------------------------

static size_t count_matching_words(const TargetWordRef *node_words,
				   size_t num_node_words,
				   const TargetWordStats *trg_words,
				   size_t num_trg_words,
				   size_t start_offset
				   )
{
   (void)num_trg_words;
   size_t count = 0 ;
   for (size_t i = 0 ; i < num_node_words - start_offset ; i++)
      {
      if (!trg_words[i].targetWord())
	 continue ;
      if (node_words[i+start_offset].name()
	  == trg_words[i].targetWord()->name())
	 count++ ;
      else
	 break ;
      }
   return count ; 
}

//----------------------------------------------------------------------

size_t BFSNode::targetOverlap(const ChartArc *arc, size_t src_overlap) const
{
   if (arc)
      {
      size_t outlen = outputLength() ;
      size_t start = 0 ;
      if (outlen > (size_t)arc->arcLength())
	 start = outlen - arc->arcLength() ;
      if (src_overlap == 0)
	 {
	 // find the longest prefix of the next arc that matches a suffix
	 //   of the current arc
	 for (size_t i = start ; i < outlen ; i++)
	    {
	    if (count_matching_words(wordList(),outlen,arc->targetWordStats(),
				     arc->arcLength(),i) == outlen-i)
	       return outlen-i ;
	    }
	 }
      else
	 {
	 // find the amount of overlapping target text nearest in length to
	 //   the number of words overlapping in the source
	 size_t mindiff = ~0 ;
	 size_t closest = 0 ;
	 for (size_t i = start ; i < outlen ; i++)
	    {
	    if (count_matching_words(wordList(),outlen,arc->targetWordStats(),
				     arc->arcLength(),i) == outlen-i)
	       {
	       if (i < src_overlap && src_overlap-i < mindiff)
		  {
		  mindiff = src_overlap - i ;
		  closest = outlen - i ;
		  }
	       else if (i > src_overlap && i-src_overlap < mindiff)
		  {
		  mindiff = i - src_overlap ;
		  closest = outlen - i ;
		  }
	       }
	    }
	 return closest ;
	 }
      }
   return 0 ;
}

//----------------------------------------------------------------------

static size_t reorder_factor(const ChartArc *arc, size_t chartlength)
{
   size_t weight = 1  ;
   if (arc)
      {
      bool at_end = ((size_t)arc->endPosition() + 1) >= chartlength ;
      for (size_t i = 0 ; i < arc->sourceWordCount() ; i++)
	 {
	 const char *word = FrPrintableName(arc->sourceWord(i)) ;
	 size_t boost = (at_end ? reorder_punct_eos : reorder_punct) ;
	 if (word && *word && !word[1] && Fr_ispunct(word[0]))
	    weight += boost ;
	 }
      }
   return weight ;
}

//----------------------------------------------------------------------

double BFSNode::futureUtility()
{
   if (weightof_future == 0.0)
      return 0.0 ;
   double utility = 0.0 ;
   const ParseChart *chart = getParseChart() ;
   // convert the set of arcs which have been used in constructing this node
   //   into a conflict set
   LmConflicts *conflicts = new LmConflicts ;
   if (conflicts)
      {
      conflicts->init(0,chart->numArcs()) ;
      for (size_t i = 0 ; i < numArcs() ; i++)
	 {
	 size_t ID = arcs[i].arc()->arcID() ;
	 conflicts->addConflict(ID) ;
	 }
      }
   // scan down the source words which have not yet been covered and accumulate
   //   their future utility scores
   size_t num_words = 0 ;
   for (size_t i = 0 ; i < inputLength() ; i++)
      {
      if (!inputCovered(i))
	 {
	 utility += chart->bestUtility(i,conflicts) ;
	 num_words++ ;
	 }
      }
   delete conflicts ;
   if (num_words)
      return utility / num_words ;
   else
      return utility ;
}

//----------------------------------------------------------------------

double BFSNode::futureUtilityMoses()
{
   if (weightof_future == 0.0)
      return 0.0 ;
   double utility = 0.0 ;
   const ParseChart *chart = getParseChart() ;
   size_t start = ~0 ;
   for (size_t i = 0 ; i < inputLength() ; i++)
      {
      if (!inputCovered(i))
	 {
	 // get starting point of an un-covered segment
	 if (start == (size_t)~0)
	    start = i;
	 }
      else if (inputCovered(i) && start != (size_t)~0)
	 {
	 // get ending point of un-covered segment and compute future score
	 utility += chart->bestUtility(start,i-start) ;
	 start = ~0;
	 }
      }
   if (start != (size_t)~0)
      utility += chart->bestUtility(start,inputLength()-start) ;
   return utility ;
}

//----------------------------------------------------------------------
// IMPORTANT NOTE: needs to stay synchronized with ChartArc::setFutureUtility!

void BFSNode::updateNodeInfo(size_t prev_words,const ChartArc *arc,
			     size_t chartlength, size_t reorders, 
			     size_t src_overlap, size_t trg_overlap)
{
   if (allow_jigsaw_combination)
      {
      NVTRACE(12,(cout<<"call removeGapMarkers from updateNodeInfo"<<endl)) ;
      (void)removeGapMarkers() ;
      }
   int arclen = arc->arcLength() ;
   if (arclen)
      LmNgramScore(modelStates(),words,outputLength()) ;
   else
      m_nulltrans++ ;
   // accumulate total probability and average ngram-match
   double totalprob = m_nulltrans * nulltrans_logvalue * LM_scale_factor ;
   double avg_ngram = 0.0 ;
   size_t ovrcount = 0 ;
   for (size_t i = 0 ; i < outputLength() ; i++)
      {
      ovrcount += (words[i].coverage() - 1) ;
      if (words[i].name() != symEPSILON)
	 {
	 avg_ngram += words[i].avgNgram() ;
	 if (words[i].probabilityKnown())
	    {
	    totalprob += words[i].probability() ;
	    }
	 }
      }
   // figure out how many target words of the current arc actually count
   //   (performance tanks when epsilon arcs are given any nontrivial weight)
   size_t arc_start = (prev_words>trg_overlap) ? prev_words - trg_overlap : 0 ;
   size_t arc_end = arc_start + arclen ;
   double weight = 0.0 ;
   double score = 0.0 ;
   double quality = 0.0 ;
   double len_bonus = 0.0 ;
   double chunk_bonus = 0.0 ;
   double doccontext = 0.0 ;
   double sentcontext = 0.0 ;
   double phrcontext = 0.0 ;
   double untrans = 0.0 ;
   const TargetWordStats *arcwords = arc->targetWordStats() ;
   for (size_t i = arc_start ; i < arc_end ; i++)
      {
      if (words[i].name() != symEPSILON)
	 {
	 size_t arcpos = i - arc_start ;
	 weight += arcwords[arcpos].weight() ;
	 score += arcwords[arcpos].score() ;
	 quality += arcwords[arcpos].quality() ;
	 len_bonus += arcwords[arcpos].lengthBonus() ;
	 chunk_bonus += arcwords[arcpos].chunkingBonus() ;
	 doccontext += arcwords[arcpos].docContext() ;
	 sentcontext += arcwords[arcpos].sentContext() ;
	 phrcontext += arcwords[arcpos].phraseContext() ;
	 untrans += arcwords[arcpos].untransPenalty() ;
	 if (moses_style_scoring) break;
	 }
      }
   // update raw score totals, if appropriate
   if (m_scoreinfo)
      {
      m_scoreinfo->incrArcQualities(quality) ;
      m_scoreinfo->incrArcScores(score) ;
      m_scoreinfo->incrArcWeights(weight) ;
      m_scoreinfo->incrLenBonus(len_bonus); 
      m_scoreinfo->incrChunkingBonus(chunk_bonus) ;
      m_scoreinfo->incrDocContext(doccontext) ;
      m_scoreinfo->incrSentContext(sentcontext) ;
      m_scoreinfo->incrPhraseContext(phrcontext) ;
      m_scoreinfo->incrUntransPenalty(untrans) ;
      }
   // update overall scores
   m_prob = totalprob ;
   m_ngramfrac = outputLength() ? avg_ngram / outputLength() : 0.0 ;
   m_featweight += (weightof_arcweight * weight
		    + weightof_score * score
		    + weightof_quality * quality
		    + weightof_lengthbonus * len_bonus
		    + weightof_chunking * chunk_bonus
		    + weightof_doccontext * doccontext
		    + weightof_sntcontext * sentcontext
		    + weightof_phrcontext * phrcontext
		    + weightof_untrans * untrans) ;
   m_ovrbonus = overlap_bonus * ovrcount ;
   NTRACE(9,(cout << "ngramfrac="<<m_ngramfrac<<",ovrcount="<<ovrcount<<endl));
   if (src_overlap > 0)
      {
      INCR_STATS(overlap_expansions) ;
      }
   NTRACE(15,(show_new_node(this,totalprob))) ;
   if (reorders > 0)
      {
      INCR_STATS(reordered_expansions) ;
      arc_reorderings += (LmUSHORT)(reorders *
				    reorder_factor(arc,chartlength)) ;
      }
   setDiscountedScore() ;
   return ;
}

//----------------------------------------------------------------------

BFSNode *BFSNode::nconc(BFSNode *more)
{
   BFSNode *n = this ;
   if (!n)
      return more ;
   while (n->next())
      n = n->next() ;
   n->setNext(more) ;
   return this ;
}

//----------------------------------------------------------------------

BFSNode *BFSNode::makeExpandedNode(const ChartArc *arc,
				   const ParseChart *chart, size_t reorders,
				   size_t src_cover, size_t src_overlap,
				   size_t trg_overlap, BFSNode *nodes) const
{
   size_t arclen = (size_t)arc->arcLength() ;
   NVTRACE(7,if (arclen==0) cout << "***expanding with empty arc***"<<endl) ;
   size_t newcount = outputLength() ;
   if (trg_overlap < arclen)
      newcount += (arclen - trg_overlap) ;
   size_t newcover = inputCoverage() ;
   const LmBitFlags *cov = arc->sourceCover() ;
   if (cov)
      {
      size_t start = arc->chart()->wordIndex(arc->startPosition()) ;
      for (size_t i = 0 ; i < arc->sourceWordSpan() ; i++)
	 {
	 if (LmGetBit(cov,i) && !inputCovered(start+i))
	    newcover++ ;
	 }
      }
   else if (src_overlap <= src_cover)
      newcover += (src_cover - src_overlap) ;
   size_t chartlength = chart->numWordBoundaries() ;
   if (newcover >= chartlength) 	// will this be the final arc?
      {
      if (use_context_cues)
	 newcount++ ;			// add sentence-end symbol if done
      if (question_particle_hack)
	 newcount++ ;			// maybe also add a question mark
      }
   BFSNode *newnode = new BFSNode(this,newcover,newcount,arc,chart,
				  trg_overlap) ;
   if (!newnode || !newnode->good())
      {
      delete newnode ;
      return nodes ;			// oops, out of memory or something...
      }
   newnode->updateNodeInfo(outputLength(),arc,chartlength,
			   reorders,src_overlap,trg_overlap) ;
   NTRACE(8,newnode->showCoverage()) ;
   NVTRACE(15,newnode->showUsedArcs()) ;
   if (newnode->inputCoverage() <= inputCoverage())
      {
      NTRACE(9,(cout<<"added arc did not increase source cover"<<endl)) ;
      delete newnode ;
      INCR_STATS(never_inserted) ;
      return nodes ;
      }
   if (!newnode->canCoverRemainder())
      {
      NTRACE(9,(cout<<"unable to cover remainder"<<endl)) ;
      delete newnode ;
      INCR_STATS(unable_to_cover) ;
      return nodes ;
      }
   INCR_STATS(successful_expansions) ;
   // if the arc we're adding has any gaps, fill them in right now so that
   //   the partial-path scoring won't be messed up by the gap markers
   if (arc->hasGapMarkers())
      {
      BFSNode *newnodes ;
      static bool recursing = false ;
      if (!recursing)
	 {
	 NTRACE(12,(cout<<"starting recursive expansion"<<endl)) ;
	 recursing = true ;
	 newnodes = newnode->expand(true) ;
	 recursing = false ;
	 NTRACE(12,(cout<<"done with recursive expansion"<<endl)) ;
	 }
      else
	 newnodes = new BFSNode(newnode) ;
      nodes = newnodes->nconc(nodes) ;
      // also include a stripped version of the arc in the search, as though
      //   we were running without interleaving, if there are non-gaps and
      //   none of the gaps are embedded gaps from a structural match
      NVTRACE(12,(cout<<"call removeGapMarkers(true) from makeExpandedNode"<<endl)) ;
      if (newnode->removeGapMarkers(true) &&
	  newnode->outputLength() > outputLength())
	 {
	 newnode->setNext(nodes) ;
	 nodes = newnode ;
	 }
      else
	 delete newnode ;
      return nodes ;
      }
   newnode->setNext(nodes) ;
   return newnode ;
}

//----------------------------------------------------------------------

static ostream &operator << (ostream &output, const BFSNode *node)
{
   size_t len = node->outputLength() ;
   for (size_t i = 0 ; i < len ; i++)
      {
      output << node->outputWord(i) ;
      if (i+1 < len)
	 output << ' ' ;
      }
   return output ;
}

//----------------------------------------------------------------------

BFSNode *BFSNode::expand(bool must_fill_gap)
{
   bool try_filling_gaps = (gapMarkers() > 0) ;
   if (must_fill_gap && !try_filling_gaps)
      {
      NTRACE(9,cout<<"Not allowed to fill gap:"<<endl) ;
      NTRACE(9,showCoverage()) ;
      NVTRACE(15,showUsedArcs()) ;
      return 0 ;			// no further expansions
      }
   if (inputCoverage() >= chart->numWordBoundaries())
      {
      // can't expand any more because already at end of input, but we may
      //   still have some gaps that were never properly filled; if that's
      //   the case, we put ourself back into the search after removing the
      //   remaining markers
      if (gapMarkers() > 0)
	 {
	 NVTRACE(12,(cout<<"call removeGapMarkers(true) from expand"<<endl)) ;
	 removeGapMarkers(true) ;
	 return new BFSNode(this) ;
	 }
      return 0 ;			// no further expansions
      }
   INCR_STATS(total_nodes_expanded) ;
   size_t reorder_limit ;
   size_t inlen = chart->numWordBoundaries() ;
   if (reordering_limit >= 1.0)
      reorder_limit = (size_t)reordering_limit ;
   else
      reorder_limit = (size_t)((reordering_limit * inlen * max_reorder_window)
			       + 0.4) ;
   // make reordering much more expensive once we hit the specified limit
   size_t reorder_weight = (arcReorderings() < reorder_limit) ? 1 : 10 ;
   BFSNode *newnodes = 0 ;
   const ChartArc *lastarc = lastArcUsed() ;
   VTRACE(7,(cout<<"Expanding"<<(must_fill_gap?"(recursed) ":" ")<<this<<endl)) ;
   NTRACE(8,(cout<<"Before-",showCoverage())) ;
   NTRACE(9,showUsedArcs()) ;
   size_t trg_end = lastArcEnd() ;
   for (size_t i = 0 ; i < lastarc->numSuccessors() ; i++)
      {
      const ChartArcSuccessor *succ = lastarc->successor(i) ;
      if (!succ)
	 continue ;
      ChartArc *arc = succ->arc() ;
      NTRACE(15,(cout<<" successor="<<arc->startPosition()<<":\""<< \
		 arc->sourceText()<<" => \""<<arc<<"\" ")) ;
      if (arcAlreadyUsed(arc))
	 {
	 NTRACE(15,(cout<<" -- already used" << endl)) ;
	 continue ;			// don't re-use arcs
	 }
      if (must_fill_gap && !succ->fillsGap())
	 {
	 NVTRACE(15,(cout<<" -- doesn't fill gap" << endl)) ;
	 INCR_STATS(unfillable_gaps) ;
	 continue ;
	 }
      INCR_STATS(attempted_node_expansions) ;
      NVTRACE(18,(cout<<"  arc="<<arc->sourceWordSpan()<<'/'<<arc->arcLength()
		  <<" ("<<succ->reordering()<<")"));
      size_t src_overlap = succ->sourceOverlap() ;
      if (!arc->allowableArc(coveredInput(),src_overlap))
	 {
	 NTRACE(15,(cout<<" -- disallowed (dup source cover)"
		    " gap="<<(arc->hasGapMarkers()?'Y':'n')<<endl)) ;
	 NTRACE(17,(cout<<"   src_overlap="<<src_overlap<<"  "<<arc<<' '));
	 NTRACE(20,(cout<<"   base node:\n",dumpArcs(cout)))
	 INCR_STATS(expansion_collisions) ;
	 continue ;
	 }
      size_t trg_overlap = succ->targetOverlap() ;
      bool fills_gap = succ->fillsGap() ;
      if (trg_end < outputLength())
	 {
	 // ensure that if the arc being expanded is not the last thing in the
	 //   output, that the successor arc is compatible with any additional
	 //   words
	 size_t new_start = trg_end - trg_overlap ;
	 trg_overlap = outputLength() - new_start ;
	 size_t new_end = new_start + arc->arcLength() ;
	 if (new_end > outputLength())
	    new_end = outputLength() ;
	 bool compatible = true ;
	 for (size_t i = new_start ; i < new_end ; i++)
	    {
	    const TargetWord *tw1 = words[i].targetWord() ;
	    const TargetWord *tw2 = arc->targetWordInfo(i-new_start) ;
	    if (!LmCompatibleTargetWords(tw1,tw2))
	       {
	       compatible = false ;
	       break ;
	       }
	    else if (tw1->isGapMarker() && !tw2->isGapMarker())
	       fills_gap = true ;
	    }
	 if (!compatible)
	    {
	    NTRACE(15,(cout<<" -- disallowed (incompatible words in overlap)"
		       << endl)) ;
	    NTRACE(20,(cout<<"   base node:\n",dumpArcs(cout)))
	    INCR_STATS(expansion_collisions) ;
	    continue ;
	    }
	 }
      size_t cover = chart->boundaryCount(arc->startPosition(),
					  arc->endPosition()) + 1 ;
      size_t reorder_count = succ->reordering() * reorder_weight ;
      if (src_overlap == 0 && !must_fill_gap &&
	  ((trg_overlap >= arc->arcLength() && gapMarkers() > 0)
	   || trg_overlap > outputLength()))
	 {
	 NTRACE(17,(cout<<" [appending]"<<endl)) ;
	 // try a version that doesn't fill in the gap, but just appends
	 INCR_STATS(attempted_node_expansions) ;
	 newnodes = makeExpandedNode(arc,chart,reorder_count,cover,
				     src_overlap,0,newnodes) ;
	 }
      if (fills_gap)
	 {
	 INCR_STATS(interleaved_expansions) ;
	 NVTRACE(17,(cout<<" [filling gap]")) ;
	 }
      NTRACE(15,(cout<<", src_ov="<<src_overlap
		  <<", trg_ov="<<trg_overlap<<endl)) ;
      if (trg_overlap <= outputLength())
	 newnodes = makeExpandedNode(arc,chart,reorder_count,cover,
				     src_overlap,trg_overlap,newnodes) ;
      }
   VTRACE(8,(cout<<"Done expanding"<<(must_fill_gap?"(recursed) ":" ")<<this<<endl)) ;
   return newnodes ;
}

//----------------------------------------------------------------------

void BFSNode::dumpArcs(ostream &out) const
{
   for (size_t i = 0 ; i < numArcs() ; i++)
      dump_arc_info(out,usedArcs()[i].arc()) ;
   return ;
}

//----------------------------------------------------------------------

void BFSNode::dumpArcs() const
{
   dumpArcs(cout) ;
   return ;
}

//----------------------------------------------------------------------

void BFSNode::dumpActiveArc(ostream &out) const
{
   size_t active = activeArc() ;
   if (active < numArcs())
      dump_arc_info(out,usedArcs()[active].arc()) ;
   else
      out << "(no active arc)" << endl ;
   return ;
}

//----------------------------------------------------------------------

void BFSNode::dumpActiveArc() const
{
   dumpActiveArc(cout) ;
   return ;
}

/************************************************************************/
/*    Methods for class BestFirstSearch					*/
/************************************************************************/

BestFirstSearch::BestFirstSearch(BFSNode *startnode, size_t nbest_list_size)
{
   assertq(startnode != 0) ;
   m_totalnodes = nodes_expanded = 0 ;
   m_inputlength = startnode->inputLength() ;
   m_activestack = 0 ;
   m_substacks = 1 ;
   m_jigsawstacks = 1 ;
   if (use_multiple_stacks)
      {
      m_substacks = max_reorder_window ;
      if (m_substacks > MAX_REORDER_STACKS)
	 m_substacks = MAX_REORDER_STACKS ;
      }
   if (allow_jigsaw_combination)
      m_jigsawstacks = 2 ;
   size_t stacks = (m_substacks * m_jigsawstacks) ;
   m_queue = FrNewC(PriorityQueue*,totalStacks()+stacks+1) ;
   if (m_queue)
      {
      bool keep_pruned = (best_count>1 || beam_width < 40/stacks) ;
      for (size_t i = 0 ; i <= totalStacks() ; i++)
	 {
	 double cutoff = beam_ratio ;
	 // be very lenient for the first couple of words and don't prune
	 //   much, to avoid having to go back and restart the search
	 if (i < DISCOUNT_START * stacks && beam_ratio < 1000.0)
	    cutoff = 1000.0 ;
	 else if (i < DISCOUNT_END * stacks && beam_ratio < 100.0)
	    cutoff = 100.0 ;
	 else if (i < (DISCOUNT_END + 2) * stacks && beam_ratio < 10.0)
	    cutoff = 10.0 ;
	 size_t width = beam_width ;
	 if (i < 5 * stacks && width < (5-i/stacks) * 50)
	    width = (5-i/stacks) * 50 ;
	 if (i >= inputLength() * stacks && width < nbest_list_size)
	    width = nbest_list_size ;
	 m_queue[i] = new PriorityQueue(width,cutoff,
					keep_pruned && i<inputLength()*stacks,
					nbest_list_size) ;
	 }
      }
   m_numpruned = 0 ;
   addNode(startnode) ;
   return ;
}

//----------------------------------------------------------------------

BestFirstSearch::~BestFirstSearch()
{
   for (size_t i = 0 ; i <= totalStacks() ; i++)
      delete m_queue[i] ;
   FrFree(m_queue) ;
   m_queue = 0 ;
   LmNGramStates::freeAllocator() ;
   return ;
}

//----------------------------------------------------------------------

size_t BestFirstSearch::totalStacks() const
{
   return inputLength() * m_substacks * m_jigsawstacks + OVERRUN ;
}

//----------------------------------------------------------------------

size_t BestFirstSearch::queueNumber(const BFSNode *node) const
{
   size_t cover = node->inputCoverage() ;
   if (cover > inputLength() + OVERRUN)
      cover = inputLength() + OVERRUN ;
   size_t sub = 0 ;
   if (m_substacks > 1)
      {
      sub = node->gapInCoverage() ;
      if (sub >= m_substacks)
	 sub = m_substacks - 1 ;
      }
   if (m_jigsawstacks > 1)
      {
      sub *= m_jigsawstacks ;
      if (node->gapMarkers())
	 sub++ ;
      }
   return cover*m_substacks*m_jigsawstacks + sub ;
}

//----------------------------------------------------------------------

int BestFirstSearch::maxNodes() const
{
   size_t maxlen = 0 ;
   for (size_t i = 0 ; i <= totalStacks() ; i++)
      maxlen += (m_queue[i] ? m_queue[i]->maximumLengthAttained() : 0) ;
   return maxlen ;
}

//----------------------------------------------------------------------

int BestFirstSearch::currNodes() const
{
   size_t currlen = 0 ;
   for (size_t i = 0 ; i <= totalStacks() ; i++)
      currlen += (m_queue[i] ? m_queue[i]->currentLength() : 0) ;
   return currlen ;
}

//----------------------------------------------------------------------

static void expand_node(const void *input, void *output)
{
   BFSNode *node = (BFSNode*)input ;
   BestFirstSearch *bfs = (BestFirstSearch*)output ;
   NTRACE(5,(cerr << node->inputCoverage() << '+' << node->score() << endl)) ;
   BFSNode *newnodes = 0 ;
   BFSNode *nxt ;
   for ( ; node ; node = nxt)
      {
      nxt = node->next() ;
      BFSNode *n ;
      for ( ; ; )
	 {
	 n = node->expand(false) ;
	 if ((n && !node->lastArcSubsumed()) || !node->nextActiveArc())
	    break ;
	 erase_list(n) ;
	 }
      newnodes = n->nconc(newnodes) ;
      delete node ;
      }
   bfs->insertNodes(newnodes) ;
   return ;
}

//----------------------------------------------------------------------

void BestFirstSearch::insertNodes(BFSNode *newnodes)
{
   TRACE(3,cout<<"insertNodes()"<<endl) ;
   size_t prunecount = 0 ;
   size_t nodecount = 0 ;
   // split the list of nodes into sections that all go onto the same stack
   newnodes = FrMergeSort(newnodes) ;
   BFSNode *next ;
   for (BFSNode *nodes = newnodes ; nodes ; nodes = next)
      {
      nodecount++ ;
      size_t qnum = queueNumber(nodes) ;
      BFSNode *pred = nodes ;
      for (next = nodes->next() ;
	   next && queueNumber(next) == qnum ;
	   next = next->next())
	 {
	 pred = next ;
	 nodecount++ ;
	 }
      pred->setNext(0) ;
      PriorityQueue *q = queue(qnum) ;
      if (q)
	 {
	 q->insertMultiple(nodes,prunecount) ;
	 }
      else
	 {
	 // nowhere to put the nodes, so delete them
	 erase_list(nodes) ;
	 }
      }
   // update node statistics
   m_totalnodes += nodecount ;
   m_numpruned += prunecount ;
   NTRACE(5,(cerr << "  queuelength = " << currNodes() << endl))
   return ;
}

//----------------------------------------------------------------------

bool BestFirstSearch::addNode(BFSNode *node)
{
   PriorityQueue *q = queue(node) ;
   if (q && q->insert(node,m_numpruned))
      m_totalnodes++ ;
   else
      delete node ;
   return true ;
}

//----------------------------------------------------------------------

size_t BestFirstSearch::queueInputCover(size_t stacknum) const
{
   return stacknum / m_substacks / m_jigsawstacks ;
}

//----------------------------------------------------------------------

size_t BestFirstSearch::nextActiveStack() const
{
   for(size_t i = activeStack() + 1 ; i <= totalStacks() ; i++)
      {
      if (m_queue[i]->currentLength() > 0)
	 return i ;
      }
   return UINT_MAX ;
}

//----------------------------------------------------------------------

size_t BestFirstSearch::activeQueueLength()
{
   for (size_t i = activeStack() ; i <= totalStacks() ; i++)
      {
      if (m_queue[i]->currentLength() > 0)
  	 {
  	 m_activestack = i ;
 	 return m_queue[i]->currentLength() ;
  	 }
      }
   return 0 ;
}

//----------------------------------------------------------------------

BFSNode *BestFirstSearch::extractActiveStack(size_t &queuelen)
{
   // skip any empty stacks
   for (size_t i = activeStack() ; i <= totalStacks() ; i++)
      {
      if (m_queue[i]->currentLength() > 0)
	 {
	 m_activestack = i ;
	 break ;
	 }
      }
   size_t cover = queueInputCover(activeStack()) ;
   if (cover >= inputLength())
      return 0 ;
   queuelen = 0 ;
   BFSNode *nodes = 0;
   for (size_t i = activeStack() ;
	i <= totalStacks() && queueInputCover(i) == cover ; i++)
      {
      size_t currlen = m_queue[i]->currentLength() ;
      if (currlen > 0)
  	 {
	 queuelen += currlen ;
	 nodes = m_queue[i]->popAll()->nconc(nodes) ;
  	 }
      }
   return nodes ;
}

//----------------------------------------------------------------------

BFSNode *BestFirstSearch::peek()
{
   for (size_t i = activeStack() ; i <= totalStacks() ; i++)
      {
      if (m_queue[i]->currentLength() > 0)
  	 {
  	 m_activestack = i ;
 	 BFSNode *node = m_queue[i]->peek() ;
	 assertq(node != 0) ;
	 return node ;
  	 }
      }
   return 0 ;
}

//----------------------------------------------------------------------

BFSNode *BestFirstSearch::pop()
{
   for (size_t i = activeStack() ; i <= totalStacks() ; i++)
      {
      if (m_queue[i]->currentLength() > 0)
  	 {
  	 m_activestack = i ;
 	 BFSNode *node = m_queue[i]->pop() ;
	 assertq(node != 0) ;
	 return node ;
  	 }
      }
   return 0 ;
}

//----------------------------------------------------------------------

bool BestFirstSearch::refillQueues(bool unlimit_beam,
				   size_t num_remaining)
{
   bool refilled = false ;
   if (nodesPruned() > 0)
      {
      // to avoid user error in the config file preventing us from finding
      //   a match on the fall-back, remove the beam-ratio limitation
      if (unlimit_beam)
	 beam_ratio = INT_MAX ;
      for (size_t i = 0 ; i < totalStacks() ; i++)
	 {
	 if (m_queue[i]->refill(num_remaining))
	    {
	    if (!refilled)
	       {
	       m_activestack = i ;
	       refilled = true ;
	       }
	    }
	 }
      }
   return refilled ;
}

//----------------------------------------------------------------------

FrList *BestFirstSearch::finalize(BFSNode *node)
{
   FrList *result = new FrList(new FrFloat(node->score()),
			       (FrObject*)(node->value()),
			       (FrObject*)(node->optionalInfo()),
			       node->scoreInfo()) ;
   if (show_overlap_stats)
      LmUpdateOverlapStatistics(node) ;
   INCR_STATS_N(reorderings_used,node->arcReorderings()) ;
   INCR_STATS_N(interleaves_used,node->gapsFilled()) ;
   TRACE(2,
	 (cerr << "  found " << result
	       << "\n     processed " << totalNodes() << " nodes ("
	       << expandedNodes() << " expanded), maxqueue = "
	       << maxNodes() << ", remaining = " << currNodes()  << endl));
   delete node ;
   return result ;
}

//----------------------------------------------------------------------

FrList *BestFirstSearch::find()
{
   if (!thread_pool)
      return 0 ;
   TRACE(3,cout << "BFS::find(), numwords = " << inputLength() << endl) ;
   TRACE(5,(collisionStatistics(cout))) ;
   double orig_beam_ratio = beam_ratio ;
   lm_active_search = this ;
   thread_pool->limitThreads(lm_config->maxthreads) ;
   for (size_t i = 1 ; i <= 3 ; i++)
      {
      size_t queuelen ;
      BFSNode *nodes ;
      while ((nodes = extractActiveStack(queuelen)) != 0)
	 {
	 TRACE(3,(cerr << "queueing " << queuelen << " nodes for expansion"
		  << ", available threads = "
		  << thread_pool->availableThreads() << endl)) ;
	 // try to figure out the best batch size to use -- the number of
	 //   dispatches should be an even multiple of the number of threads
	 //   to avoid waiting on left-over nodes, and there should be neither
	 //   too few nor too many nodes per dispatch
	 size_t blocking_size ;
	 size_t nt = thread_pool->availableThreads() ;
	 if (nt == 0) nt = 1 ;
	 if (1 == nt && queuelen > DISPATCH_MAX_BLOCKING_FACTOR)
	    {
	    blocking_size = DISPATCH_MAX_BLOCKING_FACTOR ;
	    }
	 if (queuelen <= nt * DISPATCH_MIN_BLOCKING_FACTOR)
	    {
	    blocking_size = DISPATCH_MIN_BLOCKING_FACTOR ;
	    }
	 else
	    {
	    blocking_size = (queuelen + nt - 1) / nt ;
	    }
	 // collect the nodes to be expanded, batching multiple nodes per
	 //   thread to be dispatched
	 size_t nodecount = 0 ;
	 BFSNode *batch = 0 ;
	 for (size_t n = 0 ; n < queuelen && nodes ; n++)
	    {
	    BFSNode *node = nodes ;
	    nodes = nodes->next() ;
	    nodes_expanded++ ;
	    node->setNext(batch) ;
	    batch = node ;
	    nodecount++ ;
	    if (nodecount >= blocking_size)
	       {
	       TRACE(5,(cerr << "dispatching " << nodecount << " nodes"
			<< endl)) ;
	       thread_pool->dispatch(expand_node,batch,this,true) ;
	       batch = 0 ;
	       nodecount = 0 ;
	       }
	    }
	 // handle the leftover nodes which didn't completely fill out a batch
	 if (nodecount > 0)
	    {
	    TRACE(5,(cerr << "dispatching " << nodecount << " nodes" << endl));
	    thread_pool->dispatch(expand_node,batch,this,true) ;
	    }
	 thread_pool->waitUntilIdle() ;
	 } // end while
      // when we get here, there are no more stacks of incomplete nodes, so
      //   anything else should be a complete node that we can return to the
      //   caller
      while ((queuelen = activeQueueLength()) > 0)
	 {
	 BFSNode *best = this->pop() ;
	 if (best->complete())
	    {
	    beam_ratio = orig_beam_ratio ;
	    TRACE(5,(collisionStatistics(cout))) ;
	    return finalize(best) ;
	    }
	 else
	    {
	    // Oops!
	    delete best ;
	    }
	 }
      // if we reach this point, the search failed because there was no way
      //   to get complete coverage from the nodes which were explored.  So
      //   now we fall back on any pruned nodes
      if (!refillQueues(true))
	 break ;
      } // end for(i)
   beam_ratio = orig_beam_ratio ;
   lm_active_search = 0 ;
   // oh dear, we weren't able to find a complete walk even using pruned
   //   nodes as fallback....
   TRACE(5,(collisionStatistics(cout))) ;
   TRACE(1,(cerr << "BFS::find failed" << endl))
   return 0 ; // for now
}

//----------------------------------------------------------------------

size_t BestFirstSearch::totalUncontested() const
{
   size_t count = 0 ;
#if defined(FrMULTITHREAD)
   for (size_t i = 0 ; i < totalStacks() ; i++)
      {
      count += queue(i)->mutex().criticalSections() ;
      }
#endif /* FrMULTITHREAD */
   return count ;
}

//----------------------------------------------------------------------

size_t BestFirstSearch::totalCollisions() const
{
   size_t count = 0 ;
#if defined(FrMULTITHREAD)
   for (size_t i = 0 ; i < totalStacks() ; i++)
      {
      count += queue(i)->mutex().threadCollisions() ;
      }
#endif /* FrMULTITHREAD */
   return count ;
}

//----------------------------------------------------------------------

ostream &BestFirstSearch::collisionStatistics(ostream &out) const
{
   size_t coll = totalCollisions() ;
   size_t crit = totalUncontested() ;
   if (coll + crit > 0)
      out << "BFS critical sections: " << coll << " collisions, "
	  << crit << " uncontested" << endl ;
   return out ;
}

//----------------------------------------------------------------------

ostream &BestFirstSearch::cs() const
{
   return collisionStatistics(cerr) ;
}

// end of file lmbfs.cpp //
